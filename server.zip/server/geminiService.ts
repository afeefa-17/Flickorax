import crypto from 'crypto';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import type {
  MediaTypeChoice,
  MoodChoice,
  PreferencesInput,
  SavedPreferencesDoc,
} from '../src/types/flickorax.ts';
import type { CandidateTitle } from './mediaServices.ts';

interface CachedGeminiEntry {
  rawJson: string;
  createdAt: number;
  freshUntil: number;
  staleUntil: number;
}

const FRESH_TTL_DEFAULT_MS = 20 * 60 * 1000; // 20 minutes
const FRESH_TTL_SURPRISE_MS = 5 * 60 * 1000; // 5 minutes
const STALE_BUFFER_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours stale-while-error buffer
const MAX_CACHE_ENTRIES = 300;
const TRANSIENT_COOLDOWN_MS = 90 * 1000; // 90s cooldown after 503 or timeout
const MAX_QUOTA_COOLDOWN_MS = 12 * 60 * 60 * 1000; // Up to 12h when daily quota is exhausted
const PRIMARY_TIMEOUT_MS = 8500;
const FALLBACK_TIMEOUT_MS = 12000;

const responseCache = new Map<string, CachedGeminiEntry>();
const inflightRequests = new Map<string, Promise<{ rawJson: string; fromCache: boolean }>>();
const modelCooldownUntil = new Map<string, number>();

function getGeminiClient(): GoogleGenAI {
  const apiKey = (process.env.GEMINI_API_KEY || '').trim();
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    throw new Error('GEMINI_API_KEY is not configured in server environment variables.');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

export function isQuotaExhaustedError(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err);
  return (
    msg.includes('RESOURCE_EXHAUSTED') ||
    msg.includes('Quota exceeded') ||
    msg.includes('QuotaFailure') ||
    msg.includes('free_tier_requests') ||
    msg.includes('daily free-tier quota') ||
    msg.includes('"code":429')
  );
}

export function isTransientHighDemandError(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err);
  return (
    msg.includes('503') ||
    msg.includes('UNAVAILABLE') ||
    msg.includes('high demand') ||
    msg.includes('429') ||
    msg.includes('RESOURCE_EXHAUSTED') ||
    msg.includes('temporarily busy') ||
    msg.includes('timed out')
  );
}

function isNonRetryableGeminiError(err: unknown): boolean {
  const msg = err instanceof Error ? err.message : String(err);
  return (
    msg.includes('API_KEY_INVALID') ||
    msg.includes('PERMISSION_DENIED') ||
    msg.includes('403') ||
    msg.includes('400') ||
    msg.includes('404')
  );
}

function parseRetryDelayMs(err: unknown): number | null {
  const msg = err instanceof Error ? err.message : String(err);
  const match = msg.match(/"retryDelay"\s*:\s*"(\d+)s"/i);
  if (match?.[1]) {
    const secs = parseInt(match[1], 10);
    if (!Number.isNaN(secs) && secs > 0) {
      return Math.min(secs * 1000, MAX_QUOTA_COOLDOWN_MS);
    }
  }
  return null;
}

function recordModelFailure(model: string, err: unknown): void {
  const msg = err instanceof Error ? err.message : String(err);
  const isDailyQuota =
    msg.includes('PerDay') ||
    msg.includes('free_tier_requests') ||
    msg.includes('Quota exceeded');

  let cooldownMs = 0;
  if (isDailyQuota || isQuotaExhaustedError(err)) {
    cooldownMs = parseRetryDelayMs(err) ?? 60 * 60 * 1000;
  } else if (isTransientHighDemandError(err)) {
    cooldownMs = TRANSIENT_COOLDOWN_MS;
  }

  if (cooldownMs > 0) {
    const prev = modelCooldownUntil.get(model) || 0;
    const next = Date.now() + cooldownMs;
    if (Date.now() >= prev) {
      console.info(
        `[Gemini] Cooling down ${model} for ${Math.round(cooldownMs / 1000)}s; using verified TMDB & AniList fallback meanwhile.`
      );
    }
    modelCooldownUntil.set(model, Math.max(prev, next));
  }
}

function formatGeminiError(err: unknown): Error {
  const msg = err instanceof Error ? err.message : String(err);
  if (isQuotaExhaustedError(err)) {
    return new Error(
      'Gemini daily free-tier quota reached (RESOURCE_EXHAUSTED). Showing verified TMDB & AniList matches. You can add a billing-enabled key in Settings -> Secrets to restore AI curation immediately.'
    );
  }
  if (isTransientHighDemandError(err)) {
    return new Error(
      'AI recommendations are temporarily busy due to high demand. Showing verified TMDB & AniList matches.'
    );
  }
  if (msg.includes('API_KEY_INVALID') || msg.includes('PERMISSION_DENIED') || msg.includes('403')) {
    return new Error('Gemini API key is invalid or missing. Please check GEMINI_API_KEY in Settings -> Secrets.');
  }
  return new Error(msg.length > 220 ? 'Failed to generate AI recommendations.' : msg);
}

function buildCacheKey(namespace: string, prompt: string): string {
  return crypto.createHash('sha256').update(`${namespace}::${prompt}`).digest('hex');
}

function setCachedResponse(key: string, rawJson: string, freshTtlMs: number): void {
  const now = Date.now();
  if (responseCache.has(key)) {
    responseCache.delete(key);
  } else if (responseCache.size >= MAX_CACHE_ENTRIES) {
    const oldestKey = responseCache.keys().next().value;
    if (oldestKey) responseCache.delete(oldestKey);
  }
  responseCache.set(key, {
    rawJson,
    createdAt: now,
    freshUntil: now + freshTtlMs,
    staleUntil: now + STALE_BUFFER_TTL_MS,
  });
}

async function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function expBackoffDelay(attemptIndex: number, baseMs = 450): number {
  if (attemptIndex <= 0) return 0;
  return Math.round(baseMs * Math.pow(2, attemptIndex - 1) + Math.random() * 180);
}

function withTimeout<T>(promise: Promise<T>, ms: number, label: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const timer = setTimeout(() => {
      reject(new Error(`${label} timed out after ${ms}ms`));
    }, ms);
    promise.then(
      (val) => {
        clearTimeout(timer);
        resolve(val);
      },
      (err) => {
        clearTimeout(timer);
        reject(err);
      }
    );
  });
}

function extractCleanJson(raw: string): string {
  let cleaned = (raw || '{}').trim();
  if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '').trim();
  }
  const firstBrace = cleaned.indexOf('{');
  const lastBrace = cleaned.lastIndexOf('}');
  if (firstBrace >= 0 && lastBrace > firstBrace) {
    cleaned = cleaned.slice(firstBrace, lastBrace + 1);
  }
  JSON.parse(cleaned);
  return cleaned;
}

async function generateFastJson(
  namespace: string,
  prompt: string,
  systemInstruction: string,
  schema: Record<string, unknown>,
  freshTtlMs = FRESH_TTL_DEFAULT_MS
): Promise<string> {
  const cacheKey = buildCacheKey(namespace, prompt);
  const now = Date.now();
  const cached = responseCache.get(cacheKey);

  // 1. Fresh cache hit (LRU refresh)
  if (cached && now < cached.freshUntil) {
    responseCache.delete(cacheKey);
    responseCache.set(cacheKey, cached);
    return cached.rawJson;
  }

  // 2. Coalesce identical concurrent in-flight requests
  const existingInflight = inflightRequests.get(cacheKey);
  if (existingInflight) {
    const res = await existingInflight;
    return res.rawJson;
  }

  const runPromise = (async () => {
    const ai = getGeminiClient();
    const candidates: { model: string; thinkingLevel: ThinkingLevel; timeoutMs: number }[] = [
      { model: 'gemini-4-hydrogen', thinkingLevel: ThinkingLevel.LOW, timeoutMs: PRIMARY_TIMEOUT_MS },
      { model: 'gemini-3.1-flash-lite', thinkingLevel: ThinkingLevel.MINIMAL, timeoutMs: FALLBACK_TIMEOUT_MS },
    ];
    const attempts = candidates.filter((c) => Date.now() >= (modelCooldownUntil.get(c.model) || 0));

    if (attempts.length === 0) {
      if (cached && Date.now() < cached.staleUntil) {
        return { rawJson: cached.rawJson, fromCache: true };
      }
      throw new Error(
        'Gemini daily free-tier quota reached (RESOURCE_EXHAUSTED). Showing verified TMDB & AniList matches.'
      );
    }

    let lastErr: unknown;
    for (let i = 0; i < attempts.length; i++) {
      const attempt = attempts[i];
      if (i > 0) {
        await sleep(expBackoffDelay(i, 450));
      }
      try {
        const response = await withTimeout(
          ai.models.generateContent({
            model: attempt.model,
            contents: prompt,
            config: {
              systemInstruction,
              responseMimeType: 'application/json',
              responseSchema: schema,
              thinkingConfig: { thinkingLevel: attempt.thinkingLevel },
            },
          }),
          attempt.timeoutMs,
          `Gemini ${attempt.model}`
        );
        const cleanJson = extractCleanJson(response.text ?? '{}');
        setCachedResponse(cacheKey, cleanJson, freshTtlMs);
        return { rawJson: cleanJson, fromCache: false };
      } catch (err) {
        lastErr = err;
        recordModelFailure(attempt.model, err);
        if (isNonRetryableGeminiError(err)) {
          break;
        }
      }
    }

    // 3. Serve stale buffered response if available during high-demand spike or quota cooldown
    if (cached && Date.now() < cached.staleUntil) {
      return { rawJson: cached.rawJson, fromCache: true };
    }

    throw formatGeminiError(lastErr);
  })();

  inflightRequests.set(cacheKey, runPromise);
  try {
    const result = await runPromise;
    return result.rawJson;
  } finally {
    inflightRequests.delete(cacheKey);
  }
}

function summarizeNonEmptyFilters(
  prefs: PreferencesInput,
  activeFlags?: {
    useDuration: boolean;
    useYear: boolean;
    useCountry: boolean;
    useLanguage: boolean;
  }
): Record<string, unknown> {
  const summary: Record<string, unknown> = {};
  if (prefs.type && prefs.type !== 'Anything') summary.type = prefs.type;
  if (activeFlags?.useLanguage !== false && prefs.languages.length > 0) {
    summary.audioLanguages = [...prefs.languages].sort();
    summary.subtitlesAreFine = prefs.subtitlesFine;
  }
  if (prefs.genres.length > 0) summary.genres = [...prefs.genres].sort();

  const activeMoods = prefs.moods.filter((m) => m !== 'Surprise me').sort();
  if (activeMoods.length > 0) summary.moods = activeMoods;

  if (activeFlags?.useYear !== false && !prefs.releasePeriod.anyYear) {
    summary.releaseYears = `${prefs.releasePeriod.fromYear} to ${prefs.releasePeriod.toYear}`;
  }
  if (activeFlags?.useDuration !== false && prefs.duration) {
    summary.duration = prefs.duration;
  }
  if (prefs.minRating !== null && prefs.minRating > 1) {
    summary.minimumRatingOutOf10 = prefs.minRating;
  }
  const activeCountries = prefs.countries.filter((c) => c !== 'ANY').sort();
  if (activeFlags?.useCountry !== false && activeCountries.length > 0) {
    summary.countriesOfProduction = activeCountries;
  }
  if (prefs.storyPreference.trim()) {
    summary.storylineRequest = prefs.storyPreference.trim();
  }
  return summary;
}

const candidateSchema = {
  type: Type.OBJECT,
  properties: {
    recommendations: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING, description: 'Exact official English or internationally recognized title.' },
          year: { type: Type.STRING, description: '4-digit release year.' },
          mediaType: {
            type: Type.STRING,
            description: 'Must be one of: movie, series, drama, anime.',
          },
          reason: {
            type: Type.STRING,
            description: 'One concise sentence explaining why this title matches the user or group.',
          },
          basedOnTitle: {
            type: Type.STRING,
            description: 'Only when recommending from a watchlist: the exact watchlist title that inspired this pick.',
          },
        },
        required: ['title', 'year', 'mediaType', 'reason'],
      },
    },
  },
  required: ['recommendations'],
};

function sanitizeMediaType(raw: string, fallback: MediaTypeChoice = 'Anything'): CandidateTitle['mediaType'] {
  const lower = (raw || '').toLowerCase();
  if (lower === 'anime') return 'anime';
  if (lower === 'drama') return 'drama';
  if (lower === 'series' || lower === 'tv') return 'series';
  if (lower === 'movie' || lower === 'film') return 'movie';
  if (fallback === 'Anime') return 'anime';
  if (fallback === 'Dramas') return 'drama';
  if (fallback === 'Series') return 'series';
  return 'movie';
}

export async function generateSoloCandidates(
  prefs: PreferencesInput,
  activeFlags: { useDuration: boolean; useYear: boolean; useCountry: boolean; useLanguage: boolean },
  excludeTitles: string[] = [],
  count = 10,
  animeOnly = false
): Promise<CandidateTitle[]> {
  const filterObj = summarizeNonEmptyFilters(prefs, activeFlags);
  const isAllEmpty = Object.keys(filterObj).length === 0;
  const animeNote = animeOnly ? ' ONLY recommend anime (mediaType: "anime") verifiable on AniList.' : '';
  const sortedExcludes = [...excludeTitles].sort();

  const prompt = isAllEmpty
    ? `Recommend ${count} acclaimed, popular titles${animeOnly ? ' (strictly anime)' : ' across Movies, Anime, TV Series, and Dramas'}. Exclude: ${sortedExcludes.join(', ') || 'none'}.${animeNote}`
    : `Recommend ${count} real titles matching these filters:
${JSON.stringify(filterObj)}
Rules: "Dramas" = drama TV series; respect Type strictly; audioLanguages is OR-logic (pick titles originally in ANY of the listed languages, e.g. a balanced variety across them—unless subtitlesAreFine=true); genres & moods & countries are OR-logic (match at least 1 selected genre, preferring titles blending 2+ listed genres/moods when natural); exclude ${sortedExcludes.join(', ') || 'none'}.${animeNote}`;

  const rawJson = await generateFastJson(
    'solo',
    prompt,
    'You are Flickorax curator. Output real released titles verifiable on TMDB or AniList as strict JSON.',
    candidateSchema,
    FRESH_TTL_DEFAULT_MS
  );

  const parsed = JSON.parse(rawJson) as {
    recommendations?: { title: string; year: string; mediaType: string; reason: string }[];
  };

  return (parsed.recommendations || []).map((r) => ({
    title: r.title,
    year: r.year,
    mediaType: animeOnly ? 'anime' : sanitizeMediaType(r.mediaType, prefs.type),
    reason: r.reason,
  }));
}

export async function generateSurpriseCandidates(
  mood: MoodChoice,
  type: MediaTypeChoice,
  excludeTitles: string[] = [],
  animeOnly = false
): Promise<CandidateTitle[]> {
  const moodClause = mood === 'Surprise me' ? 'any engaging mood' : `"${mood}" mood`;
  const effectiveType = animeOnly ? 'Anime' : type;
  const typeClause =
    effectiveType === 'Anything'
      ? 'a diverse mix of Movies, Anime, Series, and Dramas'
      : `strictly ${effectiveType}`;
  const sortedExcludes = [...excludeTitles].sort();

  const prompt = `Pick 8 memorable titles for ${typeClause} fitting ${moodClause}. Exclude: ${sortedExcludes.join(', ') || 'none'}.`;

  const rawJson = await generateFastJson(
    'surprise',
    prompt,
    'You are Flickorax Surprise Me curator. Return real titles verifiable on TMDB or AniList as strict JSON.',
    candidateSchema,
    FRESH_TTL_SURPRISE_MS
  );

  const parsed = JSON.parse(rawJson) as {
    recommendations?: { title: string; year: string; mediaType: string; reason: string }[];
  };

  return (parsed.recommendations || []).map((r) => ({
    title: r.title,
    year: r.year,
    mediaType: animeOnly ? 'anime' : sanitizeMediaType(r.mediaType, effectiveType),
    reason: r.reason,
  }));
}

export async function generateBecauseYouLikedCandidates(
  watchlist: { title: string; mediaType: string; genres: string[] }[],
  savedPreferences?: Partial<SavedPreferencesDoc> | null
): Promise<CandidateTitle[]> {
  const watchedList = watchlist
    .slice(0, 12)
    .map((w) => `${w.title} (${w.mediaType})`)
    .sort();

  const quietPrefs: Record<string, unknown> = {};
  if (savedPreferences?.languages?.length) quietPrefs.languages = [...savedPreferences.languages].sort();
  if (savedPreferences?.genres?.length) quietPrefs.genres = [...savedPreferences.genres].sort();
  if (savedPreferences?.moods?.length) {
    quietPrefs.moods = savedPreferences.moods.filter((m) => m !== 'Surprise me').sort();
  }
  if (savedPreferences?.countries?.length) quietPrefs.countries = [...savedPreferences.countries].sort();

  const prompt = `Watchlist: ${watchedList.join(', ')}
Background preferences: ${JSON.stringify(quietPrefs)}
Recommend 8 NEW similar titles not in the watchlist. Set "basedOnTitle" to the matching watchlist title.`;

  const rawJson = await generateFastJson(
    'because',
    prompt,
    'You are Flickorax personalized recommender. Output real titles verifiable on TMDB or AniList as strict JSON.',
    candidateSchema,
    FRESH_TTL_DEFAULT_MS
  );

  const parsed = JSON.parse(rawJson) as {
    recommendations?: {
      title: string;
      year: string;
      mediaType: string;
      reason: string;
      basedOnTitle?: string;
    }[];
  };

  return (parsed.recommendations || []).map((r) => ({
    title: r.title,
    year: r.year,
    mediaType: sanitizeMediaType(r.mediaType, 'Anything'),
    reason: r.reason,
    basedOnTitle: r.basedOnTitle || watchlist[0]?.title,
  }));
}

export async function generateWatchPartyCandidates(
  memberPreferences: { name: string; preferences: PreferencesInput | null }[],
  excludeTitles: string[] = [],
  animeOnly = false
): Promise<CandidateTitle[]> {
  const tally = (items: string[]) => {
    const counts = new Map<string, number>();
    for (const item of items) {
      counts.set(item, (counts.get(item) || 0) + 1);
    }
    return Array.from(counts.entries())
      .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
      .map(([value, count]) => ({ value, count }));
  };

  const submitted = memberPreferences.filter((m) => m.preferences !== null);
  const groupSummary = {
    members: memberPreferences.length,
    submitted: submitted.length,
    types: tally(submitted.map((m) => m.preferences!.type).filter((t) => t && t !== 'Anything')),
    genres: tally(submitted.flatMap((m) => m.preferences!.genres)).slice(0, 10),
    moods: tally(submitted.flatMap((m) => m.preferences!.moods).filter((m) => m !== 'Surprise me')),
    languages: tally(submitted.flatMap((m) => m.preferences!.languages)),
    subtitlesOk: submitted.filter((m) => m.preferences!.subtitlesFine).length,
    countries: tally(submitted.flatMap((m) => m.preferences!.countries).filter((c) => c !== 'ANY')),
    storyNotes: submitted.map((m) => m.preferences!.storyPreference.trim()).filter(Boolean).sort(),
  };

  const sortedExcludes = [...excludeTitles].sort();
  const prompt = `Watch Party group (${memberPreferences.length} members). Merged preferences (prioritize most members):
${JSON.stringify(groupSummary)}
Exclude: ${sortedExcludes.join(', ') || 'none'}.${animeOnly ? ' ONLY recommend anime (mediaType: "anime").' : ''}
Recommend 8 titles with a 1-sentence reason explaining why each suits the group.`;

  const rawJson = await generateFastJson(
    'watch-party',
    prompt,
    'You are Flickorax Watch Party matchmaker. Output real titles verifiable on TMDB or AniList as strict JSON.',
    candidateSchema,
    FRESH_TTL_DEFAULT_MS
  );

  const parsed = JSON.parse(rawJson) as {
    recommendations?: { title: string; year: string; mediaType: string; reason: string }[];
  };

  return (parsed.recommendations || []).map((r) => ({
    title: r.title,
    year: r.year,
    mediaType: animeOnly ? 'anime' : sanitizeMediaType(r.mediaType, 'Anything'),
    reason: r.reason,
  }));
}
