import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import type {
  MediaRecommendation,
  PreferencesInput,
  RoomMemberDoc,
  WatchPartyRoomDoc,
} from '../src/types/flickorax.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '..', 'data');
const ROOMS_FILE = path.join(DATA_DIR, 'watch-party-rooms.json');

// Excludes look-alike characters 0, O, 1, I, L
const CODE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const ROOM_LIFETIME_MS = 15 * 60 * 60 * 1000;
const MAX_MEMBERS = 10;

interface InternalMemberRecord {
  uid: string;
  name: string;
  isHost: boolean;
  status: 'choosing' | 'ready';
  preferences: PreferencesInput | null;
  tokenHash: string;
  joinedAtMs: number;
  updatedAtMs: number;
}

interface InternalRoomRecord {
  code: string;
  hostId: string;
  hostName: string;
  status: 'waiting' | 'matching' | 'matched';
  results: MediaRecommendation[];
  errorMessage: string;
  createdAtMs: number;
  expiresAtMs: number;
  updatedAtMs: number;
  members: InternalMemberRecord[];
}

const rooms = new Map<string, InternalRoomRecord>();

function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

export function normalizeRoomCode(input: string): string {
  return input.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
}

function loadRooms(): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(ROOMS_FILE)) {
      const raw = fs.readFileSync(ROOMS_FILE, 'utf8');
      const arr = JSON.parse(raw) as InternalRoomRecord[];
      const now = Date.now();
      for (const r of arr) {
        if (r && typeof r.code === 'string' && r.expiresAtMs > now) {
          rooms.set(r.code, r);
        }
      }
    }
  } catch (err) {
    console.warn('Could not load watch party rooms store:', err);
  }
}

function saveRooms(): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const tmp = `${ROOMS_FILE}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(Array.from(rooms.values())), 'utf8');
    fs.renameSync(tmp, ROOMS_FILE);
  } catch (err) {
    console.warn('Failed to persist watch party rooms:', err);
  }
}

export function purgeExpiredRooms(): void {
  const now = Date.now();
  let changed = false;
  for (const [code, room] of rooms.entries()) {
    if (room.expiresAtMs <= now) {
      rooms.delete(code);
      changed = true;
    }
  }
  if (changed) saveRooms();
}

loadRooms();
setInterval(purgeExpiredRooms, 5 * 60 * 1000).unref();

function generateRandomCode(): string {
  let out = '';
  for (let i = 0; i < 6; i++) {
    out += CODE_ALPHABET[crypto.randomInt(0, CODE_ALPHABET.length)];
  }
  return out;
}

function toPublicRoom(r: InternalRoomRecord): WatchPartyRoomDoc {
  return {
    code: r.code,
    hostId: r.hostId,
    hostName: r.hostName,
    memberIds: r.members.map((m) => m.uid),
    memberCount: r.members.length,
    status: r.status,
    results: r.results,
    errorMessage: r.errorMessage || undefined,
    createdAt: r.createdAtMs,
    expiresAtMs: r.expiresAtMs,
    updatedAt: r.updatedAtMs,
  };
}

function toPublicMembers(r: InternalRoomRecord): RoomMemberDoc[] {
  return r.members.map((m) => ({
    uid: m.uid,
    name: m.name,
    isHost: m.isHost,
    status: m.status,
    preferences: m.preferences,
    joinedAt: m.joinedAtMs,
    updatedAt: m.updatedAtMs,
  }));
}

export function createPartyRoom(rawNickname: string): {
  room: WatchPartyRoomDoc;
  members: RoomMemberDoc[];
  myMemberId: string;
  memberToken: string;
} {
  purgeExpiredRooms();
  const cleanName = rawNickname.trim().slice(0, 60);
  if (!cleanName) {
    throw new Error('Please enter a nickname to create the room.');
  }

  let code = '';
  for (let i = 0; i < 16; i++) {
    const candidate = generateRandomCode();
    if (!rooms.has(candidate)) {
      code = candidate;
      break;
    }
  }
  if (!code) {
    throw new Error('Could not allocate a unique room code. Please try again.');
  }

  const now = Date.now();
  const memberId = `wp_${crypto.randomBytes(10).toString('hex')}`;
  const memberToken = crypto.randomBytes(24).toString('hex');

  const record: InternalRoomRecord = {
    code,
    hostId: memberId,
    hostName: cleanName,
    status: 'waiting',
    results: [],
    errorMessage: '',
    createdAtMs: now,
    expiresAtMs: now + ROOM_LIFETIME_MS,
    updatedAtMs: now,
    members: [
      {
        uid: memberId,
        name: cleanName,
        isHost: true,
        status: 'choosing',
        preferences: null,
        tokenHash: hashToken(memberToken),
        joinedAtMs: now,
        updatedAtMs: now,
      },
    ],
  };

  rooms.set(code, record);
  saveRooms();

  return {
    room: toPublicRoom(record),
    members: toPublicMembers(record),
    myMemberId: memberId,
    memberToken,
  };
}

export function joinPartyRoom(
  rawCode: string,
  rawNickname: string,
  existingToken?: string
): {
  room: WatchPartyRoomDoc;
  members: RoomMemberDoc[];
  myMemberId: string;
  memberToken: string;
} {
  purgeExpiredRooms();
  const code = normalizeRoomCode(rawCode);
  if (!/^[A-HJ-NP-Z2-9]{6}$/.test(code)) {
    throw new Error('Please enter a valid 6-character room code.');
  }

  const room = rooms.get(code);
  if (!room) {
    throw new Error('Room not found or expired. Check the code and try again.');
  }
  if (room.expiresAtMs <= Date.now()) {
    rooms.delete(code);
    saveRooms();
    throw new Error('This room has expired. Ask your host to create a new one.');
  }

  if (existingToken) {
    const th = hashToken(existingToken);
    const existingMember = room.members.find((m) => m.tokenHash === th);
    if (existingMember) {
      return {
        room: toPublicRoom(room),
        members: toPublicMembers(room),
        myMemberId: existingMember.uid,
        memberToken: existingToken,
      };
    }
  }

  const cleanName = rawNickname.trim().slice(0, 60);
  if (!cleanName) {
    throw new Error('Please enter a nickname to join.');
  }

  if (room.members.length >= MAX_MEMBERS) {
    throw new Error('This room is full (10/10 members)');
  }

  const now = Date.now();
  const memberId = `wp_${crypto.randomBytes(10).toString('hex')}`;
  const memberToken = crypto.randomBytes(24).toString('hex');

  room.members.push({
    uid: memberId,
    name: cleanName,
    isHost: false,
    status: 'choosing',
    preferences: null,
    tokenHash: hashToken(memberToken),
    joinedAtMs: now,
    updatedAtMs: now,
  });
  room.updatedAtMs = now;
  saveRooms();

  return {
    room: toPublicRoom(room),
    members: toPublicMembers(room),
    myMemberId: memberId,
    memberToken,
  };
}

function getAuthenticatedRoomAndMember(
  rawCode: string,
  authHeader: string | undefined
): { room: InternalRoomRecord; member: InternalMemberRecord; code: string } {
  purgeExpiredRooms();
  const code = normalizeRoomCode(rawCode);
  const room = rooms.get(code);
  if (!room) {
    const err = new Error('This room has expired. Ask your host to create a new one.');
    (err as Error & { statusCode?: number }).statusCode = 410;
    throw err;
  }
  if (room.expiresAtMs <= Date.now()) {
    rooms.delete(code);
    saveRooms();
    const err = new Error('This room has expired. Ask your host to create a new one.');
    (err as Error & { statusCode?: number }).statusCode = 410;
    throw err;
  }

  const token = authHeader?.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';
  if (!token) {
    const err = new Error('Join this room with a nickname to view or participate.');
    (err as Error & { statusCode?: number }).statusCode = 401;
    throw err;
  }
  const th = hashToken(token);
  const member = room.members.find((m) => m.tokenHash === th);
  if (!member) {
    const err = new Error('You are not a member of this room.');
    (err as Error & { statusCode?: number }).statusCode = 403;
    throw err;
  }

  return { room, member, code };
}

export function getPartyRoomState(
  rawCode: string,
  authHeader: string | undefined
): { room: WatchPartyRoomDoc; members: RoomMemberDoc[]; myMemberId: string } {
  const { room, member } = getAuthenticatedRoomAndMember(rawCode, authHeader);
  return {
    room: toPublicRoom(room),
    members: toPublicMembers(room),
    myMemberId: member.uid,
  };
}

export function submitPartyMemberPicks(
  rawCode: string,
  authHeader: string | undefined,
  preferences: PreferencesInput
): { room: WatchPartyRoomDoc; members: RoomMemberDoc[]; myMemberId: string } {
  const { room, member } = getAuthenticatedRoomAndMember(rawCode, authHeader);
  if (room.status !== 'waiting') {
    const err = new Error('The host has already started matching—picks are locked for this round.');
    (err as Error & { statusCode?: number }).statusCode = 409;
    throw err;
  }

  const now = Date.now();
  member.status = 'ready';
  member.preferences = preferences;
  member.updatedAtMs = now;
  room.updatedAtMs = now;
  saveRooms();

  return {
    room: toPublicRoom(room),
    members: toPublicMembers(room),
    myMemberId: member.uid,
  };
}

export function beginPartyRoomMatch(
  rawCode: string,
  authHeader: string | undefined
): {
  room: WatchPartyRoomDoc;
  memberPreferences: { name: string; preferences: PreferencesInput | null }[];
} {
  const { room, member } = getAuthenticatedRoomAndMember(rawCode, authHeader);
  if (!member.isHost) {
    const err = new Error('Only the room host can start the Watch Party match.');
    (err as Error & { statusCode?: number }).statusCode = 403;
    throw err;
  }

  room.status = 'matching';
  room.errorMessage = '';
  room.updatedAtMs = Date.now();
  saveRooms();

  return {
    room: toPublicRoom(room),
    memberPreferences: room.members.map((m) => ({
      name: m.name,
      preferences: m.status === 'ready' ? m.preferences : null,
    })),
  };
}

export function completePartyRoomMatch(
  rawCode: string,
  results: MediaRecommendation[],
  errorMessage = ''
): { room: WatchPartyRoomDoc; members: RoomMemberDoc[] } {
  const code = normalizeRoomCode(rawCode);
  const room = rooms.get(code);
  if (!room) {
    throw new Error('This room has expired. Ask your host to create a new one.');
  }
  const now = Date.now();
  if (errorMessage && results.length === 0) {
    room.status = 'waiting';
    room.errorMessage = errorMessage;
  } else {
    room.status = 'matched';
    room.results = results;
    room.errorMessage = '';
  }
  room.updatedAtMs = now;
  saveRooms();

  return {
    room: toPublicRoom(room),
    members: toPublicMembers(room),
  };
}
