import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import type {
  MediaRecommendation,
  MoodChoice,
  PreferencesInput,
  SavedPreferencesDoc,
  WatchlistItemDoc,
} from '../src/types/flickorax.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '..', 'data');
const STORE_FILE = path.join(DATA_DIR, 'auth-store.json');

const SESSION_LIFETIME_MS = 7 * 24 * 60 * 60 * 1000;

export interface ServerUserPublic {
  uid: string;
  email: string;
  displayName: string;
}

interface StoredUserRecord {
  uid: string;
  email: string;
  displayName: string;
  salt: string;
  passwordHash: string;
  createdAtMs: number;
}

interface StoredSessionRecord {
  tokenHash: string;
  uid: string;
  expiresAtMs: number;
}

interface AuthStoreData {
  users: StoredUserRecord[];
  sessions: StoredSessionRecord[];
  preferences: Record<string, SavedPreferencesDoc>;
  watchlist: Record<string, WatchlistItemDoc[]>;
}

function emptyStore(): AuthStoreData {
  return {
    users: [],
    sessions: [],
    preferences: {},
    watchlist: {},
  };
}

let store: AuthStoreData = emptyStore();

function loadStore(): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(STORE_FILE)) {
      const raw = fs.readFileSync(STORE_FILE, 'utf8');
      const parsed = JSON.parse(raw) as Partial<AuthStoreData>;
      store = {
        users: Array.isArray(parsed.users) ? parsed.users : [],
        sessions: Array.isArray(parsed.sessions) ? parsed.sessions : [],
        preferences: parsed.preferences && typeof parsed.preferences === 'object' ? parsed.preferences : {},
        watchlist: parsed.watchlist && typeof parsed.watchlist === 'object' ? parsed.watchlist : {},
      };
      pruneExpiredSessions();
    }
  } catch (err) {
    console.warn('Could not load auth store, starting fresh:', err);
    store = emptyStore();
  }
}

function saveStore(): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    const tmpFile = `${STORE_FILE}.tmp`;
    fs.writeFileSync(tmpFile, JSON.stringify(store), 'utf8');
    fs.renameSync(tmpFile, STORE_FILE);
  } catch (err) {
    console.warn('Failed to persist auth store:', err);
  }
}

function pruneExpiredSessions(): void {
  const now = Date.now();
  const before = store.sessions.length;
  store.sessions = store.sessions.filter((s) => s.expiresAtMs > now);
  if (store.sessions.length !== before) {
    saveStore();
  }
}

function hashToken(token: string): string {
  return crypto.createHash('sha256').update(token).digest('hex');
}

function hashPassword(password: string, salt: string): string {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

function verifyPassword(password: string, salt: string, storedHex: string): boolean {
  try {
    const derived = crypto.scryptSync(password, salt, 64);
    const storedBuf = Buffer.from(storedHex, 'hex');
    if (derived.length !== storedBuf.length) return false;
    return crypto.timingSafeEqual(derived, storedBuf);
  } catch {
    return false;
  }
}

function normalizeEmail(raw: string): string {
  return raw.trim().toLowerCase();
}

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 160;
}

loadStore();

export function signupLocalUser(
  rawName: string,
  rawEmail: string,
  password: string
): { user: ServerUserPublic; token: string } {
  const email = normalizeEmail(rawEmail);
  const displayName = rawName.trim().slice(0, 60) || email.split('@')[0] || 'Member';

  if (!isValidEmail(email)) {
    throw new Error('Please enter a valid email address.');
  }
  if (typeof password !== 'string' || password.length < 6 || password.length > 128) {
    throw new Error('Password must be between 6 and 128 characters.');
  }

  const existing = store.users.find((u) => u.email === email);
  if (existing) {
    throw new Error('An account with this email already exists. Please log in instead.');
  }

  const uid = `usr_${crypto.randomBytes(12).toString('hex')}`;
  const salt = crypto.randomBytes(16).toString('hex');
  const passwordHash = hashPassword(password, salt);

  store.users.push({
    uid,
    email,
    displayName,
    salt,
    passwordHash,
    createdAtMs: Date.now(),
  });

  const token = crypto.randomBytes(32).toString('hex');
  store.sessions.push({
    tokenHash: hashToken(token),
    uid,
    expiresAtMs: Date.now() + SESSION_LIFETIME_MS,
  });

  saveStore();
  return {
    user: { uid, email, displayName },
    token,
  };
}

export function loginLocalUser(
  rawEmail: string,
  password: string
): { user: ServerUserPublic; token: string } {
  const email = normalizeEmail(rawEmail);
  if (!isValidEmail(email) || typeof password !== 'string' || password.length < 1) {
    throw new Error('Please enter your email and password.');
  }

  const found = store.users.find((u) => u.email === email);
  if (!found || !verifyPassword(password, found.salt, found.passwordHash)) {
    throw new Error('Invalid email or password.');
  }

  pruneExpiredSessions();
  const token = crypto.randomBytes(32).toString('hex');
  store.sessions.push({
    tokenHash: hashToken(token),
    uid: found.uid,
    expiresAtMs: Date.now() + SESSION_LIFETIME_MS,
  });
  saveStore();

  return {
    user: {
      uid: found.uid,
      email: found.email,
      displayName: found.displayName,
    },
    token,
  };
}

export function authenticateBearerToken(authHeader: string | undefined): ServerUserPublic | null {
  if (!authHeader || !authHeader.startsWith('Bearer ')) return null;
  const token = authHeader.slice(7).trim();
  if (!token || token.length < 32) return null;

  pruneExpiredSessions();
  const th = hashToken(token);
  const session = store.sessions.find((s) => s.tokenHash === th && s.expiresAtMs > Date.now());
  if (!session) return null;

  const user = store.users.find((u) => u.uid === session.uid);
  if (!user) return null;

  return {
    uid: user.uid,
    email: user.email,
    displayName: user.displayName,
  };
}

export function logoutLocalSession(authHeader: string | undefined): void {
  if (!authHeader || !authHeader.startsWith('Bearer ')) return;
  const token = authHeader.slice(7).trim();
  if (!token) return;
  const th = hashToken(token);
  const before = store.sessions.length;
  store.sessions = store.sessions.filter((s) => s.tokenHash !== th);
  if (store.sessions.length !== before) {
    saveStore();
  }
}

export function getLocalUserData(uid: string): {
  savedPreferences: SavedPreferencesDoc | null;
  watchlist: WatchlistItemDoc[];
} {
  return {
    savedPreferences: store.preferences[uid] || null,
    watchlist: store.watchlist[uid] || [],
  };
}

export function saveLocalUserPreferences(uid: string, prefs: PreferencesInput): SavedPreferencesDoc {
  const validMoods = new Set<MoodChoice>(['Happy', 'Sad', 'Romantic', 'Thrilling', 'Relaxed', 'Surprise me']);
  const doc: SavedPreferencesDoc = {
    userId: uid,
    languages: (prefs.languages || []).filter((x): x is string => typeof x === 'string').slice(0, 30),
    subtitlesFine: Boolean(prefs.subtitlesFine),
    genres: (prefs.genres || []).filter((x): x is string => typeof x === 'string').slice(0, 40),
    moods: (prefs.moods || []).filter((m): m is MoodChoice => validMoods.has(m)).slice(0, 10),
    countries: (prefs.countries || []).filter((x): x is string => typeof x === 'string').slice(0, 30),
    updatedAt: Date.now(),
  };
  store.preferences[uid] = doc;
  saveStore();
  return doc;
}

export function addLocalWatchlistItem(uid: string, item: MediaRecommendation): WatchlistItemDoc[] {
  const safeId = (item.externalId || '').replace(/[^a-zA-Z0-9_-]/g, '-').slice(0, 100);
  if (!safeId) return store.watchlist[uid] || [];

  const list = store.watchlist[uid] || [];
  const doc: WatchlistItemDoc = {
    userId: uid,
    externalId: safeId,
    source: item.source === 'anilist' ? 'anilist' : 'tmdb',
    mediaType:
      item.mediaType === 'anime' || item.mediaType === 'drama' || item.mediaType === 'series'
        ? item.mediaType
        : 'movie',
    title: String(item.title || 'Untitled').slice(0, 300),
    year: String(item.year || '').slice(0, 16),
    posterUrl: String(item.posterUrl || '').slice(0, 600),
    genres: Array.isArray(item.genres)
      ? item.genres.filter((g): g is string => typeof g === 'string').slice(0, 15)
      : [],
    rating: Number(item.rating) || 0,
    overview: String(item.overview || '').slice(0, 2500),
    reason: String(item.reason || '').slice(0, 600),
    addedAt: Date.now(),
  };

  const filtered = list.filter((x) => x.externalId !== safeId);
  store.watchlist[uid] = [doc, ...filtered].slice(0, 200);
  saveStore();
  return store.watchlist[uid];
}

export function removeLocalWatchlistItem(uid: string, externalId: string): WatchlistItemDoc[] {
  const safeId = (externalId || '').replace(/[^a-zA-Z0-9_-]/g, '-').slice(0, 100);
  const list = store.watchlist[uid] || [];
  store.watchlist[uid] = list.filter((x) => x.externalId !== safeId);
  saveStore();
  return store.watchlist[uid];
}
