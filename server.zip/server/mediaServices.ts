import {
  ANIME_SPECIFIC_GENRES,
  FALLBACK_COUNTRIES,
  FALLBACK_GENRES,
  FALLBACK_LANGUAGES,
  POPULAR_COUNTRY_CODES,
  POPULAR_LANGUAGE_CODES,
} from '../src/data/fallbackOptions.ts';
import type {
  CatalogOptionsResponse,
  CountryOption,
  GenreOption,
  LanguageOption,
  MediaDetails,
  MediaRecommendation,
  PreferencesInput,
} from '../src/types/flickorax.ts';

const TMDB_BASE = 'https://api.themoviedb.org/3';
const TMDB_IMG_POSTER = 'https://image.tmdb.org/t/p/w500';
const TMDB_IMG_BACKDROP = 'https://image.tmdb.org/t/p/w1280';
const TMDB_IMG_PROFILE = 'https://image.tmdb.org/t/p/w185';
const TMDB_IMG_LOGO = 'https://image.tmdb.org/t/p/w92';
const ANILIST_URL = 'https://graphql.anilist.co';

const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;
const QUERY_CACHE_TTL_MS = 5 * 60 * 1000;
const MAX_QUERY_CACHE = 250;
let cachedOptions: CatalogOptionsResponse | null = null;
const queryCache = new Map<string, { value: unknown; expiresAt: number }>();

function getQueryCache<T>(key: string): T | undefined {
  const hit = queryCache.get(key);
  if (!hit) return undefined;
  if (Date.now() > hit.expiresAt) {
    queryCache.delete(key);
    return undefined;
  }
  return hit.value as T;
}

function setQueryCache(key: string, value: unknown): void {
  if (queryCache.has(key)) {
    queryCache.delete(key);
  } else if (queryCache.size >= MAX_QUERY_CACHE) {
    const oldest = queryCache.keys().next().value;
    if (oldest) queryCache.delete(oldest);
  }
  queryCache.set(key, { value, expiresAt: Date.now() + QUERY_CACHE_TTL_MS });
}

export function getTmdbApiKey(): string {
  const key = (process.env.TMDB_API_KEY || '').trim();
  if (!key || key === 'MY_TMDB_API_KEY') return '';
  return key;
}

export function isTmdbConfigured(): boolean {
  return getTmdbApiKey().length > 0;
}

async function tmdbFetch<T>(path: string, params: Record<string, string | number | undefined> = {}): Promise<T | null> {
  const apiKey = getTmdbApiKey();
  if (!apiKey) return null;

  const url = new URL(`${TMDB_BASE}${path}`);
  const isBearer = apiKey.startsWith('eyJ') && apiKey.length > 40;
  if (!isBearer) {
    url.searchParams.set('api_key', apiKey);
  }
  const sortedEntries = Object.entries(params)
    .filter(([, v]) => v !== undefined && v !== '')
    .sort(([a], [b]) => a.localeCompare(b));
  for (const [k, v] of sortedEntries) {
    url.searchParams.set(k, String(v));
  }

  const cacheKey = `tmdb:${path}?${sortedEntries.map(([k, v]) => `${k}=${v}`).join('&')}`;
  const cached = getQueryCache<T>(cacheKey);
  if (cached !== undefined) return cached;

  for (let attempt = 0; attempt < 2; attempt++) {
    if (attempt > 0) {
      await new Promise((r) => setTimeout(r, 350));
    }
    try {
      const res = await fetch(url.toString(), {
        headers: isBearer
          ? { Authorization: `Bearer ${apiKey}`, Accept: 'application/json' }
          : { Accept: 'application/json' },
        signal: AbortSignal.timeout(8000),
      });
      if (!res.ok) {
        const bodySnippet = await res.text().catch(() => '');
        console.warn(`TMDB ${path} returned ${res.status}: ${bodySnippet.slice(0, 180)}`);
        if (res.status === 429 || res.status >= 500) continue;
        return null;
      }
      const data = (await res.json()) as T;
      setQueryCache(cacheKey, data);
      return data;
    } catch (err) {
      console.warn(`TMDB ${path} error (attempt ${attempt + 1}):`, err);
    }
  }
  return null;
}

async function anilistFetch<T>(query: string, variables: Record<string, unknown> = {}): Promise<T | null> {
  const cacheKey = `anilist:${query.replace(/\s+/g, ' ').trim()}::${JSON.stringify(variables)}`;
  const cached = getQueryCache<T>(cacheKey);
  if (cached !== undefined) return cached;

  for (let attempt = 0; attempt < 2; attempt++) {
    if (attempt > 0) {
      await new Promise((r) => setTimeout(r, 450));
    }
    try {
      const res = await fetch(ANILIST_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({ query, variables }),
        signal: AbortSignal.timeout(8000),
      });
      if (!res.ok) {
        console.warn(`AniList returned ${res.status} (attempt ${attempt + 1})`);
        if (res.status === 429 || res.status >= 500) continue;
        return null;
      }
      const json = (await res.json()) as { data?: T; errors?: unknown[] };
      if (json.errors?.length) {
        console.warn('AniList GraphQL warning:', json.errors);
      }
      if (json.data) {
        setQueryCache(cacheKey, json.data);
      }
      return json.data ?? null;
    } catch (err) {
      console.warn(`AniList fetch error (attempt ${attempt + 1}):`, err);
    }
  }
  return null;
}

export function stripHtml(raw: string | null | undefined): string {
  if (!raw) return '';
  return raw
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/p>/gi, '\n')
    .replace(/<[^>]+>/g, '')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

export function summarizeSentences(text: string, maxSentences = 3): string {
  const clean = stripHtml(text).replace(/\s+/g, ' ').trim();
  if (!clean) return 'No storyline summary available from the database.';
  const sentences = clean.match(/[^.!?]+[.!?]+/g);
  if (!sentences || sentences.length === 0) {
    return clean.length > 260 ? `${clean.slice(0, 257).trim()}...` : clean;
  }
  const picked = sentences.slice(0, maxSentences).join(' ').trim();
  return picked.length > 340 ? `${picked.slice(0, 337).trim()}...` : picked;
}

function normalizeGenreName(raw: string): string {
  const trimmed = raw.trim();
  const lower = trimmed.toLowerCase();
  if (lower === 'science fiction' || lower === 'sci-fi & fantasy') return 'Sci-Fi';
  if (lower === 'action & adventure') return 'Action';
  if (lower === 'war & politics') return 'War';
  if (lower === 'mahou shoujo') return 'Mahou Shoujo';
  return trimmed;
}

function classifyGenreTypes(name: string, inMovie: boolean, inTv: boolean, inAnime: boolean): GenreOption['types'] {
  const lower = name.toLowerCase();
  if (ANIME_SPECIFIC_GENRES.has(lower)) {
    return ['anime'];
  }
  const types = new Set<'movies' | 'series' | 'dramas' | 'anime'>();
  if (inMovie) types.add('movies');
  if (inTv) {
    types.add('series');
    if (!['animation', 'kids', 'news', 'reality', 'talk', 'western'].includes(lower)) {
      types.add('dramas');
    }
  }
  if (inAnime) types.add('anime');
  if (types.size === 0) {
    types.add('movies');
    types.add('series');
    types.add('dramas');
    types.add('anime');
  }
  return Array.from(types);
}

export async function getCatalogOptions(forceRefresh = false): Promise<CatalogOptionsResponse> {
  const now = Date.now();
  if (!forceRefresh && cachedOptions && now - cachedOptions.cachedAt < SEVEN_DAYS_MS) {
    return { ...cachedOptions, tmdbConfigured: isTmdbConfigured() };
  }

  const [tmdbMovieGenres, tmdbTvGenres, tmdbLanguages, tmdbCountries, anilistGenresRes] = await Promise.all([
    tmdbFetch<{ genres: { id: number; name: string }[] }>('/genre/movie/list', { language: 'en-US' }),
    tmdbFetch<{ genres: { id: number; name: string }[] }>('/genre/tv/list', { language: 'en-US' }),
    tmdbFetch<{ iso_639_1: string; english_name: string; name: string }[]>('/configuration/languages'),
    tmdbFetch<{ iso_3166_1: string; english_name: string }[]>('/configuration/countries'),
    anilistFetch<{ GenreCollection: string[] }>(`query { GenreCollection }`),
  ]);

  // 1. Merge Genres
  const genreMap = new Map<
    string,
    {
      name: string;
      inMovie: boolean;
      inTv: boolean;
      inAnime: boolean;
      tmdbMovieId?: number;
      tmdbTvId?: number;
    }
  >();

  const ensureGenre = (rawName: string) => {
    const name = normalizeGenreName(rawName);
    const key = name.toLowerCase();
    if (!genreMap.has(key)) {
      genreMap.set(key, { name, inMovie: false, inTv: false, inAnime: false });
    }
    return genreMap.get(key)!;
  };

  if (tmdbMovieGenres?.genres?.length) {
    for (const g of tmdbMovieGenres.genres) {
      const entry = ensureGenre(g.name);
      entry.inMovie = true;
      if (!entry.tmdbMovieId) entry.tmdbMovieId = g.id;
    }
  }
  if (tmdbTvGenres?.genres?.length) {
    for (const g of tmdbTvGenres.genres) {
      const entry = ensureGenre(g.name);
      entry.inTv = true;
      if (!entry.tmdbTvId) entry.tmdbTvId = g.id;
      // Handle TMDB compound genres so Drama/Fantasy/Adventure also get IDs
      if (g.name === 'Sci-Fi & Fantasy') {
        const fantasy = ensureGenre('Fantasy');
        fantasy.inTv = true;
        if (!fantasy.tmdbTvId) fantasy.tmdbTvId = g.id;
      }
      if (g.name === 'Action & Adventure') {
        const adv = ensureGenre('Adventure');
        adv.inTv = true;
        if (!adv.tmdbTvId) adv.tmdbTvId = g.id;
      }
    }
  }

  // If TMDB failed/unconfigured, seed from fallback movie/tv genres
  if (!tmdbMovieGenres?.genres?.length && !tmdbTvGenres?.genres?.length) {
    for (const fg of FALLBACK_GENRES) {
      const entry = ensureGenre(fg.name);
      entry.inMovie = fg.types.includes('movies');
      entry.inTv = fg.types.includes('series') || fg.types.includes('dramas');
      entry.inAnime = fg.types.includes('anime');
      entry.tmdbMovieId = fg.tmdbMovieId;
      entry.tmdbTvId = fg.tmdbTvId;
    }
  }

  if (anilistGenresRes?.GenreCollection?.length) {
    for (const g of anilistGenresRes.GenreCollection) {
      if (g.toLowerCase() === 'hentai') continue;
      const entry = ensureGenre(g);
      entry.inAnime = true;
    }
    // Ensure Isekai (top AniList tag) is included for Anime
    const isekai = ensureGenre('Isekai');
    isekai.inAnime = true;
  } else {
    for (const fg of FALLBACK_GENRES.filter((x) => x.types.includes('anime'))) {
      const entry = ensureGenre(fg.name);
      entry.inAnime = true;
    }
  }

  const genres: GenreOption[] = Array.from(genreMap.values())
    .map((g) => ({
      name: g.name,
      types: classifyGenreTypes(g.name, g.inMovie, g.inTv, g.inAnime),
      tmdbMovieId: g.tmdbMovieId,
      tmdbTvId: g.tmdbTvId,
      isAnimeSpecific: ANIME_SPECIFIC_GENRES.has(g.name.toLowerCase()),
    }))
    .sort((a, b) => a.name.localeCompare(b.name));

  // 2. Order Languages
  const langMap = new Map<string, LanguageOption>();
  const sourceLanguages = tmdbLanguages?.length ? tmdbLanguages : null;
  if (sourceLanguages) {
    for (const l of sourceLanguages) {
      if (!l.iso_639_1 || !l.english_name || l.english_name === 'No Language') continue;
      const displayName = l.iso_639_1 === 'zh' ? 'Mandarin Chinese' : l.english_name;
      langMap.set(l.iso_639_1, {
        code: l.iso_639_1,
        englishName: displayName,
        nativeName: l.name || undefined,
      });
    }
  }
  for (const fl of FALLBACK_LANGUAGES) {
    if (!langMap.has(fl.code)) {
      langMap.set(fl.code, fl);
    }
  }

  const popularLangs: LanguageOption[] = [];
  for (const code of POPULAR_LANGUAGE_CODES) {
    const found = langMap.get(code);
    if (found) popularLangs.push(found);
  }
  const popularLangSet = new Set<string>(POPULAR_LANGUAGE_CODES);
  const otherLangs = Array.from(langMap.values())
    .filter((l) => !popularLangSet.has(l.code))
    .sort((a, b) => a.englishName.localeCompare(b.englishName));
  const languages = [...popularLangs, ...otherLangs];

  // 3. Order Countries
  const countryMap = new Map<string, CountryOption>();
  if (tmdbCountries?.length) {
    for (const c of tmdbCountries) {
      if (!c.iso_3166_1 || !c.english_name) continue;
      let name = c.english_name;
      if (c.iso_3166_1 === 'KR') name = 'Korea';
      if (c.iso_3166_1 === 'US') name = 'USA';
      countryMap.set(c.iso_3166_1, { code: c.iso_3166_1, name });
    }
  } else {
    for (const fc of FALLBACK_COUNTRIES) {
      let name = fc.name;
      if (fc.code === 'KR') name = 'Korea';
      if (fc.code === 'US') name = 'USA';
      countryMap.set(fc.code, { code: fc.code, name });
    }
  }

  const popularCountries: CountryOption[] = [];
  for (const code of POPULAR_COUNTRY_CODES) {
    const found = countryMap.get(code);
    if (found) popularCountries.push(found);
  }
  const popularCountrySet = new Set<string>(POPULAR_COUNTRY_CODES);
  const otherCountries = Array.from(countryMap.values())
    .filter((c) => !popularCountrySet.has(c.code))
    .sort((a, b) => a.name.localeCompare(b.name));
  const countries = [...popularCountries, ...otherCountries];

  cachedOptions = {
    genres,
    languages,
    countries,
    tmdbConfigured: isTmdbConfigured(),
    cachedAt: now,
  };
  return cachedOptions;
}

interface TmdbGenreLookup {
  movieMap: Map<number, string>;
  tvMap: Map<number, string>;
}

let cachedGenreLookup: TmdbGenreLookup | null = null;
async function getTmdbGenreLookup(): Promise<TmdbGenreLookup> {
  if (cachedGenreLookup) return cachedGenreLookup;
  const movieMap = new Map<number, string>();
  const tvMap = new Map<number, string>();
  for (const g of FALLBACK_GENRES) {
    if (g.tmdbMovieId) movieMap.set(g.tmdbMovieId, g.name);
    if (g.tmdbTvId) tvMap.set(g.tmdbTvId, g.name);
  }
  const [mRes, tvRes] = await Promise.all([
    tmdbFetch<{ genres: { id: number; name: string }[] }>('/genre/movie/list', { language: 'en-US' }),
    tmdbFetch<{ genres: { id: number; name: string }[] }>('/genre/tv/list', { language: 'en-US' }),
  ]);
  for (const g of mRes?.genres || []) movieMap.set(g.id, normalizeGenreName(g.name));
  for (const g of tvRes?.genres || []) tvMap.set(g.id, normalizeGenreName(g.name));
  if (mRes?.genres?.length || tvRes?.genres?.length) {
    cachedGenreLookup = { movieMap, tvMap };
  }
  return { movieMap, tvMap };
}

interface AniListMediaNode {
  id: number;
  title: { english?: string | null; romaji?: string | null; native?: string | null };
  seasonYear?: number | null;
  startDate?: { year?: number | null } | null;
  coverImage?: { large?: string | null; extraLarge?: string | null } | null;
  bannerImage?: string | null;
  genres?: string[] | null;
  averageScore?: number | null;
  description?: string | null;
  episodes?: number | null;
  duration?: number | null;
  countryOfOrigin?: string | null;
  externalLinks?: { site: string; url: string }[] | null;
}

function mapAniListToMedia(node: AniListMediaNode, reason = ''): MediaRecommendation {
  const title = node.title.english || node.title.romaji || node.title.native || 'Untitled Anime';
  const year = String(node.seasonYear || node.startDate?.year || '');
  const rating = node.averageScore ? Math.round((node.averageScore / 10) * 10) / 10 : 7.5;
  return {
    externalId: `anilist-${node.id}`,
    source: 'anilist',
    mediaType: 'anime',
    title,
    year,
    posterUrl: node.coverImage?.extraLarge || node.coverImage?.large || '',
    backdropUrl: node.bannerImage || undefined,
    genres: (node.genres || []).slice(0, 4),
    rating,
    overview: summarizeSentences(node.description || ''),
    reason,
  };
}

interface TmdbSearchItem {
  id: number;
  media_type?: 'movie' | 'tv' | 'person';
  title?: string;
  name?: string;
  original_title?: string;
  original_name?: string;
  release_date?: string;
  first_air_date?: string;
  poster_path?: string | null;
  backdrop_path?: string | null;
  genre_ids?: number[];
  vote_average?: number;
  overview?: string;
  original_language?: string;
  origin_country?: string[];
}

function mapTmdbToMedia(
  item: TmdbSearchItem,
  kind: 'movie' | 'tv',
  lookup: TmdbGenreLookup,
  mediaTypeOverride?: 'movie' | 'series' | 'drama',
  reason = ''
): MediaRecommendation {
  const title = item.title || item.name || item.original_title || item.original_name || 'Untitled';
  const date = item.release_date || item.first_air_date || '';
  const year = date ? date.slice(0, 4) : '';
  const gMap = kind === 'movie' ? lookup.movieMap : lookup.tvMap;
  const genres = (item.genre_ids || [])
    .map((id) => gMap.get(id))
    .filter((x): x is string => Boolean(x))
    .slice(0, 4);
  const isDrama = mediaTypeOverride === 'drama' || (kind === 'tv' && (item.genre_ids || []).includes(18));
  const mediaType: MediaRecommendation['mediaType'] =
    kind === 'movie' ? 'movie' : isDrama ? 'drama' : 'series';

  return {
    externalId: `tmdb-${kind}-${item.id}`,
    source: 'tmdb',
    mediaType,
    title,
    year,
    posterUrl: item.poster_path ? `${TMDB_IMG_POSTER}${item.poster_path}` : '',
    backdropUrl: item.backdrop_path ? `${TMDB_IMG_BACKDROP}${item.backdrop_path}` : undefined,
    genres,
    rating: item.vote_average ? Math.round(item.vote_average * 10) / 10 : 0,
    overview: summarizeSentences(item.overview || ''),
    reason,
  };
}

export async function getTrendingMedia(): Promise<{ items: MediaRecommendation[]; tmdbConfigured: boolean }> {
  const lookup = await getTmdbGenreLookup();
  const [tmdbRes, anilistRes] = await Promise.all([
    tmdbFetch<{ results: TmdbSearchItem[] }>('/trending/all/week', { language: 'en-US' }),
    anilistFetch<{ Page: { media: AniListMediaNode[] } }>(
      `query {
        Page(page: 1, perPage: 10) {
          media(type: ANIME, sort: TRENDING_DESC, isAdult: false) {
            id
            title { english romaji native }
            seasonYear
            startDate { year }
            coverImage { large extraLarge }
            bannerImage
            genres
            averageScore
            description(asHtml: false)
          }
        }
      }`
    ),
  ]);

  const tmdbItems: MediaRecommendation[] = (tmdbRes?.results || [])
    .filter((r) => (r.media_type === 'movie' || r.media_type === 'tv') && r.poster_path)
    .slice(0, 10)
    .map((r) => mapTmdbToMedia(r, r.media_type === 'movie' ? 'movie' : 'tv', lookup));

  const animeItems: MediaRecommendation[] = (anilistRes?.Page?.media || [])
    .filter((m) => m.coverImage?.large || m.coverImage?.extraLarge)
    .slice(0, 8)
    .map((m) => mapAniListToMedia(m));

  const combined: MediaRecommendation[] = [];
  const maxLen = Math.max(tmdbItems.length, animeItems.length);
  for (let i = 0; i < maxLen; i++) {
    if (tmdbItems[i]) combined.push(tmdbItems[i]);
    if (animeItems[i]) combined.push(animeItems[i]);
  }

  return {
    items: combined.slice(0, 14),
    tmdbConfigured: isTmdbConfigured(),
  };
}

export interface CandidateTitle {
  title: string;
  year?: string;
  mediaType: 'movie' | 'series' | 'drama' | 'anime';
  reason: string;
  basedOnTitle?: string;
}

const VALID_ANILIST_GENRES = new Set([
  'Action',
  'Adventure',
  'Comedy',
  'Drama',
  'Ecchi',
  'Fantasy',
  'Horror',
  'Mahou Shoujo',
  'Mecha',
  'Music',
  'Mystery',
  'Psychological',
  'Romance',
  'Sci-Fi',
  'Slice of Life',
  'Sports',
  'Supernatural',
  'Thriller',
]);

const MOOD_GENRE_HINTS: Record<string, string[]> = {
  Happy: ['comedy', 'adventure', 'family', 'music', 'slice of life', 'fantasy'],
  Sad: ['drama', 'romance', 'war', 'history', 'psychological'],
  Romantic: ['romance', 'drama', 'comedy'],
  Thrilling: ['thriller', 'action', 'mystery', 'crime', 'horror', 'sci-fi', 'psychological'],
  Relaxed: ['slice of life', 'comedy', 'family', 'animation', 'music', 'documentary'],
};

function titlesMatch(a: string, b: string): boolean {
  const norm = (s: string) =>
    s
      .toLowerCase()
      .replace(/[:\-–—'".!?]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  const na = norm(a);
  const nb = norm(b);
  if (!na || !nb) return false;
  return na === nb || na.includes(nb) || nb.includes(na);
}

function yearMatches(targetYear: string | undefined, dbYear: string): boolean {
  if (!targetYear || !dbYear) return true;
  const ty = parseInt(targetYear, 10);
  const dy = parseInt(dbYear, 10);
  if (Number.isNaN(ty) || Number.isNaN(dy)) return true;
  return Math.abs(ty - dy) <= 2;
}

const CROSS_MEDIUM_GENRE_ALIASES: Record<string, string[]> = {
  fantasy: ['sci-fi'],
  'sci-fi': ['fantasy'],
  adventure: ['action'],
  action: ['adventure'],
  thriller: ['crime', 'mystery', 'action'],
  horror: ['mystery', 'sci-fi', 'supernatural', 'thriller'],
  romance: ['drama', 'comedy'],
  psychological: ['thriller', 'mystery', 'drama', 'crime'],
  supernatural: ['sci-fi', 'fantasy', 'mystery', 'horror'],
  'slice of life': ['comedy', 'drama'],
  isekai: ['fantasy', 'adventure'],
  sports: ['drama', 'action'],
  music: ['drama', 'comedy'],
  history: ['drama', 'war'],
};

const TV_CROSS_GENRE_FALLBACK_IDS: Record<string, number[]> = {
  romance: [18, 35],
  thriller: [80, 9648, 10759],
  horror: [9648, 10765],
  history: [18, 10768],
  music: [18, 35],
  psychological: [80, 9648, 18],
  supernatural: [10765, 9648],
  'slice of life': [35, 18],
  isekai: [16, 10765],
  sports: [18],
};

function hasGenreOverlap(itemGenres: string[], requestedGenres: string[]): boolean {
  if (!requestedGenres.length) return true;
  if (!itemGenres.length) return false;
  const normSet = new Set(itemGenres.map((g) => normalizeGenreName(g).toLowerCase()));
  return requestedGenres.some((rg) => {
    const lower = normalizeGenreName(rg).toLowerCase();
    if (normSet.has(lower)) return true;
    const aliases = CROSS_MEDIUM_GENRE_ALIASES[lower];
    return Boolean(aliases?.some((a) => normSet.has(a)));
  });
}

function scoreMediaRelevance(
  item: MediaRecommendation,
  prefs: Partial<PreferencesInput>,
  meta?: { originalLanguage?: string; originCountries?: string[]; rawOverview?: string }
): number {
  let score = 1;
  const itemGenresLower = new Set(item.genres.map((g) => normalizeGenreName(g).toLowerCase()));

  if (prefs.genres?.length) {
    let genreHits = 0;
    for (const g of prefs.genres) {
      if (itemGenresLower.has(normalizeGenreName(g).toLowerCase())) {
        genreHits += 1;
      }
    }
    score += genreHits * 4;
  }

  const activeMoods = (prefs.moods || []).filter((m) => m !== 'Surprise me');
  for (const mood of activeMoods) {
    const hints = MOOD_GENRE_HINTS[mood] || [];
    if (hints.some((h) => itemGenresLower.has(h))) {
      score += 2;
    }
  }

  if (prefs.languages?.length && meta?.originalLanguage && prefs.languages.includes(meta.originalLanguage)) {
    score += 2;
  }
  if (
    prefs.countries?.length &&
    !prefs.countries.includes('ANY') &&
    meta?.originCountries?.some((c) => prefs.countries!.includes(c))
  ) {
    score += 2;
  }

  if (prefs.storyPreference?.trim()) {
    const words = prefs.storyPreference
      .toLowerCase()
      .split(/\s+/)
      .filter((w) => w.length >= 4);
    const haystack = `${item.title} ${meta?.rawOverview || item.overview}`.toLowerCase();
    for (const w of words.slice(0, 8)) {
      if (haystack.includes(w)) score += 3;
    }
  }

  score += Math.min(2, (item.rating || 0) / 5);
  return score;
}

export async function verifyCandidateInDatabases(
  candidate: CandidateTitle,
  prefs?: Partial<PreferencesInput>,
  strictChecks?: { checkLanguage: boolean; checkCountry: boolean; checkYear: boolean; checkGenres?: boolean }
): Promise<MediaRecommendation | null> {
  const lookup = await getTmdbGenreLookup();

  if (candidate.mediaType === 'anime') {
    const data = await anilistFetch<{ Page: { media: AniListMediaNode[] } }>(
      `query ($search: String) {
        Page(page: 1, perPage: 6) {
          media(search: $search, type: ANIME, isAdult: false, sort: POPULARITY_DESC) {
            id
            title { english romaji native }
            seasonYear
            startDate { year }
            coverImage { large extraLarge }
            bannerImage
            genres
            averageScore
            description(asHtml: false)
            episodes
            duration
            countryOfOrigin
          }
        }
      }`,
      { search: candidate.title }
    );
    const nodes = data?.Page?.media || [];
    const match = nodes.find((n) => {
      const y = String(n.seasonYear || n.startDate?.year || '');
      const tMatch =
        titlesMatch(n.title.english || '', candidate.title) ||
        titlesMatch(n.title.romaji || '', candidate.title) ||
        titlesMatch(n.title.native || '', candidate.title);
      return tMatch && yearMatches(candidate.year, y);
    });

    if (!match) return null;

    if (strictChecks?.checkYear && prefs?.releasePeriod && !prefs.releasePeriod.anyYear) {
      const y = match.seasonYear || match.startDate?.year;
      if (y && (y < prefs.releasePeriod.fromYear || y > prefs.releasePeriod.toYear)) {
        return null;
      }
    }
    if (prefs?.minRating && match.averageScore) {
      if (match.averageScore / 10 < prefs.minRating) return null;
    }
    if (strictChecks?.checkCountry && prefs?.countries?.length && !prefs.countries.includes('ANY')) {
      const origin = match.countryOfOrigin || 'JP';
      if (!prefs.countries.includes(origin)) return null;
    }
    if (strictChecks?.checkLanguage && prefs?.languages?.length && !prefs.subtitlesFine) {
      const animeLang = match.countryOfOrigin === 'CN' ? 'zh' : match.countryOfOrigin === 'KR' ? 'ko' : 'ja';
      if (!prefs.languages.includes(animeLang)) return null;
    }

    const mapped = mapAniListToMedia(match, candidate.reason);
    if (
      strictChecks?.checkGenres !== false &&
      prefs?.genres?.length &&
      prefs.genres.length < 15 &&
      !hasGenreOverlap(mapped.genres, prefs.genres)
    ) {
      return null;
    }

    if (candidate.basedOnTitle) mapped.basedOnTitle = candidate.basedOnTitle;
    return mapped;
  }

  // TMDB verification for movie / series / drama
  if (!isTmdbConfigured()) return null;

  const isMovie = candidate.mediaType === 'movie';
  const endpoint = isMovie ? '/search/movie' : '/search/tv';
  const res = await tmdbFetch<{ results: TmdbSearchItem[] }>(endpoint, {
    query: candidate.title,
    include_adult: 'false',
    language: 'en-US',
  });
  const results = res?.results || [];
  if (!results.length) return null;

  const match = results.find((r) => {
    const rTitle = r.title || r.name || r.original_title || r.original_name || '';
    const rYear = (r.release_date || r.first_air_date || '').slice(0, 4);
    return titlesMatch(rTitle, candidate.title) && yearMatches(candidate.year, rYear);
  });

  if (!match) return null;

  // Enforce Drama genre when requested type is strictly 'Dramas'
  if (prefs?.type === 'Dramas' && !(match.genre_ids || []).includes(18)) {
    return null;
  }

  const rYearNum = parseInt((match.release_date || match.first_air_date || '').slice(0, 4), 10);
  if (strictChecks?.checkYear && prefs?.releasePeriod && !prefs.releasePeriod.anyYear && !Number.isNaN(rYearNum)) {
    if (rYearNum < prefs.releasePeriod.fromYear || rYearNum > prefs.releasePeriod.toYear) {
      return null;
    }
  }
  if (prefs?.minRating && match.vote_average && match.vote_average < prefs.minRating) {
    return null;
  }
  if (strictChecks?.checkLanguage && prefs?.languages?.length && !prefs.subtitlesFine) {
    if (match.original_language && !prefs.languages.includes(match.original_language)) {
      return null;
    }
  }
  if (strictChecks?.checkCountry && prefs?.countries?.length && !prefs.countries.includes('ANY')) {
    if (match.origin_country?.length) {
      const hasCountry = match.origin_country.some((c) => prefs.countries!.includes(c));
      if (!hasCountry) return null;
    }
  }

  const mapped = mapTmdbToMedia(
    match,
    isMovie ? 'movie' : 'tv',
    lookup,
    candidate.mediaType === 'drama' ? 'drama' : isMovie ? 'movie' : 'series',
    candidate.reason
  );

  if (
    strictChecks?.checkGenres !== false &&
    prefs?.genres?.length &&
    prefs.genres.length < 15 &&
    !hasGenreOverlap(mapped.genres, prefs.genres)
  ) {
    return null;
  }

  if (candidate.basedOnTitle) mapped.basedOnTitle = candidate.basedOnTitle;
  return mapped;
}

export async function discoverFallbackFromDatabases(
  prefs: PreferencesInput,
  options: {
    useDuration: boolean;
    useYear: boolean;
    useCountry: boolean;
    useLanguage: boolean;
    useGenres?: boolean;
  },
  excludeIds: Set<string>,
  needed: number
): Promise<MediaRecommendation[]> {
  const scoredPool: { item: MediaRecommendation; score: number }[] = [];
  const catalog = await getCatalogOptions();
  const lookup = await getTmdbGenreLookup();

  const wantAnime = prefs.type === 'Anime' || prefs.type === 'Anything';
  const wantMovies = prefs.type === 'Movies' || prefs.type === 'Anything';
  const wantTv = prefs.type === 'Series' || prefs.type === 'Dramas' || prefs.type === 'Anything';
  const applyGenres = options.useGenres !== false && prefs.genres.length > 0;

  const activeLanguages =
    options.useLanguage && prefs.languages.length > 0 && !prefs.subtitlesFine
      ? prefs.languages.slice(0, 12)
      : [];
  const countryParam =
    options.useCountry && prefs.countries.length > 0 && !prefs.countries.includes('ANY')
      ? prefs.countries.slice(0, 12).join('|')
      : undefined;
  const isNarrowQuery =
    activeLanguages.some((l) => l !== 'en') ||
    Boolean(countryParam) ||
    (options.useYear && !prefs.releasePeriod.anyYear);

  const selectedGenreLower = new Set(prefs.genres.map((g) => g.toLowerCase()));
  const movieGenreIds = applyGenres
    ? catalog.genres
        .filter((g) => selectedGenreLower.has(g.name.toLowerCase()) && g.tmdbMovieId)
        .map((g) => g.tmdbMovieId!)
    : [];
  const tvGenreIdsSet = new Set<number>();
  if (applyGenres) {
    for (const g of catalog.genres) {
      if (selectedGenreLower.has(g.name.toLowerCase())) {
        if (g.tmdbTvId) tvGenreIdsSet.add(g.tmdbTvId);
        const cross = TV_CROSS_GENRE_FALLBACK_IDS[g.name.toLowerCase()];
        if (cross) {
          for (const cid of cross) tvGenreIdsSet.add(cid);
        }
      }
    }
  }
  const tvGenreIds = Array.from(tvGenreIdsSet);

  // When 2+ languages are selected, query top languages individually in parallel so English doesn't drown out regional languages
  const languageSlices: (string | undefined)[] =
    activeLanguages.length > 1
      ? activeLanguages.slice(0, 3)
      : [activeLanguages.length === 1 ? activeLanguages[0] : undefined];

  const tasks: Promise<void>[] = [];

  if (wantMovies && isTmdbConfigured()) {
    for (const sliceLang of languageSlices) {
      tasks.push(
        (async () => {
          const params: Record<string, string | number | undefined> = {
            sort_by: 'popularity.desc',
            include_adult: 'false',
            'vote_count.gte': isNarrowQuery ? 5 : 25,
            with_original_language: sliceLang,
            with_origin_country: countryParam,
            with_genres: movieGenreIds.length ? Array.from(new Set(movieGenreIds)).join('|') : undefined,
            'vote_average.gte': prefs.minRating ?? undefined,
          };
          if (options.useYear && !prefs.releasePeriod.anyYear) {
            params['primary_release_date.gte'] = `${prefs.releasePeriod.fromYear}-01-01`;
            params['primary_release_date.lte'] = `${prefs.releasePeriod.toYear}-12-31`;
          }
          if (options.useDuration && prefs.duration) {
            if (prefs.duration === 'Short') params['with_runtime.lte'] = 90;
            if (prefs.duration === 'Medium') {
              params['with_runtime.gte'] = 90;
              params['with_runtime.lte'] = 120;
            }
            if (prefs.duration === 'Long') params['with_runtime.gte'] = 120;
          }
          const res = await tmdbFetch<{ results: TmdbSearchItem[] }>('/discover/movie', params);
          for (const item of res?.results || []) {
            const mapped = mapTmdbToMedia(
              item,
              'movie',
              lookup,
              'movie',
              'Verified TMDB match selected for your active filters.'
            );
            if (!excludeIds.has(mapped.externalId) && mapped.posterUrl) {
              if (applyGenres && prefs.genres.length < 15 && !hasGenreOverlap(mapped.genres, prefs.genres)) {
                continue;
              }
              scoredPool.push({
                item: mapped,
                score: scoreMediaRelevance(mapped, prefs, {
                  originalLanguage: item.original_language,
                  originCountries: item.origin_country,
                  rawOverview: item.overview,
                }),
              });
            }
          }
        })()
      );
    }
  }

  if (wantTv && isTmdbConfigured()) {
    for (const sliceLang of languageSlices) {
      tasks.push(
        (async () => {
          const tvGenreParam =
            prefs.type === 'Dramas'
              ? '18'
              : tvGenreIds.length
              ? tvGenreIds.join('|')
              : undefined;
          const params: Record<string, string | number | undefined> = {
            sort_by: 'popularity.desc',
            include_adult: 'false',
            'vote_count.gte': isNarrowQuery ? 5 : 20,
            with_original_language: sliceLang,
            with_origin_country: countryParam,
            with_genres: tvGenreParam,
            'vote_average.gte': prefs.minRating ?? undefined,
          };
          if (options.useYear && !prefs.releasePeriod.anyYear) {
            params['first_air_date.gte'] = `${prefs.releasePeriod.fromYear}-01-01`;
            params['first_air_date.lte'] = `${prefs.releasePeriod.toYear}-12-31`;
          }
          const res = await tmdbFetch<{ results: TmdbSearchItem[] }>('/discover/tv', params);
          for (const item of res?.results || []) {
            const mapped = mapTmdbToMedia(
              item,
              'tv',
              lookup,
              prefs.type === 'Dramas' ? 'drama' : 'series',
              'Verified TMDB series match based on your filters.'
            );
            if (!excludeIds.has(mapped.externalId) && mapped.posterUrl) {
              if (
                applyGenres &&
                prefs.genres.length < 15 &&
                !hasGenreOverlap(mapped.genres, prefs.genres)
              ) {
                continue;
              }
              scoredPool.push({
                item: mapped,
                score: scoreMediaRelevance(mapped, prefs, {
                  originalLanguage: item.original_language,
                  originCountries: item.origin_country,
                  rawOverview: item.overview,
                }),
              });
            }
          }
        })()
      );
    }
  }

  if (wantAnime) {
    tasks.push(
      (async () => {
        const canonicalAniGenres = applyGenres
          ? prefs.genres
              .map((g) => normalizeGenreName(g))
              .filter((g) => VALID_ANILIST_GENRES.has(g))
          : [];
        const hasIsekai = applyGenres && prefs.genres.some((g) => g.toLowerCase() === 'isekai');
        const aniCountries =
          options.useCountry && prefs.countries.length > 0 && !prefs.countries.includes('ANY')
            ? prefs.countries.filter((c) => ['JP', 'KR', 'CN', 'TW'].includes(c))
            : [];

        const skipAnimeForCountry =
          options.useCountry &&
          prefs.countries.length > 0 &&
          !prefs.countries.includes('ANY') &&
          aniCountries.length === 0;
        const skipAnimeForLanguage =
          options.useLanguage &&
          prefs.languages.length > 0 &&
          !prefs.subtitlesFine &&
          !prefs.languages.some((l) => l === 'ja' || l === 'zh' || l === 'ko');

        if (skipAnimeForCountry || skipAnimeForLanguage) return;

        // AniList genre_in is AND; only pass genre_in when exactly 1 genre is picked, otherwise fetch broader pool and filter/score by OR overlap
        const aniVariables: Record<string, unknown> = {
          sort: ['POPULARITY_DESC'],
          genre_in: canonicalAniGenres.length === 1 ? canonicalAniGenres : undefined,
          tag_in: hasIsekai && canonicalAniGenres.length <= 1 ? ['Isekai'] : undefined,
          countryOfOrigin: aniCountries.length === 1 ? aniCountries[0] : undefined,
          averageScore_greater: prefs.minRating ? Math.round(prefs.minRating * 10) : undefined,
          startDate_greater:
            options.useYear && !prefs.releasePeriod.anyYear
              ? prefs.releasePeriod.fromYear * 10000 + 101
              : undefined,
          startDate_lesser:
            options.useYear && !prefs.releasePeriod.anyYear
              ? prefs.releasePeriod.toYear * 10000 + 1231
              : undefined,
        };
        if (options.useDuration && prefs.duration) {
          if (prefs.duration === 'Short') aniVariables.episodes_lesser = 14;
          if (prefs.duration === 'Medium') {
            aniVariables.episodes_greater = 12;
            aniVariables.episodes_lesser = 27;
          }
          if (prefs.duration === 'Long') aniVariables.episodes_greater = 27;
        }

        const res = await anilistFetch<{ Page: { media: AniListMediaNode[] } }>(
          `query ($sort: [MediaSort], $genre_in: [String], $tag_in: [String], $countryOfOrigin: CountryCode, $averageScore_greater: Int, $startDate_greater: FuzzyDateInt, $startDate_lesser: FuzzyDateInt, $episodes_greater: Int, $episodes_lesser: Int) {
            Page(page: 1, perPage: 40) {
              media(
                type: ANIME,
                isAdult: false,
                sort: $sort,
                genre_in: $genre_in,
                tag_in: $tag_in,
                countryOfOrigin: $countryOfOrigin,
                averageScore_greater: $averageScore_greater,
                startDate_greater: $startDate_greater,
                startDate_lesser: $startDate_lesser,
                episodes_greater: $episodes_greater,
                episodes_lesser: $episodes_lesser
              ) {
                id
                title { english romaji native }
                seasonYear
                startDate { year }
                coverImage { large extraLarge }
                bannerImage
                genres
                averageScore
                countryOfOrigin
                description(asHtml: false)
              }
            }
          }`,
          aniVariables
        );

        for (const node of res?.Page?.media || []) {
          const origin = node.countryOfOrigin || 'JP';
          if (aniCountries.length > 1 && !aniCountries.includes(origin)) continue;
          const mapped = mapAniListToMedia(
            node,
            'Verified AniList anime match for your active preferences.'
          );
          if (!excludeIds.has(mapped.externalId) && mapped.posterUrl) {
            if (
              applyGenres &&
              canonicalAniGenres.length > 0 &&
              prefs.genres.length < 15 &&
              !hasGenreOverlap(mapped.genres, canonicalAniGenres)
            ) {
              continue;
            }
            const nativeLang = origin === 'CN' ? 'zh' : origin === 'KR' ? 'ko' : 'ja';
            scoredPool.push({
              item: mapped,
              score: scoreMediaRelevance(mapped, prefs, {
                originalLanguage: nativeLang,
                originCountries: [origin],
                rawOverview: node.description || '',
              }),
            });
          }
        }
      })()
    );
  }

  await Promise.all(tasks);

  scoredPool.sort((a, b) => b.score - a.score);

  const picked: MediaRecommendation[] = [];
  const localSeen = new Set<string>(excludeIds);
  for (const entry of scoredPool) {
    if (localSeen.has(entry.item.externalId)) continue;
    localSeen.add(entry.item.externalId);
    picked.push(entry.item);
    if (picked.length >= needed) break;
  }

  return picked;
}

export async function getGuaranteedPopularFallback(
  requestedType: PreferencesInput['type'],
  excludeIds: Set<string>,
  needed: number
): Promise<MediaRecommendation[]> {
  if (needed <= 0) return [];
  const lookup = await getTmdbGenreLookup();
  const pool: MediaRecommendation[] = [];

  const wantMovies = requestedType === 'Movies' || requestedType === 'Anything';
  const wantTv = requestedType === 'Series' || requestedType === 'Dramas' || requestedType === 'Anything';
  const wantAnime = requestedType === 'Anime' || requestedType === 'Anything';

  const tasks: Promise<void>[] = [];

  if (wantMovies && isTmdbConfigured()) {
    tasks.push(
      (async () => {
        const [trendingMovies, topMovies] = await Promise.all([
          tmdbFetch<{ results: TmdbSearchItem[] }>('/trending/movie/week', { language: 'en-US' }),
          tmdbFetch<{ results: TmdbSearchItem[] }>('/movie/top_rated', { language: 'en-US', page: 1 }),
        ]);
        for (const item of [...(trendingMovies?.results || []), ...(topMovies?.results || [])]) {
          if (!item.poster_path) continue;
          pool.push(mapTmdbToMedia(item, 'movie', lookup, 'movie', 'Popular verified match from TMDB.'));
        }
      })()
    );
  }

  if (wantTv && isTmdbConfigured()) {
    tasks.push(
      (async () => {
        const [trendingTv, topTv] = await Promise.all([
          tmdbFetch<{ results: TmdbSearchItem[] }>('/trending/tv/week', { language: 'en-US' }),
          tmdbFetch<{ results: TmdbSearchItem[] }>('/tv/top_rated', { language: 'en-US', page: 1 }),
        ]);
        for (const item of [...(trendingTv?.results || []), ...(topTv?.results || [])]) {
          if (!item.poster_path) continue;
          if (requestedType === 'Dramas' && !(item.genre_ids || []).includes(18)) continue;
          pool.push(
            mapTmdbToMedia(
              item,
              'tv',
              lookup,
              requestedType === 'Dramas' ? 'drama' : 'series',
              'Popular verified match from TMDB.'
            )
          );
        }
      })()
    );
  }

  if (wantAnime) {
    tasks.push(
      (async () => {
        const res = await anilistFetch<{ Page: { media: AniListMediaNode[] } }>(
          `query {
            Page(page: 1, perPage: 20) {
              media(type: ANIME, sort: TRENDING_DESC, isAdult: false) {
                id
                title { english romaji native }
                seasonYear
                startDate { year }
                coverImage { large extraLarge }
                bannerImage
                genres
                averageScore
                countryOfOrigin
                description(asHtml: false)
              }
            }
          }`
        );
        for (const node of res?.Page?.media || []) {
          if (!node.coverImage?.large && !node.coverImage?.extraLarge) continue;
          pool.push(mapAniListToMedia(node, 'Popular verified match from AniList.'));
        }
      })()
    );
  }

  await Promise.all(tasks);

  const picked: MediaRecommendation[] = [];
  const localSeen = new Set<string>(excludeIds);
  for (const item of pool) {
    if (localSeen.has(item.externalId) || !item.posterUrl) continue;
    localSeen.add(item.externalId);
    picked.push(item);
    if (picked.length >= needed) break;
  }
  return picked;
}

export async function getMediaDetails(
  source: string,
  mediaType: string,
  rawId: string
): Promise<MediaDetails | null> {
  if (source === 'anilist') {
    const numericId = parseInt(rawId.replace(/^anilist-/, ''), 10);
    if (Number.isNaN(numericId)) return null;
    const data = await anilistFetch<{
      Media: AniListMediaNode & {
        characters?: {
          edges?: {
            role?: string;
            node?: { name?: { full?: string }; image?: { medium?: string } };
          }[];
        };
      };
    }>(
      `query ($id: Int) {
        Media(id: $id, type: ANIME) {
          id
          title { english romaji native }
          seasonYear
          startDate { year }
          coverImage { large extraLarge }
          bannerImage
          genres
          averageScore
          description(asHtml: false)
          episodes
          duration
          countryOfOrigin
          externalLinks { site url }
          characters(perPage: 8, sort: ROLE) {
            edges {
              role
              node {
                name { full }
                image { medium }
              }
            }
          }
        }
      }`,
      { id: numericId }
    );
    const m = data?.Media;
    if (!m) return null;

    const base = mapAniListToMedia(m);
    const runtimeParts: string[] = [];
    if (m.episodes) runtimeParts.push(`${m.episodes} episode${m.episodes === 1 ? '' : 's'}`);
    if (m.duration) runtimeParts.push(`${m.duration} min/ep`);

    const cast = (m.characters?.edges || [])
      .map((e) => ({
        name: e.node?.name?.full || '',
        role: e.role ? e.role.toLowerCase().replace('_', ' ') : 'Character',
        profileUrl: e.node?.image?.medium || undefined,
      }))
      .filter((c) => c.name);

    const streamingSites = new Set(['Crunchyroll', 'Netflix', 'Hulu', 'Amazon Prime Video', 'HIDIVE', 'Disney Plus', 'YouTube']);
    const watchProviders = (m.externalLinks || [])
      .filter((l) => streamingSites.has(l.site) && l.url.startsWith('https://'))
      .slice(0, 6)
      .map((l) => ({
        providerName: l.site,
        link: l.url,
        type: 'Stream',
      }));

    return {
      ...base,
      fullDescription: stripHtml(m.description) || base.overview,
      cast,
      runtimeOrEpisodes: runtimeParts.join(' · ') || 'Episode count unavailable',
      watchProviders,
      country: m.countryOfOrigin || 'JP',
      originalLanguage: m.countryOfOrigin === 'CN' ? 'Mandarin Chinese' : 'Japanese',
    };
  }

  // TMDB
  if (!isTmdbConfigured()) return null;
  const parts = rawId.split('-');
  const tmdbId = parseInt(parts[parts.length - 1], 10);
  if (Number.isNaN(tmdbId)) return null;

  const isMovie = mediaType === 'movie' || rawId.includes('-movie-');
  const endpoint = isMovie ? `/movie/${tmdbId}` : `/tv/${tmdbId}`;

  interface TmdbDetailRaw {
    id: number;
    title?: string;
    name?: string;
    release_date?: string;
    first_air_date?: string;
    poster_path?: string | null;
    backdrop_path?: string | null;
    genres?: { id: number; name: string }[];
    vote_average?: number;
    overview?: string;
    runtime?: number;
    episode_run_time?: number[];
    number_of_seasons?: number;
    number_of_episodes?: number;
    original_language?: string;
    production_countries?: { name: string }[];
    origin_country?: string[];
    credits?: {
      cast?: { name: string; character?: string; profile_path?: string | null }[];
    };
    'watch/providers'?: {
      results?: Record<
        string,
        {
          link?: string;
          flatrate?: { provider_name: string; logo_path?: string }[];
          rent?: { provider_name: string; logo_path?: string }[];
        }
      >;
    };
  }

  const d = await tmdbFetch<TmdbDetailRaw>(endpoint, {
    append_to_response: 'credits,watch/providers',
    language: 'en-US',
  });
  if (!d) return null;

  const title = d.title || d.name || 'Untitled';
  const year = (d.release_date || d.first_air_date || '').slice(0, 4);
  const genres = (d.genres || []).map((g) => normalizeGenreName(g.name));

  let runtimeOrEpisodes = '';
  if (isMovie) {
    runtimeOrEpisodes = d.runtime ? `${d.runtime} min` : 'Runtime unavailable';
  } else {
    const bits: string[] = [];
    if (d.number_of_seasons) bits.push(`${d.number_of_seasons} season${d.number_of_seasons === 1 ? '' : 's'}`);
    if (d.number_of_episodes) bits.push(`${d.number_of_episodes} episodes`);
    if (d.episode_run_time?.length) bits.push(`${d.episode_run_time[0]} min/ep`);
    runtimeOrEpisodes = bits.join(' · ') || 'Series length unavailable';
  }

  const cast = (d.credits?.cast || []).slice(0, 8).map((c) => ({
    name: c.name,
    role: c.character || 'Cast',
    profileUrl: c.profile_path ? `${TMDB_IMG_PROFILE}${c.profile_path}` : undefined,
  }));

  const wpResults = d['watch/providers']?.results || {};
  const regionData = wpResults.US || wpResults.IN || wpResults.GB || Object.values(wpResults)[0];
  const watchProviders: MediaDetails['watchProviders'] = [];
  if (regionData) {
    for (const p of regionData.flatrate || []) {
      watchProviders.push({
        providerName: p.provider_name,
        logoUrl: p.logo_path ? `${TMDB_IMG_LOGO}${p.logo_path}` : undefined,
        link: regionData.link,
        type: 'Stream',
      });
    }
    if (watchProviders.length < 4) {
      for (const p of (regionData.rent || []).slice(0, 4 - watchProviders.length)) {
        watchProviders.push({
          providerName: p.provider_name,
          logoUrl: p.logo_path ? `${TMDB_IMG_LOGO}${p.logo_path}` : undefined,
          link: regionData.link,
          type: 'Rent / Buy',
        });
      }
    }
  }

  return {
    externalId: `tmdb-${isMovie ? 'movie' : 'tv'}-${d.id}`,
    source: 'tmdb',
    mediaType: isMovie ? 'movie' : genres.includes('Drama') ? 'drama' : 'series',
    title,
    year,
    posterUrl: d.poster_path ? `${TMDB_IMG_POSTER}${d.poster_path}` : '',
    backdropUrl: d.backdrop_path ? `${TMDB_IMG_BACKDROP}${d.backdrop_path}` : undefined,
    genres: genres.slice(0, 5),
    rating: d.vote_average ? Math.round(d.vote_average * 10) / 10 : 0,
    overview: summarizeSentences(d.overview || ''),
    reason: '',
    fullDescription: d.overview || 'No full description available.',
    cast,
    runtimeOrEpisodes,
    watchProviders: watchProviders.slice(0, 6),
    country: d.production_countries?.[0]?.name || d.origin_country?.[0],
    originalLanguage: d.original_language?.toUpperCase(),
  };
}
