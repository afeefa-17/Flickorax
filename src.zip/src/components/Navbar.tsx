import { ChevronDown, LogOut, Menu, User, X, Bookmark } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { useAuth } from '../contexts/AuthContext.tsx';

export type AppRoute =
  | { page: 'home' }
  | { page: 'find' }
  | { page: 'watch-party'; mode?: 'hub' | 'create' | 'join' | 'room'; roomCode?: string }
  | { page: 'surprise' }
  | { page: 'watchlist' };

interface NavbarProps {
  currentRoute: AppRoute;
  onNavigate: (route: AppRoute) => void;
}

export const LOGO_URL = '/src/assets/images/flickorax_logo_1795507977537.jpg';

export function Navbar({ currentRoute, onNavigate }: NavbarProps) {
  const { isLoggedIn, displayName, logOut, openAuthModal } = useAuth();
  const [partyMenuOpen, setPartyMenuOpen] = useState(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const partyRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (partyRef.current && !partyRef.current.contains(e.target as Node)) {
        setPartyMenuOpen(false);
      }
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) {
        setProfileMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const go = (route: AppRoute) => {
    setPartyMenuOpen(false);
    setProfileMenuOpen(false);
    setMobileMenuOpen(false);
    onNavigate(route);
  };

  const navLinkClass = (active: boolean) =>
    `text-sm font-medium whitespace-nowrap shrink-0 transition-colors duration-150 py-1 border-b-2 ${
      active
        ? 'text-white border-[#8C1A35]'
        : 'text-neutral-300 border-transparent hover:text-white hover:border-[#6D0F25]'
    }`;

  return (
    <header className="sticky top-0 z-40 w-full bg-black/90 backdrop-blur-md border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand */}
        <button
          type="button"
          onClick={() => go({ page: 'home' })}
          className="flex items-center gap-2.5 shrink-0 group cursor-pointer focus-visible:outline-[#8C1A35]"
        >
          <img
            src={LOGO_URL}
            alt="Flickorax logo"
            className="w-9 h-9 rounded-lg object-cover border border-white/15"
            referrerPolicy="no-referrer"
          />
          <span className="font-display text-xl font-bold tracking-tight text-white whitespace-nowrap">
            Flickorax
          </span>
        </button>

        {/* Zone 2: Exact Top Menu Order (Desktop) */}
        <nav className="hidden md:flex items-center gap-7" aria-label="Primary Navigation">
          <button
            type="button"
            onClick={() => go({ page: 'home' })}
            className={navLinkClass(currentRoute.page === 'home')}
          >
            Home
          </button>

          <button
            type="button"
            onClick={() => go({ page: 'find' })}
            className={navLinkClass(currentRoute.page === 'find')}
          >
            Find Content
          </button>

          {/* Watch Party Dropdown: Create Room, Join Room */}
          <div className="relative" ref={partyRef}>
            <button
              type="button"
              onClick={() => setPartyMenuOpen((v) => !v)}
              aria-expanded={partyMenuOpen}
              className={`flex items-center gap-1 ${navLinkClass(currentRoute.page === 'watch-party')}`}
            >
              <span>Watch Party</span>
              <ChevronDown className={`w-4 h-4 transition-transform ${partyMenuOpen ? 'rotate-180' : ''}`} />
            </button>
            {partyMenuOpen && (
              <div className="absolute left-0 mt-2 w-48 rounded-xl bg-[#111114] border border-white/12 shadow-2xl py-1.5 z-50">
                <button
                  type="button"
                  onClick={() => go({ page: 'watch-party', mode: 'create' })}
                  className="w-full text-left px-4 py-2.5 text-sm text-neutral-200 hover:bg-[#6D0F25] hover:text-white transition-colors"
                >
                  Create Room
                </button>
                <button
                  type="button"
                  onClick={() => go({ page: 'watch-party', mode: 'join' })}
                  className="w-full text-left px-4 py-2.5 text-sm text-neutral-200 hover:bg-[#6D0F25] hover:text-white transition-colors"
                >
                  Join Room
                </button>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() => go({ page: 'surprise' })}
            className={navLinkClass(currentRoute.page === 'surprise')}
          >
            Surprise Me
          </button>
        </nav>

        {/* Zone 3: Login/Sign Up OR Profile Menu (Desktop) + Mobile Hamburger */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="hidden md:block">
            {!isLoggedIn ? (
              <button
                type="button"
                onClick={() => openAuthModal()}
                className="px-4 py-2 rounded-xl bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] text-white text-sm font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer"
              >
                Login/Sign Up
              </button>
            ) : (
              <div className="relative" ref={profileRef}>
                <button
                  type="button"
                  onClick={() => setProfileMenuOpen((v) => !v)}
                  aria-expanded={profileMenuOpen}
                  className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#141418] hover:bg-[#1d1d22] border border-white/15 text-sm font-medium text-white whitespace-nowrap shrink-0 transition-colors cursor-pointer"
                >
                  <User className="w-4 h-4 text-[#8C1A35]" />
                  <span className="max-w-[140px] truncate">{displayName}</span>
                  <ChevronDown className={`w-4 h-4 transition-transform ${profileMenuOpen ? 'rotate-180' : ''}`} />
                </button>
                {profileMenuOpen && (
                  <div className="absolute right-0 mt-2 w-48 rounded-xl bg-[#111114] border border-white/12 shadow-2xl py-1.5 z-50">
                    <button
                      type="button"
                      onClick={() => go({ page: 'watchlist' })}
                      className="w-full flex items-center gap-2.5 text-left px-4 py-2.5 text-sm text-neutral-200 hover:bg-[#6D0F25] hover:text-white transition-colors"
                    >
                      <Bookmark className="w-4 h-4" />
                      <span>My Watchlist</span>
                    </button>
                    <button
                      type="button"
                      onClick={async () => {
                        setProfileMenuOpen(false);
                        await logOut();
                        if (currentRoute.page === 'watchlist') {
                          go({ page: 'home' });
                        }
                      }}
                      className="w-full flex items-center gap-2.5 text-left px-4 py-2.5 text-sm text-neutral-200 hover:bg-[#6D0F25] hover:text-white transition-colors"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Log out</span>
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={() => setMobileMenuOpen((v) => !v)}
            aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileMenuOpen}
            className="md:hidden p-2.5 rounded-xl bg-[#141418] border border-white/15 text-white hover:bg-[#6D0F25] transition-colors"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Collapsible Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0b0b0e] border-b border-white/10 px-4 py-4 space-y-1">
          <button
            type="button"
            onClick={() => go({ page: 'home' })}
            className="w-full text-left px-3 py-3 rounded-xl text-sm font-medium text-white hover:bg-[#6D0F25] transition-colors"
          >
            Home
          </button>
          <button
            type="button"
            onClick={() => go({ page: 'find' })}
            className="w-full text-left px-3 py-3 rounded-xl text-sm font-medium text-white hover:bg-[#6D0F25] transition-colors"
          >
            Find Content
          </button>
          <div className="px-3 pt-2 pb-1 text-xs font-medium text-neutral-400">Watch Party</div>
          <div className="pl-3 space-y-1">
            <button
              type="button"
              onClick={() => go({ page: 'watch-party', mode: 'create' })}
              className="w-full text-left px-3 py-2.5 rounded-xl text-sm text-neutral-200 hover:bg-[#6D0F25] hover:text-white transition-colors"
            >
              Create Room
            </button>
            <button
              type="button"
              onClick={() => go({ page: 'watch-party', mode: 'join' })}
              className="w-full text-left px-3 py-2.5 rounded-xl text-sm text-neutral-200 hover:bg-[#6D0F25] hover:text-white transition-colors"
            >
              Join Room
            </button>
          </div>
          <button
            type="button"
            onClick={() => go({ page: 'surprise' })}
            className="w-full text-left px-3 py-3 rounded-xl text-sm font-medium text-white hover:bg-[#6D0F25] transition-colors"
          >
            Surprise Me
          </button>

          <div className="pt-3 border-t border-white/10">
            {!isLoggedIn ? (
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  openAuthModal();
                }}
                className="w-full px-4 py-3 rounded-xl bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] text-white text-sm font-medium text-center transition-colors"
              >
                Login/Sign Up
              </button>
            ) : (
              <div className="space-y-1">
                <div className="px-3 py-2 text-xs text-neutral-400">Signed in as {displayName}</div>
                <button
                  type="button"
                  onClick={() => go({ page: 'watchlist' })}
                  className="w-full text-left px-3 py-3 rounded-xl text-sm font-medium text-white hover:bg-[#6D0F25] transition-colors"
                >
                  My Watchlist
                </button>
                <button
                  type="button"
                  onClick={async () => {
                    setMobileMenuOpen(false);
                    await logOut();
                    if (currentRoute.page === 'watchlist') {
                      go({ page: 'home' });
                    }
                  }}
                  className="w-full text-left px-3 py-3 rounded-xl text-sm font-medium text-neutral-300 hover:bg-[#6D0F25] hover:text-white transition-colors"
                >
                  Log out
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
