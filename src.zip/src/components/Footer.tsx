import type { AppRoute } from './Navbar.tsx';

export function Footer({ onNavigate }: { onNavigate: (route: AppRoute) => void }) {
  return (
    <footer className="border-t border-white/10 bg-[#050507] mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2.5">
            <img
              src="/src/assets/images/flickorax_logo_1795507977537.jpg"
              alt="Flickorax logo"
              className="w-7 h-7 rounded-md object-cover border border-white/15"
              referrerPolicy="no-referrer"
            />
            <span className="font-display font-bold text-white">Flickorax</span>
          </div>
          <p className="text-xs text-neutral-400">
            This product uses the TMDB API but is not endorsed or certified by TMDB.
          </p>
        </div>

        <nav className="flex flex-wrap items-center gap-6 text-sm text-neutral-400" aria-label="Footer Navigation">
          <button
            type="button"
            onClick={() => onNavigate({ page: 'home' })}
            className="hover:text-white transition-colors cursor-pointer"
          >
            Home
          </button>
          <button
            type="button"
            onClick={() => onNavigate({ page: 'find' })}
            className="hover:text-white transition-colors cursor-pointer"
          >
            Find Content
          </button>
          <button
            type="button"
            onClick={() => onNavigate({ page: 'watch-party', mode: 'hub' })}
            className="hover:text-white transition-colors cursor-pointer"
          >
            Watch Party
          </button>
          <button
            type="button"
            onClick={() => onNavigate({ page: 'surprise' })}
            className="hover:text-white transition-colors cursor-pointer"
          >
            Surprise Me
          </button>
        </nav>
      </div>
    </footer>
  );
}
