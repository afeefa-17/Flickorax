import { Bookmark, Check, Film, Info, Star } from 'lucide-react';
import { useState } from 'react';
import { useAuth } from '../contexts/AuthContext.tsx';
import type { MediaRecommendation } from '../types/flickorax.ts';

interface MediaCardProps {
  item: MediaRecommendation;
  reasonLabel?: string;
  onMoreDetails: (item: MediaRecommendation) => void;
  onRemove?: (externalId: string) => void;
}

const TYPE_LABELS: Record<MediaRecommendation['mediaType'], string> = {
  movie: 'Movie',
  series: 'Series',
  drama: 'Drama',
  anime: 'Anime',
};

export function MediaCard({ item, reasonLabel = 'Why this matches you', onMoreDetails, onRemove }: MediaCardProps) {
  const { isLoggedIn, isInWatchlist, addToWatchlist, removeFromWatchlist, openAuthModal } = useAuth();
  const [imgError, setImgError] = useState(false);
  const [saving, setSaving] = useState(false);

  const saved = isInWatchlist(item.externalId);

  const handleWatchlistClick = async () => {
    if (!isLoggedIn) {
      openAuthModal('Log in to save this');
      return;
    }
    setSaving(true);
    try {
      if (onRemove) {
        onRemove(item.externalId);
      } else if (saved) {
        await removeFromWatchlist(item.externalId);
      } else {
        await addToWatchlist(item);
      }
    } finally {
      setSaving(false);
    }
  };

  return (
    <article className="group rounded-2xl bg-[#0d0d10] border border-white/10 hover:border-[#6D0F25] overflow-hidden flex flex-col transition-all duration-200 hover:-translate-y-0.5">
      <div className="relative aspect-[2/3] w-full bg-[#141418] overflow-hidden">
        {item.posterUrl && !imgError ? (
          <img
            src={item.posterUrl}
            alt={item.title}
            loading="lazy"
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-4 text-center bg-gradient-to-b from-[#1a090e] to-black">
            <Film className="w-10 h-10 text-[#8C1A35] mb-2" />
            <span className="text-sm font-display font-semibold text-white line-clamp-2">{item.title}</span>
          </div>
        )}
        <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-black/90 via-black/40 to-transparent pointer-events-none" />
        <div className="absolute bottom-2.5 left-3 right-3 flex items-center justify-between text-xs text-white">
          <span className="font-medium">{TYPE_LABELS[item.mediaType]}</span>
          {item.rating > 0 && (
            <span className="flex items-center gap-1 font-mono-tabular font-semibold">
              <Star className="w-3.5 h-3.5 fill-[#8C1A35] text-[#8C1A35]" />
              {item.rating.toFixed(1)}
            </span>
          )}
        </div>
      </div>

      <div className="p-4 flex-1 flex flex-col gap-3">
        <div>
          {item.basedOnTitle && (
            <p className="text-xs font-medium text-[#d48b9b] mb-1">
              Because you liked {item.basedOnTitle}
            </p>
          )}
          <h3 className="font-display text-base font-semibold text-white leading-snug line-clamp-2">
            {item.title}
          </h3>
          <div className="flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-xs text-neutral-400 mt-1">
            {item.year && <span className="font-mono-tabular">{item.year}</span>}
            {item.year && item.genres.length > 0 && <span aria-hidden="true">·</span>}
            {item.genres.slice(0, 3).map((g, idx) => (
              <span key={g} className="inline-flex items-center gap-1.5">
                {idx > 0 && <span aria-hidden="true">·</span>}
                <span>{g}</span>
              </span>
            ))}
          </div>
        </div>

        <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed line-clamp-3">
          {item.overview}
        </p>

        {item.reason && (
          <div className="rounded-xl bg-[#160a0e] border border-[#6D0F25]/50 px-3 py-2.5 text-xs text-neutral-200 leading-relaxed">
            <span className="font-semibold text-white">{reasonLabel}: </span>
            {item.reason}
          </div>
        )}

        <div className="mt-auto pt-2 flex flex-col sm:flex-row gap-2">
          <button
            type="button"
            onClick={handleWatchlistClick}
            disabled={saving}
            className={`flex-1 px-3 py-2.5 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
              onRemove
                ? 'bg-[#1a1a20] hover:bg-[#6D0F25] text-white border border-white/15'
                : saved
                ? 'bg-[#4A0A19] text-white border border-[#8C1A35]'
                : 'bg-[#18181d] hover:bg-[#24242b] text-white border border-white/15'
            }`}
          >
            {onRemove ? (
              <span>Remove</span>
            ) : saved ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>In Watchlist</span>
              </>
            ) : (
              <>
                <Bookmark className="w-3.5 h-3.5" />
                <span>Add to Watchlist</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => onMoreDetails(item)}
            className="flex-1 px-3 py-2.5 rounded-xl bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] text-white text-xs font-medium flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap"
          >
            <Info className="w-3.5 h-3.5" />
            <span>More details</span>
          </button>
        </div>
      </div>
    </article>
  );
}
