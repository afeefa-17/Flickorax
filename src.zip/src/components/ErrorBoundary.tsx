import React from 'react';

interface State {
  hasError: boolean;
  message: string;
}

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, message: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, message: error.message || 'An unexpected error occurred.' };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-black text-white flex items-center justify-center p-6">
          <div className="max-w-md w-full rounded-2xl bg-[#0e0e11] border border-white/10 p-6 space-y-4">
            <h1 className="text-xl font-display font-semibold text-white">Something went wrong</h1>
            <p className="text-sm text-neutral-300 leading-relaxed">{this.state.message}</p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="px-5 py-2.5 rounded-xl bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] text-white text-sm font-medium transition-colors"
            >
              Reload Flickorax
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
