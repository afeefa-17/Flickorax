import { Check, ChevronDown, RotateCcw, Search, Sparkles, X } from 'lucide-react';
import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { POPULAR_COUNTRY_CODES, POPULAR_LANGUAGE_CODES } from '../data/fallbackOptions.ts';
import { loadCatalogOptions } from '../services/catalogService.ts';
import {
  createEmptyPreferences,
  CURRENT_YEAR,
  type CatalogOptionsResponse,
  type DurationChoice,
  type MediaTypeChoice,
  type MoodChoice,
  type PreferencesInput,
  type SavedPreferencesDoc,
} from '../types/flickorax.ts';

interface PreferencesFormProps {
  value: PreferencesInput;
  onChange: (next: PreferencesInput) => void;
  onSubmit: (prefs: PreferencesInput) => void;
  submitLabel?: string;
  loading?: boolean;
  disabled?: boolean;
  savedPreferences?: SavedPreferencesDoc | null;
  showSavedPrefsButton?: boolean;
}

const TYPE_OPTIONS: MediaTypeChoice[] = ['Movies', 'Anime', 'Series', 'Dramas', 'Anything'];
const MOOD_OPTIONS: MoodChoice[] = ['Happy', 'Sad', 'Romantic', 'Thrilling', 'Relaxed', 'Surprise me'];
const DURATION_OPTIONS: { value: DurationChoice; movieHint: string; seriesHint: string }[] = [
  { value: 'Short', movieHint: 'Under 90 min', seriesHint: 'Few episodes' },
  { value: 'Medium', movieHint: '90–120 min', seriesHint: 'One season' },
  { value: 'Long', movieHint: 'Over 120 min', seriesHint: 'Many seasons' },
];

export function PreferencesForm({
  value,
  onChange,
  onSubmit,
  submitLabel = 'Show Recommendations',
  loading = false,
  disabled = false,
  savedPreferences = null,
  showSavedPrefsButton = false,
}: PreferencesFormProps) {
  const [catalog, setCatalog] = useState<CatalogOptionsResponse | null>(null);
  const [langSearch, setLangSearch] = useState('');
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);
  const [countrySearch, setCountrySearch] = useState('');
  const [countryDropdownOpen, setCountryDropdownOpen] = useState(false);
  const [appliedSavedNotice, setAppliedSavedNotice] = useState(false);

  const langBoxRef = useRef<HTMLDivElement>(null);
  const countryBoxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadCatalogOptions().then(setCatalog);
  }, []);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (langBoxRef.current && !langBoxRef.current.contains(e.target as Node)) {
        setLangDropdownOpen(false);
      }
      if (countryBoxRef.current && !countryBoxRef.current.contains(e.target as Node)) {
        setCountryDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  const visibleGenres = useMemo(() => {
    if (!catalog) return [];
    const t = value.type;
    return catalog.genres.filter((g) => {
      if (t === 'Anything') return true;
      if (t === 'Movies') return g.types.includes('movies');
      if (t === 'Series') return g.types.includes('series');
      if (t === 'Dramas') return g.types.includes('dramas');
      if (t === 'Anime') return g.types.includes('anime');
      return true;
    });
  }, [catalog, value.type]);

  const popularLanguages = useMemo(() => {
    if (!catalog) return [];
    const popSet = new Set<string>(POPULAR_LANGUAGE_CODES);
    return catalog.languages.filter((l) => popSet.has(l.code));
  }, [catalog]);

  const filteredDropdownLanguages = useMemo(() => {
    if (!catalog) return [];
    const q = langSearch.trim().toLowerCase();
    return catalog.languages.filter(
      (l) =>
        !q ||
        l.englishName.toLowerCase().includes(q) ||
        (l.nativeName && l.nativeName.toLowerCase().includes(q)) ||
        l.code.toLowerCase().includes(q)
    );
  }, [catalog, langSearch]);

  const popularCountries = useMemo(() => {
    if (!catalog) return [];
    const popSet = new Set<string>(POPULAR_COUNTRY_CODES);
    return catalog.countries.filter((c) => popSet.has(c.code));
  }, [catalog]);

  const filteredDropdownCountries = useMemo(() => {
    if (!catalog) return [];
    const q = countrySearch.trim().toLowerCase();
    return catalog.countries.filter(
      (c) => !q || c.name.toLowerCase().includes(q) || c.code.toLowerCase().includes(q)
    );
  }, [catalog, countrySearch]);

  const getLangName = (code: string) =>
    catalog?.languages.find((l) => l.code === code)?.englishName || code.toUpperCase();

  const getCountryName = (code: string) =>
    catalog?.countries.find((c) => c.code === code)?.name || code;

  const toggleLanguage = (code: string) => {
    const exists = value.languages.includes(code);
    onChange({
      ...value,
      languages: exists ? value.languages.filter((c) => c !== code) : [...value.languages, code],
    });
  };

  const toggleGenre = (name: string) => {
    const exists = value.genres.includes(name);
    onChange({
      ...value,
      genres: exists ? value.genres.filter((g) => g !== name) : [...value.genres, name],
    });
  };

  const toggleMood = (mood: MoodChoice) => {
    const exists = value.moods.includes(mood);
    onChange({
      ...value,
      moods: exists ? value.moods.filter((m) => m !== mood) : [...value.moods, mood],
    });
  };

  const toggleCountry = (code: string) => {
    if (code === 'ANY') {
      onChange({ ...value, countries: value.countries.includes('ANY') ? [] : ['ANY'] });
      return;
    }
    const withoutAny = value.countries.filter((c) => c !== 'ANY');
    const exists = withoutAny.includes(code);
    onChange({
      ...value,
      countries: exists ? withoutAny.filter((c) => c !== code) : [...withoutAny, code],
    });
  };

  const handleClearAll = () => {
    setAppliedSavedNotice(false);
    onChange(createEmptyPreferences());
  };

  const handleSelectAll = () => {
    setAppliedSavedNotice(false);
    onChange({
      ...value,
      genres: visibleGenres.map((g) => g.name),
      moods: ['Happy', 'Sad', 'Romantic', 'Thrilling', 'Relaxed'],
      subtitlesFine: true,
    });
  };

  const handleApplySaved = () => {
    if (!savedPreferences) return;
    onChange({
      ...value,
      languages: savedPreferences.languages || [],
      subtitlesFine: Boolean(savedPreferences.subtitlesFine),
      genres: savedPreferences.genres || [],
      moods: (savedPreferences.moods || []) as MoodChoice[],
      countries: savedPreferences.countries || [],
    });
    setAppliedSavedNotice(true);
  };

  const handleFormSubmit = (e: FormEvent) => {
    e.preventDefault();
    onSubmit(value);
  };

  const chipClass = (active: boolean) =>
    `px-3.5 py-2 rounded-xl text-xs sm:text-sm font-medium transition-all duration-150 cursor-pointer border ${
      active
        ? 'bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] text-white border-[#8C1A35]'
        : 'bg-[#131317] hover:bg-[#1c1c22] text-neutral-200 border-white/12 hover:border-white/25'
    }`;

  // Build ordered field definitions so numbering (1..9) is always computed directly from position
  const numberedFields = [
    {
      key: 'type',
      title: 'Type',
      content: (
        <div className="flex flex-wrap gap-2">
          {TYPE_OPTIONS.map((t) => (
            <button
              key={t}
              type="button"
              disabled={disabled}
              onClick={() => {
                const nextType = t;
                // Keep only genres valid for the newly selected type
                const allowed = new Set(
                  (catalog?.genres || [])
                    .filter((g) => {
                      if (nextType === 'Anything') return true;
                      if (nextType === 'Movies') return g.types.includes('movies');
                      if (nextType === 'Series') return g.types.includes('series');
                      if (nextType === 'Dramas') return g.types.includes('dramas');
                      if (nextType === 'Anime') return g.types.includes('anime');
                      return true;
                    })
                    .map((g) => g.name)
                );
                onChange({
                  ...value,
                  type: nextType,
                  genres: allowed.size > 0 ? value.genres.filter((g) => allowed.has(g)) : value.genres,
                });
              }}
              className={chipClass(value.type === t)}
            >
              {t}
            </button>
          ))}
        </div>
      ),
    },
    {
      key: 'language',
      title: 'Language',
      subtitle: 'Audio language you want to hear',
      content: (
        <div className="space-y-3" ref={langBoxRef}>
          {/* Popular languages first */}
          <div className="flex flex-wrap gap-2">
            {popularLanguages.map((lang) => (
              <button
                key={lang.code}
                type="button"
                disabled={disabled}
                onClick={() => toggleLanguage(lang.code)}
                className={chipClass(value.languages.includes(lang.code))}
              >
                {lang.englishName}
              </button>
            ))}
          </div>

          {/* Searchable dropdown for all TMDB languages */}
          <div className="relative max-w-md">
            <button
              type="button"
              disabled={disabled}
              onClick={() => setLangDropdownOpen((v) => !v)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#131317] border border-white/15 text-left text-sm text-neutral-200 flex items-center justify-between hover:border-[#6D0F25] transition-colors cursor-pointer"
            >
              <span>Search all languages ({catalog?.languages.length || 0})...</span>
              <ChevronDown className={`w-4 h-4 transition-transform ${langDropdownOpen ? 'rotate-180' : ''}`} />
            </button>

            {langDropdownOpen && (
              <div className="absolute left-0 right-0 mt-1.5 rounded-xl bg-[#101014] border border-white/15 shadow-2xl z-30 overflow-hidden">
                <div className="p-2 border-b border-white/10 flex items-center gap-2">
                  <Search className="w-4 h-4 text-neutral-400 shrink-0" />
                  <input
                    type="text"
                    value={langSearch}
                    onChange={(e) => setLangSearch(e.target.value)}
                    placeholder="Type language name..."
                    className="w-full bg-transparent text-sm text-white placeholder-neutral-500 focus:outline-none"
                  />
                </div>
                <div className="max-h-56 overflow-y-auto py-1">
                  {filteredDropdownLanguages.map((lang) => {
                    const selected = value.languages.includes(lang.code);
                    return (
                      <button
                        key={lang.code}
                        type="button"
                        onClick={() => toggleLanguage(lang.code)}
                        className={`w-full px-3.5 py-2 text-left text-sm flex items-center justify-between transition-colors ${
                          selected
                            ? 'bg-[#6D0F25] text-white'
                            : 'text-neutral-200 hover:bg-[#1b1b21]'
                        }`}
                      >
                        <span>
                          {lang.englishName}
                          {lang.nativeName && lang.nativeName !== lang.englishName
                            ? ` (${lang.nativeName})`
                            : ''}
                        </span>
                        {selected && <Check className="w-4 h-4 shrink-0" />}
                      </button>
                    );
                  })}
                  {filteredDropdownLanguages.length === 0 && (
                    <div className="px-3.5 py-3 text-xs text-neutral-400">No matching languages.</div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Selected language tags (if any outside quick row) */}
          {value.languages.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {value.languages.map((code) => (
                <span
                  key={code}
                  className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#4A0A19] border border-[#8C1A35] text-xs text-white"
                >
                  <span>{getLangName(code)}</span>
                  <button
                    type="button"
                    disabled={disabled}
                    onClick={() => toggleLanguage(code)}
                    aria-label={`Remove ${getLangName(code)}`}
                    className="hover:text-neutral-300 cursor-pointer"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </span>
              ))}
            </div>
          )}

          {/* Subtitles are fine toggle */}
          <label className="inline-flex items-center gap-3 cursor-pointer select-none pt-1">
            <button
              type="button"
              role="switch"
              aria-checked={value.subtitlesFine}
              disabled={disabled}
              onClick={() => onChange({ ...value, subtitlesFine: !value.subtitlesFine })}
              className={`w-11 h-6 rounded-full transition-colors p-0.5 cursor-pointer ${
                value.subtitlesFine ? 'bg-[#6D0F25]' : 'bg-[#26262c]'
              }`}
            >
              <span
                className={`block w-5 h-5 rounded-full bg-white transition-transform ${
                  value.subtitlesFine ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
            <span className="text-sm text-neutral-200">Subtitles are fine</span>
          </label>
        </div>
      ),
    },
    {
      key: 'genres',
      title: 'Genres',
      content: (
        <div className="flex flex-wrap gap-2">
          {visibleGenres.map((genre) => (
            <button
              key={genre.name}
              type="button"
              disabled={disabled}
              onClick={() => toggleGenre(genre.name)}
              className={chipClass(value.genres.includes(genre.name))}
            >
              {genre.name}
            </button>
          ))}
          {visibleGenres.length === 0 && (
            <span className="text-xs text-neutral-400">Loading genres...</span>
          )}
        </div>
      ),
    },
    {
      key: 'mood',
      title: 'Your mood',
      content: (
        <div className="flex flex-wrap gap-2">
          {MOOD_OPTIONS.map((mood) => (
            <button
              key={mood}
              type="button"
              disabled={disabled}
              onClick={() => toggleMood(mood)}
              className={chipClass(value.moods.includes(mood))}
            >
              {mood}
            </button>
          ))}
        </div>
      ),
    },
    {
      key: 'releasePeriod',
      title: 'Release period',
      content: (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={disabled}
              onClick={() =>
                onChange({
                  ...value,
                  releasePeriod: { ...value.releasePeriod, anyYear: true },
                })
              }
              className={chipClass(value.releasePeriod.anyYear)}
            >
              Any year
            </button>
            <button
              type="button"
              disabled={disabled}
              onClick={() =>
                onChange({
                  ...value,
                  releasePeriod: { ...value.releasePeriod, anyYear: false },
                })
              }
              className={chipClass(!value.releasePeriod.anyYear)}
            >
              Custom year range
            </button>
          </div>

          {!value.releasePeriod.anyYear && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-xl rounded-xl bg-[#111115] border border-white/10 p-4">
              <div className="space-y-2">
                <div className="flex justify-between text-xs text-neutral-300">
                  <span>From year</span>
                  <span className="font-mono-tabular font-semibold text-white">
                    {value.releasePeriod.fromYear}
                  </span>
                </div>
                <input
                  type="range"
                  min={1950}
                  max={CURRENT_YEAR}
                  disabled={disabled}
                  value={value.releasePeriod.fromYear}
                  onChange={(e) => {
                    const nextFrom = Number(e.target.value);
                    onChange({
                      ...value,
                      releasePeriod: {
                        anyYear: false,
                        fromYear: nextFrom,
                        toYear: Math.max(nextFrom, value.releasePeriod.toYear),
                      },
                    });
                  }}
                  className="w-full burgundy-slider"
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-xs text-neutral-300">
                  <span>To year</span>
                  <span className="font-mono-tabular font-semibold text-white">
                    {value.releasePeriod.toYear}
                  </span>
                </div>
                <input
                  type="range"
                  min={1950}
                  max={CURRENT_YEAR}
                  disabled={disabled}
                  value={value.releasePeriod.toYear}
                  onChange={(e) => {
                    const nextTo = Number(e.target.value);
                    onChange({
                      ...value,
                      releasePeriod: {
                        anyYear: false,
                        fromYear: Math.min(value.releasePeriod.fromYear, nextTo),
                        toYear: nextTo,
                      },
                    });
                  }}
                  className="w-full burgundy-slider"
                />
              </div>
            </div>
          )}
        </div>
      ),
    },
    {
      key: 'duration',
      title: 'Duration',
      content: (
        <div className="flex flex-wrap gap-2">
          {DURATION_OPTIONS.map((opt) => {
            const active = value.duration === opt.value;
            const hint =
              value.type === 'Movies'
                ? opt.movieHint
                : value.type === 'Series' || value.type === 'Dramas' || value.type === 'Anime'
                ? opt.seriesHint
                : `${opt.movieHint} / ${opt.seriesHint}`;
            return (
              <button
                key={opt.value}
                type="button"
                disabled={disabled}
                onClick={() =>
                  onChange({ ...value, duration: active ? '' : opt.value })
                }
                className={chipClass(active)}
              >
                {opt.value} ({hint})
              </button>
            );
          })}
        </div>
      ),
    },
    {
      key: 'minRating',
      title: 'Minimum rating',
      content: (
        <div className="space-y-3 max-w-md">
          <div className="flex items-center gap-3">
            <button
              type="button"
              disabled={disabled}
              onClick={() => onChange({ ...value, minRating: null })}
              className={chipClass(value.minRating === null)}
            >
              Any
            </button>
            <span className="text-sm font-mono-tabular text-neutral-200">
              {value.minRating === null ? 'Any rating' : `${value.minRating}.0+ / 10`}
            </span>
          </div>
          <input
            type="range"
            min={1}
            max={10}
            step={1}
            disabled={disabled}
            value={value.minRating ?? 1}
            onChange={(e) => onChange({ ...value, minRating: Number(e.target.value) })}
            className="w-full burgundy-slider"
            aria-label="Minimum rating from 1 to 10"
          />
          <div className="flex justify-between text-[11px] font-mono-tabular text-neutral-500">
            <span>1</span>
            <span>5</span>
            <span>10</span>
          </div>
        </div>
      ),
    },
    {
      key: 'countries',
      title: 'Made in',
      subtitle: 'Country of production',
      content: (
        <div className="space-y-3" ref={countryBoxRef}>
          <div className="flex flex-wrap gap-2">
            {popularCountries.map((c) => (
              <button
                key={c.code}
                type="button"
                disabled={disabled}
                onClick={() => toggleCountry(c.code)}
                className={chipClass(value.countries.includes(c.code))}
              >
                {c.name}
              </button>
            ))}
            <button
              type="button"
              disabled={disabled}
              onClick={() => toggleCountry('ANY')}
              className={chipClass(value.countries.includes('ANY'))}
            >
              Any
            </button>
          </div>

          <div className="relative max-w-md">
            <button
              type="button"
              disabled={disabled}
              onClick={() => setCountryDropdownOpen((v) => !v)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-[#131317] border border-white/15 text-left text-sm text-neutral-200 flex items-center justify-between hover:border-[#6D0F25] transition-colors cursor-pointer"
            >
              <span>Search all countries ({catalog?.countries.length || 0})...</span>
              <ChevronDown className={`w-4 h-4 transition-transform ${countryDropdownOpen ? 'rotate-180' : ''}`} />
            </button>

            {countryDropdownOpen && (
              <div className="absolute left-0 right-0 mt-1.5 rounded-xl bg-[#101014] border border-white/15 shadow-2xl z-30 overflow-hidden">
                <div className="p-2 border-b border-white/10 flex items-center gap-2">
                  <Search className="w-4 h-4 text-neutral-400 shrink-0" />
                  <input
                    type="text"
                    value={countrySearch}
                    onChange={(e) => setCountrySearch(e.target.value)}
                    placeholder="Type country name..."
                    className="w-full bg-transparent text-sm text-white placeholder-neutral-500 focus:outline-none"
                  />
                </div>
                <div className="max-h-56 overflow-y-auto py-1">
                  {filteredDropdownCountries.map((c) => {
                    const selected = value.countries.includes(c.code);
                    return (
                      <button
                        key={c.code}
                        type="button"
                        onClick={() => toggleCountry(c.code)}
                        className={`w-full px-3.5 py-2 text-left text-sm flex items-center justify-between transition-colors ${
                          selected
                            ? 'bg-[#6D0F25] text-white'
                            : 'text-neutral-200 hover:bg-[#1b1b21]'
                        }`}
                      >
                        <span>{c.name}</span>
                        {selected && <Check className="w-4 h-4 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {value.countries.filter((c) => c !== 'ANY').length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {value.countries
                .filter((c) => c !== 'ANY')
                .map((code) => (
                  <span
                    key={code}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-[#4A0A19] border border-[#8C1A35] text-xs text-white"
                  >
                    <span>{getCountryName(code)}</span>
                    <button
                      type="button"
                      disabled={disabled}
                      onClick={() => toggleCountry(code)}
                      aria-label={`Remove ${getCountryName(code)}`}
                      className="hover:text-neutral-300 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </span>
                ))}
            </div>
          )}
        </div>
      ),
    },
    {
      key: 'storyPreference',
      title: 'Story preference',
      content: (
        <textarea
          rows={3}
          disabled={disabled}
          value={value.storyPreference}
          onChange={(e) => onChange({ ...value, storyPreference: e.target.value })}
          placeholder="e.g. a girl who travels back in time"
          className="w-full max-w-2xl px-4 py-3 rounded-xl bg-[#111115] border border-white/15 text-sm text-white placeholder-neutral-500 focus:border-[#8C1A35] focus:outline-none"
        />
      ),
    },
  ];

  return (
    <form onSubmit={handleFormSubmit} className="space-y-6">
      {/* Top Action Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-white/10">
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            type="button"
            disabled={disabled}
            onClick={handleClearAll}
            className="px-3.5 py-2 rounded-xl bg-[#141418] hover:bg-[#1e1e24] border border-white/15 text-xs font-medium text-neutral-200 inline-flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Clear all</span>
          </button>
          <button
            type="button"
            disabled={disabled}
            onClick={handleSelectAll}
            className="px-3.5 py-2 rounded-xl bg-[#141418] hover:bg-[#1e1e24] border border-white/15 text-xs font-medium text-neutral-200 inline-flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Check className="w-3.5 h-3.5" />
            <span>Select all</span>
          </button>
        </div>

        {showSavedPrefsButton && savedPreferences && (
          <button
            type="button"
            disabled={disabled}
            onClick={handleApplySaved}
            className="px-4 py-2 rounded-xl bg-[#4A0A19] hover:bg-[#6D0F25] border border-[#8C1A35] text-xs font-medium text-white inline-flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Use my saved preferences</span>
          </button>
        )}
      </div>

      {appliedSavedNotice && (
        <div className="rounded-xl bg-[#180a0e] border border-[#6D0F25] px-4 py-2.5 text-xs text-neutral-200">
          Loaded your saved language, genres, mood, and country. Feel free to edit anything before submitting.
        </div>
      )}

      {/* Automatically numbered 1 to 9 */}
      <div className="space-y-6">
        {numberedFields.map((field, index) => (
          <div
            key={field.key}
            className="rounded-2xl bg-[#0b0b0e] border border-white/10 p-5 sm:p-6 space-y-3"
          >
            <div className="flex flex-wrap items-baseline gap-2">
              <span className="font-mono-tabular text-sm font-bold text-[#d48b9b]">
                {index + 1}.
              </span>
              <h3 className="font-display text-base sm:text-lg font-semibold text-white">
                {field.title}
              </h3>
              {field.subtitle && (
                <span className="text-xs text-neutral-400">— {field.subtitle}</span>
              )}
            </div>
            {field.content}
          </div>
        ))}
      </div>

      {/* Submit */}
      <div className="pt-2">
        <button
          type="submit"
          disabled={loading || disabled}
          className="w-full sm:w-auto min-w-[240px] px-8 py-4 rounded-2xl bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] disabled:opacity-60 text-white font-display font-semibold text-base transition-colors cursor-pointer shadow-lg"
        >
          {loading ? 'Finding verified matches...' : submitLabel}
        </button>
      </div>
    </form>
  );
}
