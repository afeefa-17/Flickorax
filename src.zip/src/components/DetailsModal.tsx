import { Bookmark, Check, Clock, ExternalLink, Film, Star, Users, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext.tsx';
import { fetchMediaDetails } from '../services/recommendationService.ts';
import type { MediaDetails, MediaRecommendation } from '../types/flickorax.ts';

interface DetailsModalProps {
  item: MediaRecommendation | null;
  onClose: () => void;
}

export function DetailsModal({ item, onClose }: DetailsModalProps) {
  const { isLoggedIn, isInWatchlist, addToWatchlist, removeFromWatchlist, openAuthModal } = useAuth();
  const [details, setDetails] = useState<MediaDetails | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!item) {
      setDetails(null);
      setError(null);
      return;
    }

    let cancelled = false;
    setLoading(true);
    setError(null);

    fetchMediaDetails(item.source, item.mediaType, item.externalId)
      .then((data) => {
        if (!cancelled) setDetails({ ...data, reason: item.reason || data.reason });
      })
      .catch((err) => {
        if (!cancelled) {
          setError(err instanceof Error ? err.message : 'Failed to load details.');
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [item]);

  if (!item) return null;

  const display = details || item;
  const saved = isInWatchlist(item.externalId);

  const handleWatchlist = async () => {
    if (!isLoggedIn) {
      openAuthModal('Log in to save this');
      return;
    }
    if (saved) {
      await removeFromWatchlist(item.externalId);
    } else {
      await addToWatchlist(item);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="details-modal-title"
      onClick={onClose}
    >
      <div
        className="w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-2xl bg-[#0d0d10] border border-white/15 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative h-48 sm:h-64 w-full bg-[#15151a] overflow-hidden">
          {display.backdropUrl || display.posterUrl ? (
            <img
              src={display.backdropUrl || display.posterUrl}
              alt={display.title}
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover opacity-55"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-[#3a0814] to-black" />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d10] via-[#0d0d10]/55 to-transparent" />
          <button
            type="button"
            onClick={onClose}
            aria-label="Close details"
            className="absolute top-4 right-4 p-2 rounded-xl bg-black/75 text-white hover:bg-[#6D0F25] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 sm:p-8 -mt-20 relative z-10 space-y-6">
          <div className="flex flex-col sm:flex-row gap-6 items-start">
            <div className="w-32 sm:w-40 shrink-0 aspect-[2/3] rounded-xl overflow-hidden bg-[#17171c] border border-white/15 shadow-xl">
              {display.posterUrl ? (
                <img
                  src={display.posterUrl}
                  alt={display.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Film className="w-10 h-10 text-[#8C1A35]" />
                </div>
              )}
            </div>

            <div className="flex-1 space-y-3 pt-2">
              <h2 id="details-modal-title" className="font-display text-2xl sm:text-3xl font-bold text-white">
                {display.title}
              </h2>

              <div className="flex flex-wrap items-center gap-x-2.5 gap-y-1 text-sm text-neutral-300">
                {display.year && <span className="font-mono-tabular">{display.year}</span>}
                <span>·</span>
                <span className="capitalize">{display.mediaType}</span>
                {display.rating > 0 && (
                  <>
                    <span>·</span>
                    <span className="inline-flex items-center gap-1 font-mono-tabular font-semibold text-white">
                      <Star className="w-4 h-4 fill-[#8C1A35] text-[#8C1A35]" />
                      {display.rating.toFixed(1)}
                    </span>
                  </>
                )}
                {details?.runtimeOrEpisodes && (
                  <>
                    <span>·</span>
                    <span className="inline-flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-[#8C1A35]" />
                      {details.runtimeOrEpisodes}
                    </span>
                  </>
                )}
              </div>

              {display.genres.length > 0 && (
                <p className="text-xs text-neutral-400">
                  {display.genres.join(' · ')}
                  {details?.country ? ` · ${details.country}` : ''}
                </p>
              )}

              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleWatchlist}
                  className={`px-5 py-2.5 rounded-xl text-sm font-medium inline-flex items-center gap-2 transition-colors cursor-pointer ${
                    saved
                      ? 'bg-[#4A0A19] border border-[#8C1A35] text-white'
                      : 'bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] text-white'
                  }`}
                >
                  {saved ? <Check className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
                  <span>{saved ? 'In My Watchlist' : 'Add to Watchlist'}</span>
                </button>
              </div>
            </div>
          </div>

          {loading && (
            <div className="space-y-3 py-4">
              <div className="h-4 bg-white/10 rounded animate-pulse w-3/4" />
              <div className="h-4 bg-white/10 rounded animate-pulse w-full" />
              <div className="h-4 bg-white/10 rounded animate-pulse w-5/6" />
            </div>
          )}

          {error && (
            <p className="text-sm text-neutral-300 bg-[#4A0A19]/40 border border-[#8C1A35] rounded-xl p-3">
              {error}
            </p>
          )}

          <div className="space-y-2">
            <h3 className="font-display text-sm font-semibold text-neutral-300">Storyline</h3>
            <p className="text-sm sm:text-base text-neutral-200 leading-relaxed whitespace-pre-line">
              {details?.fullDescription || display.overview}
            </p>
          </div>

          {details?.cast && details.cast.length > 0 && (
            <div className="space-y-3">
              <h3 className="font-display text-sm font-semibold text-neutral-300 flex items-center gap-2">
                <Users className="w-4 h-4 text-[#8C1A35]" />
                <span>Cast & Characters</span>
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {details.cast.map((c, idx) => (
                  <div
                    key={`${c.name}-${idx}`}
                    className="rounded-xl bg-[#131317] border border-white/10 p-2.5 flex items-center gap-2.5"
                  >
                    {c.profileUrl ? (
                      <img
                        src={c.profileUrl}
                        alt={c.name}
                        referrerPolicy="no-referrer"
                        className="w-10 h-10 rounded-lg object-cover shrink-0 bg-black"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-lg bg-[#231016] shrink-0 flex items-center justify-center text-xs font-semibold text-[#d48b9b]">
                        {c.name.slice(0, 2).toUpperCase()}
                      </div>
                    )}
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-white truncate">{c.name}</div>
                      <div className="text-[11px] text-neutral-400 truncate capitalize">{c.role}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {details?.watchProviders && details.watchProviders.length > 0 && (
            <div className="space-y-3">
              <h3 className="font-display text-sm font-semibold text-neutral-300">Where to watch</h3>
              <div className="flex flex-wrap gap-2.5">
                {details.watchProviders.map((p, idx) =>
                  p.link ? (
                    <a
                      key={`${p.providerName}-${idx}`}
                      href={p.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#141418] hover:bg-[#6D0F25] border border-white/12 text-xs font-medium text-white transition-colors"
                    >
                      {p.logoUrl && (
                        <img
                          src={p.logoUrl}
                          alt=""
                          referrerPolicy="no-referrer"
                          className="w-5 h-5 rounded object-cover"
                        />
                      )}
                      <span>{p.providerName}</span>
                      <span className="text-neutral-400">({p.type})</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  ) : (
                    <div
                      key={`${p.providerName}-${idx}`}
                      className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-[#141418] border border-white/12 text-xs font-medium text-white"
                    >
                      <span>{p.providerName}</span>
                    </div>
                  )
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
