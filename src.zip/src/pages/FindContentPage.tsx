import { AlertCircle, RefreshCw, SlidersHorizontal } from 'lucide-react';
import { useState } from 'react';
import { MediaCard } from '../components/MediaCard.tsx';
import { PreferencesForm } from '../components/PreferencesForm.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';
import { fetchSoloRecommendations } from '../services/recommendationService.ts';
import {
  createEmptyPreferences,
  type MediaRecommendation,
  type PreferencesInput,
} from '../types/flickorax.ts';

interface FindContentPageProps {
  onOpenDetails: (item: MediaRecommendation) => void;
}

export function FindContentPage({ onOpenDetails }: FindContentPageProps) {
  const { isLoggedIn, savedPreferences, saveUserPreferences } = useAuth();
  // Always starts empty; never pre-filled or auto-applied
  const [prefs, setPrefs] = useState<PreferencesInput>(() => createEmptyPreferences());
  const [results, setResults] = useState<MediaRecommendation[]>([]);
  const [relaxedFilters, setRelaxedFilters] = useState<string[]>([]);
  const [notice, setNotice] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);

  const fetchRecommendations = async (inputPrefs: PreferencesInput, excludeTitles: string[] = []) => {
    setLoading(true);
    setError(null);
    setNotice(null);
    setHasSearched(true);

    try {
      // Quietly save only language, genres, mood, and country for logged-in users
      if (isLoggedIn) {
        saveUserPreferences(inputPrefs).catch(() => {});
      }

      const data = await fetchSoloRecommendations(inputPrefs, excludeTitles);
      setResults(data.items || []);
      setRelaxedFilters(data.relaxedFilters || []);
      setNotice(data.notice || null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Recommendation request failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10 space-y-10">
      <div className="space-y-2">
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">
          Find Content
        </h1>
        <p className="text-sm sm:text-base text-neutral-400 max-w-2xl">
          Every field is optional. Pick only what matters right now—or leave everything empty for a curated mix across Movies, Anime, Series, and Dramas.
        </p>
      </div>

      <PreferencesForm
        value={prefs}
        onChange={setPrefs}
        onSubmit={(submitted) => fetchRecommendations(submitted)}
        submitLabel="Show Recommendations"
        loading={loading}
        savedPreferences={savedPreferences}
        showSavedPrefsButton={isLoggedIn}
      />

      {loading && (
        <div className="space-y-4 pt-4">
          <div className="flex items-center gap-3 text-sm text-neutral-200">
            <RefreshCw className="w-4 h-4 text-[#8C1A35] animate-spin" />
            <span>Matching your preferences with AI and verifying titles in TMDB & AniList...</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="h-[460px] rounded-2xl bg-[#111114] border border-white/10 animate-pulse" />
            ))}
          </div>
        </div>
      )}

      {!loading && error && (
        <div className="rounded-2xl bg-[#300812] border border-[#8C1A35] p-5 flex items-start gap-3 text-sm text-white">
          <AlertCircle className="w-5 h-5 text-[#e09aa9] shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-semibold">Unable to fetch recommendations</p>
            <p className="text-neutral-200">{error}</p>
          </div>
        </div>
      )}

      {!loading && hasSearched && !error && (
        <section className="space-y-5 pt-4 border-t border-white/10">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <h2 className="font-display text-2xl font-bold text-white">
              Your Recommendations
            </h2>
            <button
              type="button"
              onClick={() =>
                fetchRecommendations(
                  prefs,
                  results.map((r) => r.title)
                )
              }
              className="px-4 py-2.5 rounded-xl bg-[#16161b] hover:bg-[#6D0F25] border border-white/15 text-xs sm:text-sm font-medium text-white inline-flex items-center gap-2 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Show 5 new matches</span>
            </button>
          </div>

          {relaxedFilters.length > 0 && (
            <div className="rounded-xl bg-[#1a0b10] border border-[#6D0F25] px-4 py-3 text-xs sm:text-sm text-neutral-200 flex items-start gap-2.5">
              <SlidersHorizontal className="w-4 h-4 text-[#e09aa9] shrink-0 mt-0.5" />
              <span>
                To bring you 5 verified matches, we relaxed: <strong>{relaxedFilters.join(', ')}</strong>.
              </span>
            </div>
          )}

          {notice && (
            <div className="rounded-xl bg-[#141418] border border-white/15 px-4 py-3 text-xs sm:text-sm text-neutral-200">
              {notice}
            </div>
          )}

          {results.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {results.map((item) => (
                <MediaCard
                  key={item.externalId}
                  item={item}
                  reasonLabel="Why this matches you"
                  onMoreDetails={onOpenDetails}
                />
              ))}
            </div>
          ) : (
            <div className="rounded-2xl bg-[#0d0d10] border border-white/10 p-6 text-sm text-neutral-300">
              No verified titles matched right now. Try adjusting a filter and searching again.
            </div>
          )}
        </section>
      )}
    </div>
  );
}
