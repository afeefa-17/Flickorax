import { AlertCircle, RefreshCw, Shuffle } from 'lucide-react';
import { useState } from 'react';
import { MediaCard } from '../components/MediaCard.tsx';
import { fetchSurpriseRecommendations } from '../services/recommendationService.ts';
import type {
  MediaRecommendation,
  MediaTypeChoice,
  MoodChoice,
} from '../types/flickorax.ts';

interface SurpriseMePageProps {
  onOpenDetails: (item: MediaRecommendation) => void;
}

const MOODS: MoodChoice[] = ['Happy', 'Sad', 'Romantic', 'Thrilling', 'Relaxed', 'Surprise me'];
const TYPES: MediaTypeChoice[] = ['Movies', 'Anime', 'Series', 'Dramas', 'Anything'];

export function SurpriseMePage({ onOpenDetails }: SurpriseMePageProps) {
  const [mood, setMood] = useState<MoodChoice>('Surprise me');
  const [type, setType] = useState<MediaTypeChoice>('Anything');
  const [results, setResults] = useState<MediaRecommendation[]>([]);
  const [notice, setNotice] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [hasRolled, setHasRolled] = useState(false);

  const runSurprise = async (excludeTitles: string[] = []) => {
    setLoading(true);
    setError(null);
    setNotice(null);
    setHasRolled(true);
    try {
      const data = await fetchSurpriseRecommendations(mood, type, excludeTitles);
      setResults(data.items || []);
      setNotice(data.notice || null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong.');
    } finally {
      setLoading(false);
    }
  };

  const chipClass = (active: boolean) =>
    `px-4 py-2.5 rounded-xl text-sm font-medium border transition-colors cursor-pointer ${
      active
        ? 'bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] text-white border-[#8C1A35]'
        : 'bg-[#131317] hover:bg-[#1d1d24] text-neutral-200 border-white/12'
    }`;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10 space-y-10">
      <div className="space-y-2">
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">
          Surprise Me
        </h1>
        <p className="text-sm sm:text-base text-neutral-400 max-w-2xl">
          Two quick questions, zero setup, no login required. Let Flickorax pick 5 verified titles for your vibe.
        </p>
      </div>

      <div className="rounded-2xl bg-[#0c0c0f] border border-white/10 p-6 sm:p-8 space-y-7">
        <div className="space-y-3">
          <div className="flex items-baseline gap-2">
            <span className="font-mono-tabular text-sm font-bold text-[#d48b9b]">1.</span>
            <h2 className="font-display text-lg font-semibold text-white">
              What mood are you in?
            </h2>
          </div>
          <div className="flex flex-wrap gap-2.5">
            {MOODS.map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setMood(m)}
                className={chipClass(mood === m)}
              >
                {m}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-baseline gap-2">
            <span className="font-mono-tabular text-sm font-bold text-[#d48b9b]">2.</span>
            <h2 className="font-display text-lg font-semibold text-white">
              What type do you want to watch?
            </h2>
          </div>
          <div className="flex flex-wrap gap-2.5">
            {TYPES.map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setType(t)}
                className={chipClass(type === t)}
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        <div className="pt-2">
          <button
            type="button"
            disabled={loading}
            onClick={() => runSurprise()}
            className="px-8 py-4 rounded-2xl bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] disabled:opacity-60 text-white font-display font-semibold text-base inline-flex items-center gap-2.5 transition-colors cursor-pointer"
          >
            <Shuffle className="w-5 h-5" />
            <span>{loading ? 'Picking your surprises...' : 'Surprise Me'}</span>
          </button>
        </div>
      </div>

      {loading && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {Array.from({ length: 5 }).map((_, idx) => (
            <div key={idx} className="h-[460px] rounded-2xl bg-[#111114] border border-white/10 animate-pulse" />
          ))}
        </div>
      )}

      {!loading && error && (
        <div className="rounded-2xl bg-[#300812] border border-[#8C1A35] p-5 flex items-start gap-3 text-sm text-white">
          <AlertCircle className="w-5 h-5 text-[#e09aa9] shrink-0 mt-0.5" />
          <span>{error}</span>
        </div>
      )}

      {!loading && hasRolled && !error && results.length > 0 && (
        <section className="space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <h2 className="font-display text-2xl font-bold text-white">Your Surprise Picks</h2>
            <button
              type="button"
              onClick={() => runSurprise(results.map((r) => r.title))}
              className="px-5 py-2.5 rounded-xl bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] text-white text-sm font-medium inline-flex items-center gap-2 transition-colors cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Surprise me again</span>
            </button>
          </div>

          {notice && (
            <div className="rounded-xl bg-[#141418] border border-white/15 px-4 py-3 text-xs sm:text-sm text-neutral-200">
              {notice}
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {results.map((item) => (
              <MediaCard
                key={item.externalId}
                item={item}
                reasonLabel="Why it fits"
                onMoreDetails={onOpenDetails}
              />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
