import { Compass, Film, Shuffle, Star, Users } from 'lucide-react';
import { useEffect, useState } from 'react';
import { MediaCard } from '../components/MediaCard.tsx';
import type { AppRoute } from '../components/Navbar.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';
import { fetchBecauseYouLiked, fetchTrendingMedia } from '../services/recommendationService.ts';
import type { MediaRecommendation } from '../types/flickorax.ts';

interface HomePageProps {
  onNavigate: (route: AppRoute) => void;
  onOpenDetails: (item: MediaRecommendation) => void;
}

export function HomePage({ onNavigate, onOpenDetails }: HomePageProps) {
  const { isLoggedIn, watchlist, savedPreferences } = useAuth();
  const [trending, setTrending] = useState<MediaRecommendation[]>([]);
  const [trendingLoading, setTrendingLoading] = useState(true);
  const [tmdbConfigured, setTmdbConfigured] = useState(true);
  const [becauseItems, setBecauseItems] = useState<MediaRecommendation[]>([]);
  const [becauseLoading, setBecauseLoading] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setTrendingLoading(true);
    fetchTrendingMedia()
      .then((data) => {
        if (!cancelled) {
          setTrending(data.items || []);
          setTmdbConfigured(data.tmdbConfigured !== false);
        }
      })
      .catch(() => {
        if (!cancelled) setTrending([]);
      })
      .finally(() => {
        if (!cancelled) setTrendingLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!isLoggedIn || watchlist.length === 0) {
      setBecauseItems([]);
      return;
    }

    let cancelled = false;
    setBecauseLoading(true);
    fetchBecauseYouLiked(
      watchlist.map((w) => ({
        title: w.title,
        mediaType: w.mediaType,
        genres: w.genres,
      })),
      savedPreferences || null
    )
      .then((data) => {
        if (!cancelled) setBecauseItems(data.items || []);
      })
      .catch(() => {
        if (!cancelled) setBecauseItems([]);
      })
      .finally(() => {
        if (!cancelled) setBecauseLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [isLoggedIn, watchlist, savedPreferences]);

  return (
    <div className="space-y-16 pb-10">
      {/* Hero Section */}
      <section className="relative overflow-hidden border-b border-white/10">
        <div className="absolute inset-0">
          <img
            src="/src/assets/images/hero_cinema_backdrop_1795507978113.jpg"
            alt="Flickorax private screening room"
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover opacity-50"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/75 to-black/65" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/50 to-transparent" />
        </div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 py-16 sm:py-24 lg:py-28 flex flex-col items-start gap-7">
          <div className="flex items-center gap-4">
            <img
              src="/src/assets/images/flickorax_logo_1795507977537.jpg"
              alt="Flickorax emblem"
              referrerPolicy="no-referrer"
              className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border border-[#6D0F25] shadow-2xl"
            />
            <span className="font-display text-3xl sm:text-4xl font-bold tracking-tight text-white">
              Flickorax
            </span>
          </div>

          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white max-w-3xl leading-[1.08]">
            Find what to watch, together or solo
          </h1>

          <p className="text-base sm:text-lg text-neutral-300 max-w-2xl leading-relaxed">
            AI-curated movies, anime, series, and dramas verified directly against TMDB and AniList. Tailor every mood and filter yourself, or host a live Watch Party room for up to 10 friends.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto pt-1">
            <button
              type="button"
              onClick={() => onNavigate({ page: 'find' })}
              className="px-8 py-4 rounded-2xl bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] text-white font-display font-semibold text-base sm:text-lg transition-all duration-150 cursor-pointer shadow-xl text-center"
            >
              Watch Solo
            </button>
            <button
              type="button"
              onClick={() => onNavigate({ page: 'watch-party', mode: 'hub' })}
              className="px-8 py-4 rounded-2xl bg-[#141418] hover:bg-[#6D0F25] active:bg-[#4A0A19] border border-white/20 hover:border-[#8C1A35] text-white font-display font-semibold text-base sm:text-lg transition-all duration-150 cursor-pointer text-center"
            >
              Watch Together
            </button>
          </div>
        </div>
      </section>

      {/* Three Feature Cards */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <button
            type="button"
            onClick={() => onNavigate({ page: 'find' })}
            className="text-left rounded-2xl bg-[#0c0c0f] hover:bg-[#140a0e] border border-white/10 hover:border-[#6D0F25] p-6 sm:p-7 space-y-3 transition-all duration-200 hover:-translate-y-0.5 cursor-pointer group"
          >
            <div className="w-11 h-11 rounded-xl bg-[#6D0F25]/25 border border-[#6D0F25] flex items-center justify-center text-[#e09aa9] group-hover:bg-[#6D0F25] group-hover:text-white transition-colors">
              <Compass className="w-5 h-5" />
            </div>
            <h2 className="font-display text-xl font-semibold text-white">Find Content</h2>
            <p className="text-sm text-neutral-400 leading-relaxed">
              Filter by type, audio language, genres, mood, release years, duration, country, and storyline. Leave anything blank and still get 5 verified matches.
            </p>
          </button>

          <button
            type="button"
            onClick={() => onNavigate({ page: 'watch-party', mode: 'hub' })}
            className="text-left rounded-2xl bg-[#0c0c0f] hover:bg-[#140a0e] border border-white/10 hover:border-[#6D0F25] p-6 sm:p-7 space-y-3 transition-all duration-200 hover:-translate-y-0.5 cursor-pointer group"
          >
            <div className="w-11 h-11 rounded-xl bg-[#6D0F25]/25 border border-[#6D0F25] flex items-center justify-center text-[#e09aa9] group-hover:bg-[#6D0F25] group-hover:text-white transition-colors">
              <Users className="w-5 h-5" />
            </div>
            <h2 className="font-display text-xl font-semibold text-white">Watch Party</h2>
            <p className="text-sm text-neutral-400 leading-relaxed">
              Create a room with a 6-character code, invite up to 10 people with no login required, merge everyone&apos;s tastes, and reveal group picks live.
            </p>
          </button>

          <button
            type="button"
            onClick={() => onNavigate({ page: 'surprise' })}
            className="text-left rounded-2xl bg-[#0c0c0f] hover:bg-[#140a0e] border border-white/10 hover:border-[#6D0F25] p-6 sm:p-7 space-y-3 transition-all duration-200 hover:-translate-y-0.5 cursor-pointer group"
          >
            <div className="w-11 h-11 rounded-xl bg-[#6D0F25]/25 border border-[#6D0F25] flex items-center justify-center text-[#e09aa9] group-hover:bg-[#6D0F25] group-hover:text-white transition-colors">
              <Shuffle className="w-5 h-5" />
            </div>
            <h2 className="font-display text-xl font-semibold text-white">Surprise Me</h2>
            <p className="text-sm text-neutral-400 leading-relaxed">
              Short on time? Answer two quick questions—your mood and type—and get 5 instant verified recommendations.
            </p>
          </button>
        </div>
      </section>

      {/* Trending Posters Row (TMDB + AniList) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 space-y-5">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-white">
              Trending Now
            </h2>
            <p className="text-sm text-neutral-400 mt-1">
              Live picks from {tmdbConfigured ? 'TMDB and AniList' : 'AniList (add TMDB_API_KEY in secrets for TMDB movies & series)'}. Click any poster for full details.
            </p>
          </div>
        </div>

        {trendingLoading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-7 gap-4">
            {Array.from({ length: 7 }).map((_, idx) => (
              <div
                key={idx}
                className="aspect-[2/3] rounded-2xl bg-[#131317] border border-white/10 animate-pulse"
              />
            ))}
          </div>
        ) : trending.length === 0 ? (
          <div className="rounded-2xl bg-[#0d0d10] border border-white/10 p-6 text-sm text-neutral-400">
            Trending titles could not be loaded right now. Check your network connection or TMDB key configuration.
          </div>
        ) : (
          <div className="flex gap-4 overflow-x-auto pb-3 snap-x">
            {trending.map((item) => (
              <button
                key={item.externalId}
                type="button"
                onClick={() => onOpenDetails(item)}
                className="group shrink-0 w-40 sm:w-44 text-left snap-start rounded-2xl bg-[#0d0d10] border border-white/10 hover:border-[#6D0F25] overflow-hidden transition-all duration-200 hover:-translate-y-1 cursor-pointer"
              >
                <div className="relative aspect-[2/3] w-full bg-[#15151a] overflow-hidden">
                  {item.posterUrl ? (
                    <img
                      src={item.posterUrl}
                      alt={item.title}
                      loading="lazy"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Film className="w-8 h-8 text-[#8C1A35]" />
                    </div>
                  )}
                  <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-black/90 to-transparent" />
                  {item.rating > 0 && (
                    <span className="absolute bottom-2 right-2.5 flex items-center gap-1 text-xs font-mono-tabular font-semibold text-white">
                      <Star className="w-3 h-3 fill-[#8C1A35] text-[#8C1A35]" />
                      {item.rating.toFixed(1)}
                    </span>
                  )}
                </div>
                <div className="p-3 space-y-1">
                  <div className="text-sm font-display font-semibold text-white line-clamp-1">
                    {item.title}
                  </div>
                  <div className="text-xs text-neutral-400 flex items-center gap-1.5">
                    <span className="capitalize">{item.mediaType}</span>
                    {item.year && (
                      <>
                        <span>·</span>
                        <span className="font-mono-tabular">{item.year}</span>
                      </>
                    )}
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </section>

      {/* Because You Liked... (Logged-in users with non-empty watchlist only) */}
      {isLoggedIn && watchlist.length > 0 && (becauseLoading || becauseItems.length > 0) && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 space-y-5">
          <div>
            <h2 className="font-display text-2xl sm:text-3xl font-bold text-white">
              Because you liked...
            </h2>
            <p className="text-sm text-neutral-400 mt-1">
              Fresh stories inspired by titles in your watchlist.
            </p>
          </div>

          {becauseLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {Array.from({ length: 3 }).map((_, idx) => (
                <div
                  key={idx}
                  className="h-96 rounded-2xl bg-[#131317] border border-white/10 animate-pulse"
                />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {becauseItems.map((item) => (
                <MediaCard
                  key={item.externalId}
                  item={item}
                  reasonLabel="Why it fits"
                  onMoreDetails={onOpenDetails}
                />
              ))}
            </div>
          )}
        </section>
      )}
    </div>
  );
}
