import { Bookmark } from 'lucide-react';
import { MediaCard } from '../components/MediaCard.tsx';
import type { AppRoute } from '../components/Navbar.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';
import type { MediaRecommendation } from '../types/flickorax.ts';

interface WatchlistPageProps {
  onNavigate: (route: AppRoute) => void;
  onOpenDetails: (item: MediaRecommendation) => void;
}

export function WatchlistPage({ onNavigate, onOpenDetails }: WatchlistPageProps) {
  const { isLoggedIn, watchlist, removeFromWatchlist, openAuthModal } = useAuth();

  if (!isLoggedIn) {
    return (
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-20 text-center space-y-5">
        <div className="w-14 h-14 rounded-2xl bg-[#6D0F25]/25 border border-[#6D0F25] flex items-center justify-center mx-auto text-[#e09aa9]">
          <Bookmark className="w-6 h-6" />
        </div>
        <h1 className="font-display text-3xl font-bold text-white">My Watchlist</h1>
        <p className="text-neutral-400 text-sm sm:text-base max-w-md mx-auto">
          Log in or create a free account to save movies, anime, series, and dramas across sessions.
        </p>
        <button
          type="button"
          onClick={() => openAuthModal('Log in to view your Watchlist')}
          className="px-6 py-3 rounded-xl bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] text-white font-medium text-sm transition-colors cursor-pointer"
        >
          Login / Sign Up
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">My Watchlist</h1>
          <p className="text-sm text-neutral-400 mt-1">
            {watchlist.length} saved title{watchlist.length === 1 ? '' : 's'}
          </p>
        </div>
        <button
          type="button"
          onClick={() => onNavigate({ page: 'find' })}
          className="px-5 py-2.5 rounded-xl bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] text-white text-sm font-medium transition-colors cursor-pointer"
        >
          Find More Titles
        </button>
      </div>

      {watchlist.length === 0 ? (
        <div className="rounded-2xl bg-[#0d0d10] border border-white/10 p-10 text-center space-y-4">
          <p className="text-neutral-300 text-base">Your watchlist is empty right now.</p>
          <p className="text-neutral-400 text-sm">
            Explore recommendations or click any trending poster to save titles you want to watch next.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {watchlist.map((w) => {
            const mediaItem: MediaRecommendation = {
              externalId: w.externalId,
              source: w.source,
              mediaType: w.mediaType,
              title: w.title,
              year: w.year,
              posterUrl: w.posterUrl,
              genres: w.genres || [],
              rating: w.rating,
              overview: w.overview,
              reason: w.reason || '',
            };
            return (
              <MediaCard
                key={w.externalId}
                item={mediaItem}
                reasonLabel="Note"
                onMoreDetails={onOpenDetails}
                onRemove={(id) => void removeFromWatchlist(id)}
              />
            );
          })}
        </div>
      )}
    </div>
  );
}
