import {
  AlertCircle,
  Check,
  Clock,
  Copy,
  Link2,
  RefreshCw,
  Sparkles,
  UserPlus,
  Users,
} from 'lucide-react';
import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { MediaCard } from '../components/MediaCard.tsx';
import type { AppRoute } from '../components/Navbar.tsx';
import { PreferencesForm } from '../components/PreferencesForm.tsx';
import { useAuth } from '../contexts/AuthContext.tsx';
import {
  createWatchPartyRoomApi,
  fetchWatchPartyRoomStateApi,
  joinWatchPartyRoomApi,
  normalizeRoomCode,
  runWatchPartyMatchApi,
  submitWatchPartyPicksApi,
} from '../services/watchPartyService.ts';
import {
  createEmptyPreferences,
  type MediaRecommendation,
  type PreferencesInput,
  type RoomMemberDoc,
  type WatchPartyRoomDoc,
} from '../types/flickorax.ts';

interface WatchPartyPageProps {
  mode: 'hub' | 'create' | 'join' | 'room';
  initialRoomCode?: string;
  onNavigate: (route: AppRoute) => void;
  onOpenDetails: (item: MediaRecommendation) => void;
}

function formatCountdown(ms: number): string {
  if (ms <= 0) return '00:00:00';
  const totalSec = Math.floor(ms / 1000);
  const hours = Math.floor(totalSec / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;
  return `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

export function WatchPartyPage({
  mode,
  initialRoomCode = '',
  onNavigate,
  onOpenDetails,
}: WatchPartyPageProps) {
  const { isLoggedIn, displayName, getRoomSession, setRoomSession } = useAuth();

  // Form states for Create / Join
  const [nickname, setNickname] = useState('');
  const [joinCode, setJoinCode] = useState(initialRoomCode);
  const [actionLoading, setActionLoading] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  // Active room real-time state
  const activeCode = useMemo(() => normalizeRoomCode(initialRoomCode), [initialRoomCode]);
  const activeSession = activeCode ? getRoomSession(activeCode) : null;

  const [room, setRoom] = useState<WatchPartyRoomDoc | null>(null);
  const [members, setMembers] = useState<RoomMemberDoc[]>([]);
  const [roomLoading, setRoomLoading] = useState(false);
  const [roomError, setRoomError] = useState<string | null>(null);
  const [expired, setExpired] = useState(false);
  const [remainingMs, setRemainingMs] = useState<number>(15 * 60 * 60 * 1000);

  // Local PreferencesForm state inside room (ALWAYS starts empty!)
  const [myPrefs, setMyPrefs] = useState<PreferencesInput>(() => createEmptyPreferences());
  const [submittingPicks, setSubmittingPicks] = useState(false);
  const [matchingNow, setMatchingNow] = useState(false);
  const [picksSavedToast, setPicksSavedToast] = useState(false);
  const [copiedType, setCopiedType] = useState<'code' | 'link' | null>(null);

  useEffect(() => {
    if (initialRoomCode && mode !== 'room') {
      setJoinCode(initialRoomCode);
    }
  }, [initialRoomCode, mode]);

  // If user opens a shared room URL and already has a guest/member session in memory for it, enter directly
  useEffect(() => {
    if (mode !== 'join' || !initialRoomCode) return;
    const code = normalizeRoomCode(initialRoomCode);
    if (code.length !== 6) return;
    const existing = getRoomSession(code);
    if (existing) {
      onNavigate({ page: 'watch-party', mode: 'room', roomCode: code });
    }
  }, [mode, initialRoomCode, getRoomSession, onNavigate]);

  // Live polling sync for active room (every 1.8s)
  useEffect(() => {
    if (mode !== 'room' || activeCode.length !== 6) return;

    if (!activeSession) {
      onNavigate({ page: 'watch-party', mode: 'join', roomCode: activeCode });
      return;
    }

    let cancelled = false;
    setRoomLoading((prev) => (room?.code === activeCode ? prev : true));
    setRoomError(null);
    setExpired(false);

    const syncRoom = async () => {
      try {
        const res = await fetchWatchPartyRoomStateApi(activeCode, activeSession.memberToken);
        if (cancelled) return;
        setRoomLoading(false);
        setRoom(res.room);
        setMembers(res.members);
        if (res.room.expiresAtMs) {
          const left = res.room.expiresAtMs - Date.now();
          setRemainingMs(left);
          if (left <= 0) setExpired(true);
        }
      } catch (err) {
        if (cancelled) return;
        setRoomLoading(false);
        const status = (err as Error & { statusCode?: number }).statusCode;
        if (status === 410) {
          setRoom(null);
          setExpired(true);
          setRoomSession(activeCode, null);
        } else if (status === 401 || status === 403) {
          setRoomSession(activeCode, null);
          onNavigate({ page: 'watch-party', mode: 'join', roomCode: activeCode });
        } else {
          setRoomError(err instanceof Error ? err.message : 'Unable to open room.');
        }
      }
    };

    void syncRoom();
    const interval = window.setInterval(syncRoom, 1800);
    return () => {
      cancelled = true;
      window.clearInterval(interval);
    };
  }, [mode, activeCode, activeSession, onNavigate, setRoomSession]);

  // Countdown tick every second
  useEffect(() => {
    if (mode !== 'room' || !room?.expiresAtMs) return;
    const expMs = room.expiresAtMs;
    const timer = window.setInterval(() => {
      const left = expMs - Date.now();
      setRemainingMs(left);
      if (left <= 0) {
        setExpired(true);
        window.clearInterval(timer);
      }
    }, 1000);
    return () => window.clearInterval(timer);
  }, [mode, room?.expiresAtMs]);

  const handleCreateRoom = async (e: FormEvent) => {
    e.preventDefault();
    setActionError(null);
    const effectiveName = isLoggedIn ? displayName : nickname.trim();
    if (!effectiveName) {
      setActionError('Please enter a guest nickname to create the room.');
      return;
    }

    setActionLoading(true);
    try {
      const created = await createWatchPartyRoomApi(effectiveName);
      if (created.memberToken) {
        setRoomSession(created.room.code, {
          memberId: created.myMemberId,
          memberToken: created.memberToken,
          name: effectiveName,
        });
      }
      setRoom(created.room);
      setMembers(created.members);
      setMyPrefs(createEmptyPreferences());
      onNavigate({ page: 'watch-party', mode: 'room', roomCode: created.room.code });
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to create room.');
    } finally {
      setActionLoading(false);
    }
  };

  const handleJoinRoom = async (e: FormEvent) => {
    e.preventDefault();
    setActionError(null);
    const effectiveName = isLoggedIn ? displayName : nickname.trim();
    if (!effectiveName) {
      setActionError('Please enter a guest nickname to join.');
      return;
    }
    if (!joinCode.trim()) {
      setActionError('Please enter the 6-character room code.');
      return;
    }

    setActionLoading(true);
    try {
      const cleanCode = normalizeRoomCode(joinCode);
      const existing = getRoomSession(cleanCode);
      const joined = await joinWatchPartyRoomApi(cleanCode, effectiveName, existing?.memberToken);
      if (joined.memberToken) {
        setRoomSession(joined.room.code, {
          memberId: joined.myMemberId,
          memberToken: joined.memberToken,
          name: effectiveName,
        });
      }
      setRoom(joined.room);
      setMembers(joined.members);
      setMyPrefs(createEmptyPreferences());
      onNavigate({ page: 'watch-party', mode: 'room', roomCode: joined.room.code });
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Failed to join room.');
    } finally {
      setActionLoading(false);
    }
  };

  const handleSubmitPicks = async (prefs: PreferencesInput) => {
    if (!activeSession || !room || expired) return;
    setSubmittingPicks(true);
    setActionError(null);
    try {
      const updated = await submitWatchPartyPicksApi(room.code, activeSession.memberToken, prefs);
      setRoom(updated.room);
      setMembers(updated.members);
      setPicksSavedToast(true);
      window.setTimeout(() => setPicksSavedToast(false), 3000);
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Could not submit your picks.');
    } finally {
      setSubmittingPicks(false);
    }
  };

  const handleHostMatch = async (excludeTitles: string[] = []) => {
    if (!activeSession || !room || room.hostId !== activeSession.memberId || expired) return;
    setActionError(null);
    setMatchingNow(true);
    setRoom((prev) => (prev ? { ...prev, status: 'matching', errorMessage: '' } : prev));
    try {
      const completed = await runWatchPartyMatchApi(
        room.code,
        activeSession.memberToken,
        excludeTitles
      );
      setRoom(completed.room);
      setMembers(completed.members);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Could not run group match.';
      setActionError(msg);
      setRoom((prev) => (prev ? { ...prev, status: 'waiting', errorMessage: msg } : prev));
    } finally {
      setMatchingNow(false);
    }
  };

  const copyValue = async (type: 'code' | 'link') => {
    if (!room) return;
    const text = type === 'code' ? room.code : `${window.location.origin}/?room=${room.code}`;
    try {
      await navigator.clipboard.writeText(text);
      setCopiedType(type);
      window.setTimeout(() => setCopiedType(null), 2000);
    } catch {
      // ignore clipboard errors
    }
  };

  // --- Hub View ---
  if (mode === 'hub') {
    return (
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-12 space-y-10">
        <div className="space-y-3">
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">Watch Party</h1>
          <p className="text-neutral-400 text-sm sm:text-base max-w-2xl">
            Watch together without endless scrolling. Up to 10 people can join a private room as guests or members, submit their tastes, and let Flickorax match everyone live—no account required.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="rounded-2xl bg-[#0d0d10] border border-white/12 p-7 space-y-5 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-xl bg-[#6D0F25]/25 border border-[#6D0F25] flex items-center justify-center text-[#e09aa9]">
                <Users className="w-6 h-6" />
              </div>
              <h2 className="font-display text-2xl font-semibold text-white">Create Room</h2>
              <p className="text-sm text-neutral-400 leading-relaxed">
                Enter a guest nickname (or use your account) to host a new Watch Party, share the 6-character room code, and launch the match whenever your group is ready.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate({ page: 'watch-party', mode: 'create' })}
              className="w-full py-3.5 px-5 rounded-xl bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] text-white font-semibold text-sm transition-colors cursor-pointer"
            >
              Create Room
            </button>
          </div>

          <div className="rounded-2xl bg-[#0d0d10] border border-white/12 p-7 space-y-5 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-12 h-12 rounded-xl bg-[#6D0F25]/25 border border-[#6D0F25] flex items-center justify-center text-[#e09aa9]">
                <UserPlus className="w-6 h-6" />
              </div>
              <h2 className="font-display text-2xl font-semibold text-white">Join Room</h2>
              <p className="text-sm text-neutral-400 leading-relaxed">
                Have a room code from a friend? Enter your guest nickname and the 6-character code (any letter case) to jump right in.
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate({ page: 'watch-party', mode: 'join' })}
              className="w-full py-3.5 px-5 rounded-xl bg-[#16161b] hover:bg-[#6D0F25] active:bg-[#4A0A19] border border-white/15 text-white font-semibold text-sm transition-colors cursor-pointer"
            >
              Join Room
            </button>
          </div>
        </div>
      </div>
    );
  }

  // --- Create Room View ---
  if (mode === 'create') {
    return (
      <div className="max-w-lg mx-auto px-4 sm:px-6 py-14 space-y-6">
        <div className="space-y-2">
          <h1 className="font-display text-3xl font-bold text-white">Create a Watch Party</h1>
          <p className="text-sm text-neutral-400">
            Rooms stay active for 15 hours and support up to 10 members including you. Guest login is instant—no signup needed.
          </p>
        </div>

        <form
          onSubmit={handleCreateRoom}
          className="rounded-2xl bg-[#0d0d10] border border-white/12 p-6 sm:p-7 space-y-5"
        >
          {isLoggedIn ? (
            <div className="rounded-xl bg-[#141418] border border-white/10 p-4 text-sm text-neutral-200">
              Hosting as <strong className="text-white">{displayName}</strong>
            </div>
          ) : (
            <div className="space-y-2">
              <label htmlFor="host-nickname" className="block text-sm font-medium text-neutral-200">
                Guest nickname
              </label>
              <input
                id="host-nickname"
                type="text"
                required
                maxLength={60}
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
                placeholder="e.g. Maya"
                className="w-full px-4 py-3 rounded-xl bg-black border border-white/15 text-sm text-white placeholder-neutral-500 focus:border-[#8C1A35] focus:outline-none"
              />
            </div>
          )}

          {actionError && (
            <div className="rounded-xl bg-[#380915] border border-[#8C1A35] p-3.5 text-xs text-white leading-relaxed">
              {actionError}
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-3">
            <button
              type="submit"
              disabled={actionLoading}
              className="flex-1 py-3.5 px-5 rounded-xl bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] disabled:opacity-60 text-white font-semibold text-sm transition-colors cursor-pointer"
            >
              {actionLoading ? 'Creating room...' : 'Create Guest Room'}
            </button>
            <button
              type="button"
              onClick={() => onNavigate({ page: 'watch-party', mode: 'join' })}
              className="py-3.5 px-5 rounded-xl bg-[#15151a] hover:bg-[#1f1f27] border border-white/15 text-neutral-200 font-medium text-sm transition-colors cursor-pointer"
            >
              Join instead
            </button>
          </div>
        </form>
      </div>
    );
  }

  // --- Join Room View ---
  if (mode === 'join') {
    return (
      <div className="max-w-lg mx-auto px-4 sm:px-6 py-14 space-y-6">
        <div className="space-y-2">
          <h1 className="font-display text-3xl font-bold text-white">Join a Watch Party</h1>
          <p className="text-sm text-neutral-400">
            Enter the 6-character room code from your host and a guest nickname. Letter case doesn&apos;t matter.
          </p>
        </div>

        <form
          onSubmit={handleJoinRoom}
          className="rounded-2xl bg-[#0d0d10] border border-white/12 p-6 sm:p-7 space-y-5"
        >
          <div className="space-y-2">
            <label htmlFor="join-room-code" className="block text-sm font-medium text-neutral-200">
              Room code
            </label>
            <input
              id="join-room-code"
              type="text"
              required
              maxLength={8}
              value={joinCode}
              onChange={(e) => setJoinCode(e.target.value)}
              placeholder="e.g. K7P2XM"
              className="w-full px-4 py-3 rounded-xl bg-black border border-white/15 text-lg font-mono-tabular tracking-widest uppercase text-white placeholder-neutral-500 focus:border-[#8C1A35] focus:outline-none"
            />
          </div>

          {isLoggedIn ? (
            <div className="rounded-xl bg-[#141418] border border-white/10 p-4 text-sm text-neutral-200">
              Joining as <strong className="text-white">{displayName}</strong>
            </div>
          ) : (
            <div className="space-y-2">
              <label htmlFor="guest-nickname" className="block text-sm font-medium text-neutral-200">
                Guest nickname
              </label>
              <input
                id="guest-nickname"
                type="text"
                required
                maxLength={60}
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
                placeholder="e.g. Jordan"
                className="w-full px-4 py-3 rounded-xl bg-black border border-white/15 text-sm text-white placeholder-neutral-500 focus:border-[#8C1A35] focus:outline-none"
              />
            </div>
          )}

          {actionError && (
            <div className="rounded-xl bg-[#380915] border border-[#8C1A35] p-3.5 text-xs text-white leading-relaxed">
              {actionError}
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-3">
            <button
              type="submit"
              disabled={actionLoading}
              className="flex-1 py-3.5 px-5 rounded-xl bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] disabled:opacity-60 text-white font-semibold text-sm transition-colors cursor-pointer"
            >
              {actionLoading ? 'Joining room...' : 'Join as Guest'}
            </button>
            <button
              type="button"
              onClick={() => onNavigate({ page: 'watch-party', mode: 'create' })}
              className="py-3.5 px-5 rounded-xl bg-[#15151a] hover:bg-[#1f1f27] border border-white/15 text-neutral-200 font-medium text-sm transition-colors cursor-pointer"
            >
              Create instead
            </button>
          </div>
        </form>
      </div>
    );
  }

  // --- Active Room View ---
  if (expired) {
    return (
      <div className="max-w-xl mx-auto px-4 sm:px-6 py-20 text-center space-y-5">
        <div className="w-14 h-14 rounded-2xl bg-[#380915] border border-[#8C1A35] flex items-center justify-center mx-auto text-white">
          <Clock className="w-6 h-6" />
        </div>
        <h1 className="font-display text-2xl sm:text-3xl font-bold text-white">
          This room has expired. Ask your host to create a new one.
        </h1>
        <p className="text-sm text-neutral-400">
          Watch Party rooms expire 15 hours after creation and their temporary data is removed automatically.
        </p>
        <button
          type="button"
          onClick={() => onNavigate({ page: 'watch-party', mode: 'create' })}
          className="px-6 py-3 rounded-xl bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] text-white font-medium text-sm transition-colors cursor-pointer"
        >
          Create a new room
        </button>
      </div>
    );
  }

  if (roomError) {
    return (
      <div className="max-w-xl mx-auto px-4 sm:px-6 py-20 text-center space-y-5">
        <AlertCircle className="w-10 h-10 text-[#e09aa9] mx-auto" />
        <h1 className="font-display text-2xl font-bold text-white">Unable to open room</h1>
        <p className="text-sm text-neutral-300">{roomError}</p>
        <button
          type="button"
          onClick={() => onNavigate({ page: 'watch-party', mode: 'join', roomCode: activeCode })}
          className="px-6 py-3 rounded-xl bg-[#6D0F25] hover:bg-[#8C1A35] text-white font-medium text-sm transition-colors cursor-pointer"
        >
          Go to Join Room
        </button>
      </div>
    );
  }

  if (roomLoading || !room) {
    return (
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-14 space-y-6">
        <div className="h-32 rounded-2xl bg-[#111114] border border-white/10 animate-pulse" />
        <div className="h-96 rounded-2xl bg-[#111114] border border-white/10 animate-pulse" />
      </div>
    );
  }

  const isHost = Boolean(activeSession && room.hostId === activeSession.memberId);
  const myMember = members.find((m) => m.uid === activeSession?.memberId);
  const readyCount = members.filter((m) => m.status === 'ready').length;
  const under30Min = remainingMs > 0 && remainingMs <= 30 * 60 * 1000;
  const formLocked = room.status !== 'waiting' || matchingNow;

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      {/* Room Header with Large Room Code, Copy, Share, Countdown */}
      <div className="rounded-2xl bg-[#0d0d10] border border-white/12 p-6 sm:p-8 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-3">
          <div className="text-xs font-medium text-neutral-400">Watch Party Room Code</div>
          <div className="flex flex-wrap items-center gap-4">
            <span className="font-mono-tabular text-4xl sm:text-5xl font-bold tracking-[0.2em] text-white">
              {room.code}
            </span>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => copyValue('code')}
                className="px-3.5 py-2 rounded-xl bg-[#17171c] hover:bg-[#6D0F25] border border-white/15 text-xs font-medium text-white inline-flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {copiedType === 'code' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedType === 'code' ? 'Copied' : 'Copy code'}</span>
              </button>
              <button
                type="button"
                onClick={() => copyValue('link')}
                className="px-3.5 py-2 rounded-xl bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] text-xs font-medium text-white inline-flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                {copiedType === 'link' ? <Check className="w-3.5 h-3.5" /> : <Link2 className="w-3.5 h-3.5" />}
                <span>{copiedType === 'link' ? 'Link copied' : 'Share link'}</span>
              </button>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-6">
          <div className="space-y-1">
            <div className="text-xs text-neutral-400">Members</div>
            <div className="font-mono-tabular text-xl font-bold text-white">
              {room.memberCount}/10 members
            </div>
          </div>
          <div className="space-y-1">
            <div className="text-xs text-neutral-400">Time left</div>
            <div className="font-mono-tabular text-xl font-bold text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#8C1A35]" />
              <span>{formatCountdown(remainingMs)}</span>
            </div>
          </div>
        </div>
      </div>

      {under30Min && (
        <div className="rounded-xl bg-[#380915] border border-[#8C1A35] px-4 py-3 text-sm text-white flex items-center gap-2.5">
          <Clock className="w-4 h-4 shrink-0" />
          <span>30 minutes or less remaining before this room expires automatically.</span>
        </div>
      )}

      {/* Live Member List + Host Action */}
      <div className="rounded-2xl bg-[#0b0b0e] border border-white/10 p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-display text-lg font-semibold text-white">Room Members</h2>
            <p className="text-xs text-neutral-400 mt-0.5">
              Members who haven&apos;t submitted count as &quot;no preference&quot; and never block the group.
            </p>
          </div>

          {isHost && (
            <button
              type="button"
              disabled={room.status === 'matching' || matchingNow}
              onClick={() => handleHostMatch()}
              className="px-6 py-3 rounded-xl bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] disabled:opacity-60 text-white font-semibold text-sm inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>
                {room.status === 'matching' || matchingNow
                  ? 'Matching group...'
                  : `Find Our Match (${readyCount}/${members.length} submitted)`}
              </span>
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {members.map((m) => (
            <div
              key={m.uid}
              className="rounded-xl bg-[#131317] border border-white/10 px-4 py-3 flex items-center justify-between gap-3"
            >
              <div className="min-w-0">
                <div className="text-sm font-medium text-white truncate">
                  {m.name} {m.isHost ? '(Host)' : ''}
                </div>
              </div>
              <span
                className={`text-xs font-medium shrink-0 ${
                  m.status === 'ready' ? 'text-[#e09aa9]' : 'text-neutral-400'
                }`}
              >
                {m.status === 'ready' ? 'ready' : 'choosing...'}
              </span>
            </div>
          ))}
        </div>

        {(actionError || room.errorMessage) && (
          <div className="rounded-xl bg-[#380915] border border-[#8C1A35] p-3.5 text-xs text-white">
            {actionError || room.errorMessage}
          </div>
        )}
      </div>

      {/* Synced Results Section */}
      {(room.status === 'matching' || matchingNow) && (
        <div className="rounded-2xl bg-[#0d0d10] border border-[#6D0F25] p-8 text-center space-y-3">
          <RefreshCw className="w-7 h-7 text-[#8C1A35] animate-spin mx-auto" />
          <h2 className="font-display text-xl font-semibold text-white">
            Finding 5 matches for the whole group...
          </h2>
          <p className="text-sm text-neutral-400">
            Merging everyone&apos;s picks and verifying titles in TMDB & AniList.
          </p>
        </div>
      )}

      {room.status === 'matched' && !matchingNow && room.results && room.results.length > 0 && (
        <section className="space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h2 className="font-display text-2xl sm:text-3xl font-bold text-white">
                Group Recommendations
              </h2>
              <p className="text-sm text-neutral-400 mt-1">
                Synced live for everyone in room {room.code}.
              </p>
            </div>
            {isHost && (
              <button
                type="button"
                onClick={() => handleHostMatch(room.results.map((r) => r.title))}
                className="px-5 py-2.5 rounded-xl bg-[#6D0F25] hover:bg-[#8C1A35] active:bg-[#4A0A19] text-white text-sm font-medium inline-flex items-center gap-2 transition-colors cursor-pointer"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Try again</span>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {room.results.map((item) => (
              <MediaCard
                key={item.externalId}
                item={item}
                reasonLabel="Why this suits the group"
                onMoreDetails={onOpenDetails}
              />
            ))}
          </div>
        </section>
      )}

      {/* Room Preferences Form (Shared Form, starts empty, editable until host starts match) */}
      <section className="space-y-4 pt-4 border-t border-white/10">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="font-display text-2xl font-bold text-white">Your Room Picks</h2>
            <p className="text-sm text-neutral-400">
              {formLocked
                ? 'The host has started matching—picks are now locked for this round.'
                : 'Fill in only what you feel like watching tonight, then tap Submit my picks. You can edit until the host starts the match.'}
            </p>
          </div>
          {picksSavedToast && (
            <span className="text-xs font-medium text-[#e09aa9]">
              Your picks are submitted!
            </span>
          )}
        </div>

        <PreferencesForm
          value={myPrefs}
          onChange={setMyPrefs}
          onSubmit={handleSubmitPicks}
          submitLabel={myMember?.status === 'ready' ? 'Update my picks' : 'Submit my picks'}
          loading={submittingPicks}
          disabled={formLocked}
          showSavedPrefsButton={false}
        />
      </section>
    </div>
  );
}
