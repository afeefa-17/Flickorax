import type {
  MediaDetails,
  MediaRecommendation,
  MediaTypeChoice,
  MoodChoice,
  PreferencesInput,
  RecommendationResponse,
  SavedPreferencesDoc,
} from '../types/flickorax.ts';

const SESSION_CACHE_PREFIX = 'flickorax_session_cache_v1:';
const DEFAULT_TTL_MS = 15 * 60 * 1000; // 15 minutes
const SURPRISE_TTL_MS = 5 * 60 * 1000; // 5 minutes
const MAX_CACHE_ENTRIES = 60;

interface CacheEntry<T> {
  value: T;
  expiresAt: number;
}

const memoryCache = new Map<string, CacheEntry<unknown>>();
const inflightRequests = new Map<string, Promise<unknown>>();

export interface RetryOptions {
  maxRetries?: number;
  baseDelayMs?: number;
  signal?: AbortSignal;
  onRetry?: (attempt: number, maxRetries: number, delayMs: number) => void;
}

function isRetryableStatus(status: number): boolean {
  return status === 429 || status === 502 || status === 503 || status === 504;
}

function isRetryableMessage(message: string): boolean {
  const lower = message.toLowerCase();
  return (
    lower.includes('503') ||
    lower.includes('unavailable') ||
    lower.includes('high demand') ||
    lower.includes('temporarily busy') ||
    lower.includes('resource_exhausted') ||
    lower.includes('429')
  );
}

function computeExponentialBackoff(attempt: number, baseDelayMs: number): number {
  const exp = baseDelayMs * Math.pow(2, attempt);
  const jitter = Math.floor(Math.random() * 200);
  return Math.round(exp + jitter);
}

async function sleepWithAbort(ms: number, signal?: AbortSignal): Promise<void> {
  if (signal?.aborted) {
    throw new DOMException('Aborted', 'AbortError');
  }
  await new Promise<void>((resolve, reject) => {
    const timer = window.setTimeout(() => {
      signal?.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    const onAbort = () => {
      window.clearTimeout(timer);
      reject(new DOMException('Aborted', 'AbortError'));
    };
    signal?.addEventListener('abort', onAbort, { once: true });
  });
}

/**
 * Performs a fetch returning parsed JSON, automatically retrying transient 503/429/network
 * errors with exponential backoff and jitter.
 */
export async function fetchJsonWithBackoff<T>(
  input: string,
  init: RequestInit = {},
  options: RetryOptions = {}
): Promise<T> {
  const maxRetries = options.maxRetries ?? 3;
  const baseDelayMs = options.baseDelayMs ?? 600;
  const signal = options.signal ?? init.signal ?? undefined;

  let lastError: Error = new Error('Request failed.');

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    if (signal?.aborted) {
      throw new DOMException('Aborted', 'AbortError');
    }

    try {
      const res = await fetch(input, { ...init, signal });
      const data = (await res.json().catch(() => ({}))) as T & { error?: string };

      if (res.ok) {
        return data;
      }

      const errorMessage = data?.error || `Request failed with status ${res.status}.`;
      const err = new Error(errorMessage) as Error & { statusCode?: number };
      err.statusCode = res.status;
      lastError = err;

      const shouldRetry =
        attempt < maxRetries &&
        (isRetryableStatus(res.status) || isRetryableMessage(errorMessage));

      if (!shouldRetry) {
        throw err;
      }
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError') {
        throw err;
      }
      const normalized = err instanceof Error ? err : new Error('Network error occurred.');
      lastError = normalized;

      const status = (normalized as Error & { statusCode?: number }).statusCode;
      const isNonRetryableClientError = status !== undefined && status >= 400 && status < 500 && status !== 429;

      if (attempt >= maxRetries || isNonRetryableClientError) {
        throw normalized;
      }
    }

    const delayMs = computeExponentialBackoff(attempt, baseDelayMs);
    options.onRetry?.(attempt + 1, maxRetries, delayMs);
    await sleepWithAbort(delayMs, signal);
  }

  throw lastError;
}

function normalizeStringArray(arr: string[] | undefined): string[] {
  if (!Array.isArray(arr)) return [];
  return [...arr].map((s) => s.trim()).filter(Boolean).sort();
}

function buildCanonicalSoloKey(prefs: PreferencesInput, excludeTitles: string[]): string {
  return JSON.stringify({
    type: prefs.type,
    languages: normalizeStringArray(prefs.languages),
    subtitlesFine: Boolean(prefs.subtitlesFine),
    genres: normalizeStringArray(prefs.genres),
    moods: normalizeStringArray(prefs.moods),
    releasePeriod: prefs.releasePeriod.anyYear
      ? { anyYear: true }
      : {
          anyYear: false,
          fromYear: prefs.releasePeriod.fromYear,
          toYear: prefs.releasePeriod.toYear,
        },
    duration: prefs.duration || '',
    minRating: prefs.minRating ?? null,
    countries: normalizeStringArray(prefs.countries),
    storyPreference: prefs.storyPreference.trim().toLowerCase(),
    excludeTitles: normalizeStringArray(excludeTitles.map((t) => t.toLowerCase())),
  });
}

function readSessionCache<T>(cacheKey: string): T | null {
  const now = Date.now();
  const memHit = memoryCache.get(cacheKey);
  if (memHit) {
    if (now < memHit.expiresAt) {
      return memHit.value as T;
    }
    memoryCache.delete(cacheKey);
  }

  try {
    const raw = window.sessionStorage.getItem(`${SESSION_CACHE_PREFIX}${cacheKey}`);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as CacheEntry<T>;
    if (!parsed || typeof parsed.expiresAt !== 'number' || now >= parsed.expiresAt) {
      window.sessionStorage.removeItem(`${SESSION_CACHE_PREFIX}${cacheKey}`);
      return null;
    }
    memoryCache.set(cacheKey, parsed);
    return parsed.value;
  } catch {
    return null;
  }
}

function writeSessionCache<T>(cacheKey: string, value: T, ttlMs: number): void {
  const entry: CacheEntry<T> = {
    value,
    expiresAt: Date.now() + ttlMs,
  };

  if (memoryCache.has(cacheKey)) {
    memoryCache.delete(cacheKey);
  } else if (memoryCache.size >= MAX_CACHE_ENTRIES) {
    const oldest = memoryCache.keys().next().value;
    if (oldest) memoryCache.delete(oldest);
  }
  memoryCache.set(cacheKey, entry);

  try {
    window.sessionStorage.setItem(`${SESSION_CACHE_PREFIX}${cacheKey}`, JSON.stringify(entry));
  } catch {
    // Ignore sessionStorage quota / private browsing restrictions
  }
}

async function withSessionCache<T>(
  cacheKey: string,
  ttlMs: number,
  isCacheable: (value: T) => boolean,
  fetcher: () => Promise<T>
): Promise<T> {
  const cached = readSessionCache<T>(cacheKey);
  if (cached !== null) {
    return cached;
  }

  const inflight = inflightRequests.get(cacheKey);
  if (inflight) {
    return (await inflight) as T;
  }

  const promise = (async () => {
    const result = await fetcher();
    if (isCacheable(result)) {
      writeSessionCache(cacheKey, result, ttlMs);
    }
    return result;
  })();

  inflightRequests.set(cacheKey, promise);
  try {
    return await promise;
  } finally {
    inflightRequests.delete(cacheKey);
  }
}

export async function fetchSoloRecommendations(
  preferences: PreferencesInput,
  excludeTitles: string[] = [],
  options: RetryOptions = {}
): Promise<RecommendationResponse> {
  const key = `solo:${buildCanonicalSoloKey(preferences, excludeTitles)}`;
  return withSessionCache<RecommendationResponse>(
    key,
    DEFAULT_TTL_MS,
    (data) => Array.isArray(data.items) && data.items.length > 0,
    () =>
      fetchJsonWithBackoff<RecommendationResponse>(
        '/api/recommendations',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ preferences, excludeTitles }),
        },
        options
      )
  );
}

export async function fetchSurpriseRecommendations(
  mood: MoodChoice,
  type: MediaTypeChoice,
  excludeTitles: string[] = [],
  options: RetryOptions = {}
): Promise<RecommendationResponse> {
  const key = `surprise:${JSON.stringify({
    mood,
    type,
    excludeTitles: normalizeStringArray(excludeTitles.map((t) => t.toLowerCase())),
  })}`;

  return withSessionCache<RecommendationResponse>(
    key,
    SURPRISE_TTL_MS,
    (data) => Array.isArray(data.items) && data.items.length > 0,
    () =>
      fetchJsonWithBackoff<RecommendationResponse>(
        '/api/surprise',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ mood, type, excludeTitles }),
        },
        options
      )
  );
}

export async function fetchBecauseYouLiked(
  watchlist: { title: string; mediaType: string; genres: string[] }[],
  savedPreferences?: Partial<SavedPreferencesDoc> | null,
  options: RetryOptions = {}
): Promise<{ items: MediaRecommendation[] }> {
  const key = `because:${JSON.stringify({
    watchlist: watchlist
      .slice(0, 20)
      .map((w) => `${w.title}:${w.mediaType}`)
      .sort(),
    languages: normalizeStringArray(savedPreferences?.languages),
    genres: normalizeStringArray(savedPreferences?.genres),
    moods: normalizeStringArray(savedPreferences?.moods),
    countries: normalizeStringArray(savedPreferences?.countries),
  })}`;

  return withSessionCache<{ items: MediaRecommendation[] }>(
    key,
    DEFAULT_TTL_MS,
    (data) => Array.isArray(data.items) && data.items.length > 0,
    () =>
      fetchJsonWithBackoff<{ items: MediaRecommendation[] }>(
        '/api/because-you-liked',
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ watchlist, savedPreferences: savedPreferences || null }),
        },
        options
      )
  );
}

export async function fetchTrendingMedia(
  options: RetryOptions = {}
): Promise<{ items: MediaRecommendation[]; tmdbConfigured: boolean }> {
  return withSessionCache<{ items: MediaRecommendation[]; tmdbConfigured: boolean }>(
    'trending:weekly',
    DEFAULT_TTL_MS,
    (data) => Array.isArray(data.items) && data.items.length > 0,
    () => fetchJsonWithBackoff<{ items: MediaRecommendation[]; tmdbConfigured: boolean }>('/api/trending', {}, options)
  );
}

export async function fetchMediaDetails(
  source: 'tmdb' | 'anilist',
  mediaType: string,
  externalId: string,
  options: RetryOptions = {}
): Promise<MediaDetails> {
  const key = `details:${source}:${mediaType}:${externalId}`;
  return withSessionCache<MediaDetails>(
    key,
    DEFAULT_TTL_MS,
    (data) => Boolean(data && data.externalId),
    () =>
      fetchJsonWithBackoff<MediaDetails>(
        `/api/details/${source}/${mediaType}/${encodeURIComponent(externalId)}`,
        {},
        options
      )
  );
}

export function clearRecommendationSessionCache(): void {
  memoryCache.clear();
  try {
    const keysToRemove: string[] = [];
    for (let i = 0; i < window.sessionStorage.length; i++) {
      const k = window.sessionStorage.key(i);
      if (k && k.startsWith(SESSION_CACHE_PREFIX)) {
        keysToRemove.push(k);
      }
    }
    for (const k of keysToRemove) {
      window.sessionStorage.removeItem(k);
    }
  } catch {
    // ignore storage errors
  }
}
