import {
  FALLBACK_COUNTRIES,
  FALLBACK_GENRES,
  FALLBACK_LANGUAGES,
} from '../data/fallbackOptions.ts';
import type { CatalogOptionsResponse } from '../types/flickorax.ts';

const CACHE_KEY = 'flickorax_catalog_options_v2';
const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;

export async function loadCatalogOptions(): Promise<CatalogOptionsResponse> {
  try {
    const raw = localStorage.getItem(CACHE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as CatalogOptionsResponse;
      if (
        parsed &&
        Array.isArray(parsed.genres) &&
        parsed.genres.length > 0 &&
        Array.isArray(parsed.languages) &&
        Array.isArray(parsed.countries) &&
        Date.now() - parsed.cachedAt < SEVEN_DAYS_MS
      ) {
        return parsed;
      }
    }
  } catch {
    // ignore storage errors
  }

  try {
    const res = await fetch('/api/options');
    if (!res.ok) throw new Error('Failed to fetch catalog options');
    const data = (await res.json()) as CatalogOptionsResponse;
    try {
      localStorage.setItem(CACHE_KEY, JSON.stringify(data));
    } catch {
      // ignore storage quota errors
    }
    return data;
  } catch {
    return {
      genres: FALLBACK_GENRES,
      languages: FALLBACK_LANGUAGES,
      countries: FALLBACK_COUNTRIES,
      tmdbConfigured: false,
      cachedAt: Date.now(),
    };
  }
}
