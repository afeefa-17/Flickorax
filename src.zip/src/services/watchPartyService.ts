import type { MediaRecommendation, PreferencesInput, RoomMemberDoc, WatchPartyRoomDoc } from '../types/flickorax.ts';
import { fetchJsonWithBackoff } from './recommendationService.ts';

export function normalizeRoomCode(input: string): string {
  return input.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
}

export interface RoomActionResponse {
  room: WatchPartyRoomDoc;
  members: RoomMemberDoc[];
  myMemberId: string;
  memberToken?: string;
}

export async function createWatchPartyRoomApi(nickname: string): Promise<RoomActionResponse> {
  const res = await fetch('/api/watch-party/rooms', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nickname }),
  });
  const data = (await res.json()) as RoomActionResponse & { error?: string };
  if (!res.ok) {
    throw new Error(data.error || 'Failed to create room.');
  }
  return data;
}

export async function joinWatchPartyRoomApi(
  roomCodeInput: string,
  nickname: string,
  existingToken?: string
): Promise<RoomActionResponse> {
  const code = normalizeRoomCode(roomCodeInput);
  if (!/^[A-HJ-NP-Z2-9]{6}$/.test(code)) {
    throw new Error('Please enter a valid 6-character room code.');
  }

  const res = await fetch(`/api/watch-party/rooms/${encodeURIComponent(code)}/join`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ nickname, existingToken }),
  });
  const data = (await res.json()) as RoomActionResponse & { error?: string };
  if (!res.ok) {
    throw new Error(data.error || 'Failed to join room.');
  }
  return data;
}

export async function fetchWatchPartyRoomStateApi(
  roomCode: string,
  memberToken: string
): Promise<{ room: WatchPartyRoomDoc; members: RoomMemberDoc[]; myMemberId: string; statusCode: number }> {
  const code = normalizeRoomCode(roomCode);
  const res = await fetch(`/api/watch-party/rooms/${encodeURIComponent(code)}`, {
    headers: { Authorization: `Bearer ${memberToken}` },
  });
  const data = (await res.json().catch(() => ({}))) as {
    room?: WatchPartyRoomDoc;
    members?: RoomMemberDoc[];
    myMemberId?: string;
    error?: string;
  };
  if (!res.ok || !data.room) {
    const err = new Error(data.error || 'Unable to load Watch Party room.') as Error & { statusCode?: number };
    err.statusCode = res.status;
    throw err;
  }
  return {
    room: data.room,
    members: data.members || [],
    myMemberId: data.myMemberId || '',
    statusCode: res.status,
  };
}

export async function submitWatchPartyPicksApi(
  roomCode: string,
  memberToken: string,
  preferences: PreferencesInput
): Promise<{ room: WatchPartyRoomDoc; members: RoomMemberDoc[]; myMemberId: string }> {
  const code = normalizeRoomCode(roomCode);
  const res = await fetch(`/api/watch-party/rooms/${encodeURIComponent(code)}/picks`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${memberToken}`,
    },
    body: JSON.stringify({ preferences }),
  });
  const data = (await res.json()) as {
    room?: WatchPartyRoomDoc;
    members?: RoomMemberDoc[];
    myMemberId?: string;
    error?: string;
  };
  if (!res.ok || !data.room) {
    throw new Error(data.error || 'Could not submit your picks.');
  }
  return {
    room: data.room,
    members: data.members || [],
    myMemberId: data.myMemberId || '',
  };
}

export async function runWatchPartyMatchApi(
  roomCode: string,
  memberToken: string,
  excludeTitles: string[] = []
): Promise<{ room: WatchPartyRoomDoc; members: RoomMemberDoc[]; results?: MediaRecommendation[] }> {
  const code = normalizeRoomCode(roomCode);
  const data = await fetchJsonWithBackoff<{
    room?: WatchPartyRoomDoc;
    members?: RoomMemberDoc[];
    error?: string;
  }>(
    `/api/watch-party/rooms/${encodeURIComponent(code)}/match`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${memberToken}`,
      },
      body: JSON.stringify({ excludeTitles }),
    },
    { maxRetries: 2, baseDelayMs: 600 }
  );
  if (!data.room) {
    throw new Error(data.error || 'Group match failed.');
  }
  return {
    room: data.room,
    members: data.members || [],
  };
}
