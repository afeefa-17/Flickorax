export type MediaTypeChoice = 'Movies' | 'Anime' | 'Series' | 'Dramas' | 'Anything';

export type MoodChoice =
  | 'Happy'
  | 'Sad'
  | 'Romantic'
  | 'Thrilling'
  | 'Relaxed'
  | 'Surprise me';

export type DurationChoice = 'Short' | 'Medium' | 'Long';

export interface PreferencesInput {
  type: MediaTypeChoice;
  languages: string[];
  subtitlesFine: boolean;
  genres: string[];
  moods: MoodChoice[];
  releasePeriod: {
    anyYear: boolean;
    fromYear: number;
    toYear: number;
  };
  duration: DurationChoice | '';
  minRating: number | null;
  countries: string[];
  storyPreference: string;
}

export interface GenreOption {
  name: string;
  types: ('movies' | 'series' | 'dramas' | 'anime')[];
  tmdbMovieId?: number;
  tmdbTvId?: number;
  isAnimeSpecific?: boolean;
}

export interface LanguageOption {
  code: string;
  englishName: string;
  nativeName?: string;
}

export interface CountryOption {
  code: string;
  name: string;
}

export interface CatalogOptionsResponse {
  genres: GenreOption[];
  languages: LanguageOption[];
  countries: CountryOption[];
  tmdbConfigured: boolean;
  cachedAt: number;
}

export interface MediaRecommendation {
  externalId: string;
  source: 'tmdb' | 'anilist';
  mediaType: 'movie' | 'series' | 'drama' | 'anime';
  title: string;
  year: string;
  posterUrl: string;
  backdropUrl?: string;
  genres: string[];
  rating: number;
  overview: string;
  reason: string;
  basedOnTitle?: string;
}

export interface MediaDetails extends MediaRecommendation {
  fullDescription: string;
  cast: { name: string; role: string; profileUrl?: string }[];
  runtimeOrEpisodes: string;
  watchProviders: {
    providerName: string;
    logoUrl?: string;
    link?: string;
    type: string;
  }[];
  country?: string;
  originalLanguage?: string;
}

export interface RecommendationResponse {
  items: MediaRecommendation[];
  relaxedFilters: string[];
  notice?: string;
  tmdbConfigured: boolean;
}

export interface SavedPreferencesDoc {
  userId: string;
  languages: string[];
  subtitlesFine: boolean;
  genres: string[];
  moods: MoodChoice[];
  countries: string[];
  updatedAt?: unknown;
}

export interface WatchlistItemDoc {
  userId: string;
  externalId: string;
  source: 'tmdb' | 'anilist';
  mediaType: 'movie' | 'series' | 'drama' | 'anime';
  title: string;
  year: string;
  posterUrl: string;
  genres: string[];
  rating: number;
  overview: string;
  reason?: string;
  addedAt?: unknown;
}

export interface WatchPartyRoomDoc {
  code: string;
  hostId: string;
  hostName: string;
  memberIds: string[];
  memberCount: number;
  status: 'waiting' | 'matching' | 'matched';
  results: MediaRecommendation[];
  errorMessage?: string;
  createdAt?: unknown;
  expiresAt?: unknown;
  expiresAtMs?: number;
  updatedAt?: unknown;
}

export interface RoomMemberDoc {
  uid: string;
  name: string;
  isHost: boolean;
  status: 'choosing' | 'ready';
  preferences?: PreferencesInput | null;
  joinedAt?: unknown;
  updatedAt?: unknown;
}

export const CURRENT_YEAR = new Date().getFullYear();

export function createEmptyPreferences(): PreferencesInput {
  return {
    type: 'Anything',
    languages: [],
    subtitlesFine: false,
    genres: [],
    moods: [],
    releasePeriod: {
      anyYear: true,
      fromYear: 1990,
      toYear: CURRENT_YEAR,
    },
    duration: '',
    minRating: null,
    countries: [],
    storyPreference: '',
  };
}
