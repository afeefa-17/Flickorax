import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import {
  createUserWithEmailAndPassword,
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
  type User,
} from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
} from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../lib/firebase.ts';
import type {
  MediaRecommendation,
  PreferencesInput,
  SavedPreferencesDoc,
  WatchlistItemDoc,
} from '../types/flickorax.ts';

interface LocalSession {
  user: {
    uid: string;
    email: string;
    displayName: string;
  };
  token: string;
}

export interface WatchPartyMemberSession {
  memberId: string;
  memberToken: string;
  name: string;
}

interface AuthContextValue {
  user: User | null;
  authReady: boolean;
  isLoggedIn: boolean;
  displayName: string;
  savedPreferences: SavedPreferencesDoc | null;
  watchlist: WatchlistItemDoc[];
  authModalOpen: boolean;
  authModalMessage: string | null;
  openAuthModal: (message?: string) => void;
  closeAuthModal: () => void;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  signUpWithEmail: (name: string, email: string, password: string) => Promise<void>;
  logOut: () => Promise<void>;
  saveUserPreferences: (prefs: PreferencesInput) => Promise<void>;
  addToWatchlist: (item: MediaRecommendation) => Promise<void>;
  removeFromWatchlist: (externalId: string) => Promise<void>;
  isInWatchlist: (externalId: string) => boolean;
  getRoomSession: (roomCode: string) => WatchPartyMemberSession | null;
  setRoomSession: (roomCode: string, session: WatchPartyMemberSession | null) => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [firebaseUser, setFirebaseUser] = useState<User | null>(null);
  const [localSession, setLocalSession] = useState<LocalSession | null>(null);
  const [firebaseEmailDisabled, setFirebaseEmailDisabled] = useState(false);
  const [authReady, setAuthReady] = useState(false);
  const [savedPreferences, setSavedPreferences] = useState<SavedPreferencesDoc | null>(null);
  const [watchlist, setWatchlist] = useState<WatchlistItemDoc[]>([]);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authModalMessage, setAuthModalMessage] = useState<string | null>(null);
  const [roomSessions, setRoomSessions] = useState<Record<string, WatchPartyMemberSession>>({});

  const isFirebaseSignedIn = Boolean(firebaseUser && !firebaseUser.isAnonymous);
  const isLoggedIn = isFirebaseSignedIn || Boolean(localSession);
  const displayName = isFirebaseSignedIn
    ? firebaseUser?.displayName || firebaseUser?.email?.split('@')[0] || 'Member'
    : localSession
    ? localSession.user.displayName
    : 'Guest';

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setFirebaseUser(u);
      setAuthReady(true);
      if ((!u || u.isAnonymous) && !localSession) {
        setSavedPreferences(null);
        setWatchlist([]);
      }
    });
    return unsub;
  }, [localSession]);

  // Firestore subscription when signed in with Firebase (e.g., Google)
  useEffect(() => {
    if (!authReady || !firebaseUser || firebaseUser.isAnonymous) return;

    const prefPath = `users/${firebaseUser.uid}/preferences/saved`;
    getDoc(doc(db, 'users', firebaseUser.uid, 'preferences', 'saved'))
      .then((snap) => {
        if (snap.exists()) {
          setSavedPreferences(snap.data() as SavedPreferencesDoc);
        } else {
          setSavedPreferences(null);
        }
      })
      .catch((err) => {
        console.warn('Could not fetch saved preferences:', err);
      });

    const watchlistPath = `users/${firebaseUser.uid}/watchlist`;
    const q = query(collection(db, watchlistPath), orderBy('addedAt', 'desc'));
    const unsubWatchlist = onSnapshot(
      q,
      (snap) => {
        const items: WatchlistItemDoc[] = snap.docs.map((d) => d.data() as WatchlistItemDoc);
        setWatchlist(items);
      },
      (err) => {
        handleFirestoreError(err, OperationType.LIST, `${watchlistPath} (${prefPath})`);
      }
    );

    return () => unsubWatchlist();
  }, [authReady, firebaseUser]);

  // Server fetch when signed in via local Email/Password session
  useEffect(() => {
    if (!localSession || isFirebaseSignedIn) return;
    let cancelled = false;
    fetch('/api/user/data', {
      headers: { Authorization: `Bearer ${localSession.token}` },
    })
      .then((r) => (r.ok ? r.json() : null))
      .then((data: { savedPreferences?: SavedPreferencesDoc | null; watchlist?: WatchlistItemDoc[] } | null) => {
        if (!cancelled && data) {
          setSavedPreferences(data.savedPreferences || null);
          setWatchlist(data.watchlist || []);
        }
      })
      .catch(() => {});

    return () => {
      cancelled = true;
    };
  }, [localSession, isFirebaseSignedIn]);

  const openAuthModal = useCallback((message?: string) => {
    setAuthModalMessage(message || null);
    setAuthModalOpen(true);
  }, []);

  const closeAuthModal = useCallback(() => {
    setAuthModalOpen(false);
    setAuthModalMessage(null);
  }, []);

  const signInWithGoogle = useCallback(async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
      setLocalSession(null);
      setAuthModalOpen(false);
      setAuthModalMessage(null);
    } catch (err) {
      const code = (err as { code?: string })?.code || '';
      if (code === 'auth/popup-blocked') {
        throw new Error(
          'Your browser blocked the Google sign-in popup. Allow popups for this site or log in with email and password below.'
        );
      }
      if (code === 'auth/popup-closed-by-user' || code === 'auth/cancelled-popup-request') {
        throw new Error('Google sign-in was cancelled before finishing. Try again or use email login below.');
      }
      if (code === 'auth/unauthorized-domain') {
        throw new Error(
          `Add "${window.location.hostname}" under Firebase Console -> Authentication -> Settings -> Authorized domains, or sign in with email and password below.`
        );
      }
      if (code === 'auth/operation-not-allowed') {
        throw new Error(
          'Google sign-in is currently disabled in Firebase Console. Please sign in with email and password below.'
        );
      }
      throw err;
    }
  }, []);

  const signInLocalApi = async (email: string, password: string) => {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: email.trim(), password }),
    });
    const data = (await res.json()) as {
      user?: LocalSession['user'];
      token?: string;
      error?: string;
    };
    if (!res.ok || !data.user || !data.token) {
      throw new Error(data.error || 'Invalid email or password.');
    }
    setLocalSession({ user: data.user, token: data.token });
    setAuthModalOpen(false);
    setAuthModalMessage(null);
  };

  const signUpLocalApi = async (name: string, email: string, password: string) => {
    const res = await fetch('/api/auth/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: name.trim(), email: email.trim(), password }),
    });
    const data = (await res.json()) as {
      user?: LocalSession['user'];
      token?: string;
      error?: string;
    };
    if (!res.ok || !data.user || !data.token) {
      throw new Error(data.error || 'Could not create account.');
    }
    setLocalSession({ user: data.user, token: data.token });
    setSavedPreferences(null);
    setWatchlist([]);
    setAuthModalOpen(false);
    setAuthModalMessage(null);
  };

  const signInWithEmail = useCallback(
    async (email: string, password: string) => {
      if (firebaseEmailDisabled) {
        await signInLocalApi(email, password);
        return;
      }
      try {
        await signInWithEmailAndPassword(auth, email.trim(), password);
        setLocalSession(null);
        setAuthModalOpen(false);
        setAuthModalMessage(null);
      } catch (err) {
        const code = (err as { code?: string })?.code || '';
        if (
          code === 'auth/operation-not-allowed' ||
          code === 'auth/admin-restricted-operation'
        ) {
          setFirebaseEmailDisabled(true);
          await signInLocalApi(email, password);
          return;
        }
        if (code === 'auth/invalid-credential' || code === 'auth/user-not-found') {
          try {
            await signInLocalApi(email, password);
            return;
          } catch {
            throw new Error('Invalid email or password.');
          }
        }
        throw err;
      }
    },
    [firebaseEmailDisabled]
  );

  const signUpWithEmail = useCallback(
    async (name: string, email: string, password: string) => {
      if (firebaseEmailDisabled) {
        await signUpLocalApi(name, email, password);
        return;
      }
      try {
        const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
        if (name.trim()) {
          await updateProfile(cred.user, { displayName: name.trim().slice(0, 60) });
          setFirebaseUser({ ...cred.user, displayName: name.trim().slice(0, 60) } as User);
        }
        setLocalSession(null);
        setAuthModalOpen(false);
        setAuthModalMessage(null);
      } catch (err) {
        const code = (err as { code?: string })?.code || '';
        if (
          code === 'auth/operation-not-allowed' ||
          code === 'auth/admin-restricted-operation'
        ) {
          setFirebaseEmailDisabled(true);
          await signUpLocalApi(name, email, password);
          return;
        }
        throw err;
      }
    },
    [firebaseEmailDisabled]
  );

  const logOut = useCallback(async () => {
    if (localSession) {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: { Authorization: `Bearer ${localSession.token}` },
      }).catch(() => {});
      setLocalSession(null);
      setSavedPreferences(null);
      setWatchlist([]);
    }
    if (firebaseUser) {
      await signOut(auth).catch(() => {});
    }
  }, [localSession, firebaseUser]);

  // Saves ONLY language, genres, mood, and country (never type or storyPreference)
  const saveUserPreferences = useCallback(
    async (prefs: PreferencesInput) => {
      if (isFirebaseSignedIn && firebaseUser) {
        const path = `users/${firebaseUser.uid}/preferences/saved`;
        const payload = {
          userId: firebaseUser.uid,
          languages: prefs.languages.slice(0, 30),
          subtitlesFine: Boolean(prefs.subtitlesFine),
          genres: prefs.genres.slice(0, 40),
          moods: prefs.moods.slice(0, 10),
          countries: prefs.countries.slice(0, 30),
          updatedAt: serverTimestamp(),
        };
        try {
          await setDoc(doc(db, 'users', firebaseUser.uid, 'preferences', 'saved'), payload);
          setSavedPreferences({ ...payload, updatedAt: new Date() });
        } catch (err) {
          handleFirestoreError(err, OperationType.WRITE, path);
        }
        return;
      }

      if (localSession) {
        const res = await fetch('/api/user/preferences', {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${localSession.token}`,
          },
          body: JSON.stringify({ preferences: prefs }),
        });
        if (res.ok) {
          const data = (await res.json()) as { savedPreferences?: SavedPreferencesDoc };
          if (data.savedPreferences) setSavedPreferences(data.savedPreferences);
        }
      }
    },
    [isFirebaseSignedIn, firebaseUser, localSession]
  );

  const addToWatchlist = useCallback(
    async (item: MediaRecommendation) => {
      if (!isLoggedIn) {
        openAuthModal('Log in to save this');
        return;
      }

      if (isFirebaseSignedIn && firebaseUser) {
        const safeId = item.externalId.replace(/[^a-zA-Z0-9_-]/g, '-').slice(0, 100);
        const path = `users/${firebaseUser.uid}/watchlist/${safeId}`;
        try {
          await setDoc(doc(db, 'users', firebaseUser.uid, 'watchlist', safeId), {
            userId: firebaseUser.uid,
            externalId: safeId,
            source: item.source,
            mediaType: item.mediaType,
            title: item.title.slice(0, 300),
            year: (item.year || '').slice(0, 16),
            posterUrl: (item.posterUrl || '').slice(0, 600),
            genres: (item.genres || []).slice(0, 15),
            rating: Number(item.rating) || 0,
            overview: (item.overview || '').slice(0, 2500),
            reason: (item.reason || '').slice(0, 600),
            addedAt: serverTimestamp(),
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, path);
        }
        return;
      }

      if (localSession) {
        const res = await fetch('/api/user/watchlist', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${localSession.token}`,
          },
          body: JSON.stringify({ item }),
        });
        if (res.ok) {
          const data = (await res.json()) as { watchlist?: WatchlistItemDoc[] };
          if (data.watchlist) setWatchlist(data.watchlist);
        }
      }
    },
    [isLoggedIn, isFirebaseSignedIn, firebaseUser, localSession, openAuthModal]
  );

  const removeFromWatchlist = useCallback(
    async (externalId: string) => {
      if (!isLoggedIn) return;
      const safeId = externalId.replace(/[^a-zA-Z0-9_-]/g, '-').slice(0, 100);

      if (isFirebaseSignedIn && firebaseUser) {
        const path = `users/${firebaseUser.uid}/watchlist/${safeId}`;
        try {
          await deleteDoc(doc(db, 'users', firebaseUser.uid, 'watchlist', safeId));
        } catch (err) {
          handleFirestoreError(err, OperationType.DELETE, path);
        }
        return;
      }

      if (localSession) {
        const res = await fetch(`/api/user/watchlist/${encodeURIComponent(safeId)}`, {
          method: 'DELETE',
          headers: { Authorization: `Bearer ${localSession.token}` },
        });
        if (res.ok) {
          const data = (await res.json()) as { watchlist?: WatchlistItemDoc[] };
          if (data.watchlist) setWatchlist(data.watchlist);
        }
      }
    },
    [isLoggedIn, isFirebaseSignedIn, firebaseUser, localSession]
  );

  const isInWatchlist = useCallback(
    (externalId: string) => watchlist.some((w) => w.externalId === externalId),
    [watchlist]
  );

  const getRoomSession = useCallback(
    (roomCode: string) => roomSessions[roomCode.toUpperCase()] || null,
    [roomSessions]
  );

  const setRoomSession = useCallback((roomCode: string, session: WatchPartyMemberSession | null) => {
    const key = roomCode.toUpperCase();
    setRoomSessions((prev) => {
      const next = { ...prev };
      if (session) {
        next[key] = session;
      } else {
        delete next[key];
      }
      return next;
    });
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user: firebaseUser,
        authReady,
        isLoggedIn,
        displayName,
        savedPreferences,
        watchlist,
        authModalOpen,
        authModalMessage,
        openAuthModal,
        closeAuthModal,
        signInWithGoogle,
        signInWithEmail,
        signUpWithEmail,
        logOut,
        saveUserPreferences,
        addToWatchlist,
        removeFromWatchlist,
        isInWatchlist,
        getRoomSession,
        setRoomSession,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
