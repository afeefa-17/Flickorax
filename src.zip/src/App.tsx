import { useCallback, useEffect, useState } from 'react';
import { AuthModal } from './components/AuthModal.tsx';
import { DetailsModal } from './components/DetailsModal.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import { Footer } from './components/Footer.tsx';
import { Navbar, type AppRoute } from './components/Navbar.tsx';
import { AuthProvider } from './contexts/AuthContext.tsx';
import { FindContentPage } from './pages/FindContentPage.tsx';
import { HomePage } from './pages/HomePage.tsx';
import { SurpriseMePage } from './pages/SurpriseMePage.tsx';
import { WatchlistPage } from './pages/WatchlistPage.tsx';
import { WatchPartyPage } from './pages/WatchPartyPage.tsx';
import type { MediaRecommendation } from './types/flickorax.ts';

function parseRouteFromUrl(): AppRoute {
  const params = new URLSearchParams(window.location.search);
  const room = params.get('room');
  if (room) {
    return {
      page: 'watch-party',
      mode: 'join',
      roomCode: room.trim().toUpperCase(),
    };
  }
  const path = window.location.pathname.toLowerCase();
  if (path === '/find') return { page: 'find' };
  if (path === '/surprise') return { page: 'surprise' };
  if (path === '/watchlist') return { page: 'watchlist' };
  if (path === '/watch-party/create') return { page: 'watch-party', mode: 'create' };
  if (path === '/watch-party/join') return { page: 'watch-party', mode: 'join' };
  if (path.startsWith('/watch-party/room/')) {
    const code = path.split('/').pop() || '';
    return { page: 'watch-party', mode: 'room', roomCode: code.toUpperCase() };
  }
  if (path === '/watch-party') return { page: 'watch-party', mode: 'hub' };
  return { page: 'home' };
}

function buildUrlFromRoute(route: AppRoute): string {
  if (route.page === 'home') return '/';
  if (route.page === 'find') return '/find';
  if (route.page === 'surprise') return '/surprise';
  if (route.page === 'watchlist') return '/watchlist';
  if (route.page === 'watch-party') {
    if (route.mode === 'create') return '/watch-party/create';
    if (route.mode === 'join') {
      return route.roomCode ? `/?room=${encodeURIComponent(route.roomCode)}` : '/watch-party/join';
    }
    if (route.mode === 'room' && route.roomCode) {
      return `/watch-party/room/${encodeURIComponent(route.roomCode)}`;
    }
    return '/watch-party';
  }
  return '/';
}

function FlickoraxApp() {
  const [route, setRoute] = useState<AppRoute>(() => parseRouteFromUrl());
  const [detailsItem, setDetailsItem] = useState<MediaRecommendation | null>(null);

  const navigate = useCallback((next: AppRoute) => {
    setRoute(next);
    const nextUrl = buildUrlFromRoute(next);
    if (window.location.pathname + window.location.search !== nextUrl) {
      window.history.pushState({}, '', nextUrl);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  useEffect(() => {
    const onPop = () => setRoute(parseRouteFromUrl());
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-black text-[#FAFAFA]">
      <Navbar currentRoute={route} onNavigate={navigate} />

      <main className="flex-1">
        {route.page === 'home' && (
          <HomePage onNavigate={navigate} onOpenDetails={setDetailsItem} />
        )}
        {route.page === 'find' && (
          <FindContentPage onOpenDetails={setDetailsItem} />
        )}
        {route.page === 'watch-party' && (
          <WatchPartyPage
            mode={route.mode || 'hub'}
            initialRoomCode={route.roomCode || ''}
            onNavigate={navigate}
            onOpenDetails={setDetailsItem}
          />
        )}
        {route.page === 'surprise' && (
          <SurpriseMePage onOpenDetails={setDetailsItem} />
        )}
        {route.page === 'watchlist' && (
          <WatchlistPage onNavigate={navigate} onOpenDetails={setDetailsItem} />
        )}
      </main>

      <Footer onNavigate={navigate} />
      <DetailsModal item={detailsItem} onClose={() => setDetailsItem(null)} />
      <AuthModal />
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <FlickoraxApp />
      </AuthProvider>
    </ErrorBoundary>
  );
}
